#!/usr/bin/env python3
"""Export the standalone stdlib runtime with deterministic content and manifest.

Usage: python3 scripts/package-runtime.py --output /path/to/host/vendor/album_engine
The output must be an empty directory or an existing generated runtime export.
"""
import argparse
import hashlib
import json
import shutil
from pathlib import Path


def package(output):
    root = Path(__file__).resolve().parents[1]
    source = root / 'python/album_engine'
    output = Path(output).resolve()
    if output == source.resolve() or source.resolve() in output.parents:
        raise ValueError('Cannot export over runtime source')
    if output.exists() and any(output.iterdir()) and not (output / 'runtime-manifest.json').is_file():
        raise ValueError('Output is not a generated runtime export')
    files = {p.relative_to(source).as_posix(): p.read_bytes() for p in source.rglob('*')
             if p.is_file() and p.name != '.npmignore' and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
    files['model-set.json'] = (root / 'src/contracts/model-set.json').read_bytes()
    files['album-document-v2.schema.json'] = (root / 'schema/album-document-v2.schema.json').read_bytes()
    version = json.loads((root / 'package.json').read_text())['version']
    files['runtime-manifest.json'] = (json.dumps({'package':'album-engine-runtime','version':version,
        'modelSet':'album-rig-1','schemaVersion':2,'rigVersion':1,
        'sha256':{name:hashlib.sha256(raw).hexdigest() for name,raw in sorted(files.items())}},
        ensure_ascii=False,sort_keys=True,indent=2) + '\n').encode()
    output.mkdir(parents=True,exist_ok=True)
    for cache in output.rglob('__pycache__'):
        if cache.is_dir(): shutil.rmtree(cache)
    for existing in output.rglob('*'):
        if existing.is_file() and '__pycache__' not in existing.parts and existing.relative_to(output).as_posix() not in files:
            existing.unlink()
    for name,raw in sorted(files.items()):
        target = output / name; target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(raw)
    return files['runtime-manifest.json']

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    args = parser.parse_args(); package(args.output)
    print('Runtime exported to ' + str(args.output))
