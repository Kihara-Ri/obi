"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pluginRootDisposer = pluginRootDisposer;
/** Stop resources synchronously; defer nested React-root disposal past host commit. */
function pluginRootDisposer(root, controller, released) {
    let disposed = false;
    return () => {
        if (disposed)
            return;
        disposed = true;
        controller.abort();
        queueMicrotask(() => { try {
            root.unmount();
        }
        finally {
            released();
        } });
    };
}
