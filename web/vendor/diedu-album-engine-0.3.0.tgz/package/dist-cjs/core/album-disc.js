"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumDiscs = void 0;
exports.discTravel = discTravel;
const THREE = __importStar(require("three"));
const album_pocket_mouth_1 = require("./album-pocket-mouth");
const smooth = (n) => { const t = Math.max(0, Math.min(1, n)); return t * t * (3 - 2 * t); };
/** Withdraw through the holder's mouth, then bring the free disc towards the viewer. */
function discTravel(out, pocket) {
    const withdrawal = smooth(out / .52);
    // A pocket has almost no vertical clearance. Keep the complete disc flat
    // until its trailing rim clears the mouth, including on the return trip.
    return { slide: pocket ? withdrawal : 0,
        lift: pocket ? .018 * smooth((out - .52) / .16) : .025 * withdrawal,
        inspect: smooth((out - (pocket ? .68 : .52)) / (pocket ? .32 : .48)) };
}
/** Disc pivots stay attached to their holders, including when a fold is moving. */
class AlbumDiscs {
    discs = [];
    owners = new Map();
    mouths = new Map();
    sleeveTransforms = new Map();
    point = new THREE.Vector3();
    rotation = new THREE.Quaternion();
    scale = new THREE.Vector3();
    matrix = new THREE.Matrix4();
    desired = new THREE.Matrix4();
    constructor(root, indexOf, visible, singlePocket = false, innerPockets = false) {
        root.updateMatrixWorld(true);
        const candidates = [];
        root.traverse(object => {
            if (typeof object.userData.discSlot === 'number' && visible(object) && indexOf(object) >= 0)
                candidates.push(object);
        });
        for (const object of candidates) {
            const parent = object.parent;
            // Measure in the holder's coordinate system, not camera/world space:
            // the external packaging scale may differ from the nominal GLB size.
            const discBounds = new THREE.Box3().makeEmpty();
            const inverse = parent.matrixWorld.clone().invert();
            object.traverse(node => {
                if (!(node instanceof THREE.Mesh))
                    return;
                node.geometry.computeBoundingBox();
                if (!node.geometry.boundingBox)
                    return;
                discBounds.union(node.geometry.boundingBox.clone().applyMatrix4(inverse.clone().multiply(node.matrixWorld)));
            });
            const dimensions = discBounds.getSize(new THREE.Vector3());
            const position = discBounds.getCenter(new THREE.Vector3());
            const radius = Math.max(dimensions.x, dimensions.y, dimensions.z) / 2;
            const thickness = Math.min(dimensions.x, dimensions.y, dimensions.z);
            const pivot = new THREE.Group();
            pivot.name = 'Inspectable_CD_' + (indexOf(object) + 1);
            pivot.quaternion.copy(object.quaternion);
            pivot.scale.copy(object.scale);
            const hubs = parent.children.filter(child => child.name.startsWith('Disc_translucent_hub')
                && parent.worldToLocal(new THREE.Box3().setFromObject(child).getCenter(new THREE.Vector3())).distanceTo(position) < .003);
            pivot.position.copy(position);
            parent.add(pivot);
            parent.updateMatrixWorld(true);
            pivot.attach(object);
            for (const hub of hubs)
                pivot.attach(hub);
            let holder = parent;
            while (holder && !holder.userData.holder && !holder.userData.sleeveFront)
                holder = holder.parent;
            const pocket = holder?.userData.holder === 'pocket' || singlePocket;
            const mouth = holder?.userData.mouthSide ?? 1;
            const width = new THREE.Box3().setFromObject(parent).getSize(new THREE.Vector3()).x;
            const index = indexOf(object);
            let paperMouth;
            if (innerPockets && holder?.children.some(object => object.userData.pocketLip)) {
                paperMouth = this.mouths.get(holder);
                if (!paperMouth) {
                    paperMouth = new album_pocket_mouth_1.PaperPocketMouth(holder, mouth);
                    this.mouths.set(holder, paperMouth);
                }
            }
            pivot.traverse(child => this.owners.set(child, index));
            this.discs.push({ index, object: pivot, parent, position, pocket, mouth, paperMouth,
                radius, thickness,
                quaternion: pivot.quaternion.clone(), scale: pivot.scale.clone(),
                normal: new THREE.Vector3(0, 1, 0).applyQuaternion(pivot.quaternion),
                distance: Math.max(.13, width / 2 + .071 - mouth * position.x) });
        }
    }
    get indices() { return this.discs.map(disc => disc.index).sort((a, b) => a - b); }
    metrics(index) {
        const disc = this.discs.find(item => item.index === index);
        return disc ? { center: disc.position.clone(), radius: disc.radius, thickness: disc.thickness } : undefined;
    }
    seat(index, center) {
        const disc = this.discs.find(item => item.index === index);
        if (!disc)
            throw new Error('Cannot seat an unknown CD');
        disc.position.copy(center);
        disc.object.position.copy(center);
    }
    setSleeveOffset(index, offset) {
        this.setSleeveTransform(index, new THREE.Matrix4().makeTranslation(offset.x, offset.y, offset.z));
    }
    setSleeveTransform(index, transform) {
        this.sleeveTransforms.set(index, transform.clone());
    }
    owner(object) { return this.owners.get(object); }
    /** Enlarge the small exposed edge to a 44 px touch target without a visible control. */
    gripAt(x, y, camera, width, height, radius = 22, preferred = -1) {
        let chosen, nearest = radius * radius;
        const eye = camera.getWorldPosition(new THREE.Vector3());
        for (const disc of this.discs) {
            if (!disc.pocket)
                continue;
            const carrier = disc.parent.matrixWorld.clone().multiply(this.sleeveTransforms.get(disc.index) ?? new THREE.Matrix4());
            const grip = new THREE.Vector3(disc.position.x + disc.mouth * .055, disc.position.y, disc.position.z).applyMatrix4(carrier);
            const normal = new THREE.Vector3(0, 1, 0).transformDirection(carrier);
            if (normal.dot(eye.clone().sub(grip).normalize()) < .15)
                continue;
            const point = grip.project(camera);
            if (point.z < -1 || point.z > 1)
                continue;
            const squared = ((point.x + 1) * width / 2 - x) ** 2 + ((1 - point.y) * height / 2 - y) ** 2;
            // Keep the same pocket through a small boundary band while the case tilts.
            if (disc.index === preferred && squared <= (radius + 8) ** 2)
                return disc.index;
            if (squared <= nearest) {
                chosen = disc.index;
                nearest = squared;
            }
        }
        return chosen;
    }
    inspectionBounds(index) {
        const disc = this.discs.find(item => item.index === index);
        return disc ? new THREE.Box3().setFromObject(disc.object) : null;
    }
    reset(pose) {
        for (const disc of this.discs) {
            const transform = this.sleeveTransforms.get(disc.index) ?? new THREE.Matrix4();
            transform.clone().multiply(new THREE.Matrix4().compose(disc.position, disc.quaternion, disc.scale))
                .decompose(disc.object.position, disc.object.quaternion, disc.object.scale);
        }
        const active = pose && !this.sleeveTransforms.has(pose.index) && this.discs.find(disc => disc.index === pose.index)?.paperMouth;
        for (const mouth of this.mouths.values())
            mouth.paint(mouth === active ? pose.out : 0);
    }
    dispose() { for (const mouth of this.mouths.values())
        mouth.dispose(); this.mouths.clear(); }
    paint(pose, distance, view, hint) {
        const hinted = hint && this.discs.find(item => item.index === hint.index);
        const amount = hint ? Math.max(0, Math.min(1, hint.amount)) : 0;
        if (hinted && amount > 0 && (pose.index !== hinted.index || pose.out <= 0)) {
            // Paper pockets must stay flat; lifting here would cut through the lip.
            hinted.object.position.copy(hinted.position);
            if (hinted.pocket)
                hinted.object.position.x += hinted.mouth * .008 * amount;
            else
                hinted.object.position.addScaledVector(hinted.normal, .0024 * amount);
            hinted.object.position.applyMatrix4(this.sleeveTransforms.get(hinted.index) ?? new THREE.Matrix4());
            hinted.object.updateMatrixWorld(true);
        }
        if (pose.index < 0 || pose.out <= 0)
            return;
        const disc = this.discs.find(item => item.index === pose.index);
        if (!disc)
            return;
        const travel = discTravel(pose.out, disc.pocket);
        disc.parent.updateWorldMatrix(true, false);
        const remainingHint = hinted === disc ? amount * (1 - smooth(pose.out / .52)) : 0;
        const paperMouth = this.sleeveTransforms.has(disc.index) ? undefined : disc.paperMouth;
        const exitAngle = paperMouth?.paint(pose.out) ?? 0;
        const carrier = disc.parent.matrixWorld.clone().multiply(this.sleeveTransforms.get(disc.index) ?? new THREE.Matrix4());
        this.point.copy(disc.position);
        const slide = disc.distance * travel.slide + (disc.pocket ? .008 * remainingHint : 0);
        // Slide along the gently opened mouth plane. The trailing rim stays below
        // its own paper and the leading rim passes above the opposite pocket.
        this.point.x += disc.mouth * (slide * Math.cos(exitAngle) + .06 * (Math.cos(exitAngle) - 1));
        this.point.y += (slide + .06) * Math.sin(exitAngle);
        if (!disc.pocket)
            this.point.addScaledVector(disc.normal, travel.lift + .0024 * remainingHint);
        this.point.applyMatrix4(carrier);
        this.rotation.setFromRotationMatrix(new THREE.Matrix4().extractRotation(carrier));
        this.rotation.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), disc.mouth * exitAngle)).multiply(disc.quaternion);
        disc.object.getWorldScale(this.scale);
        // The inspection pose is camera-facing, independent of the packaging's
        // rotation. Its silver reverse remains accessible by rotating the disc.
        const halfView = view ? view.slope * Math.min(1, view.aspect) * (view.inspectionFraction ?? .58) : 0;
        const radius = .06 * Math.max(this.scale.x, this.scale.z);
        let fit = view ? Math.min(1.08, distance * .85 * halfView / radius) : 1.08;
        const bounds = disc.pocket ? view?.bounds : undefined;
        if (bounds)
            fit = Math.min(fit, Math.max(.05, (distance - bounds.max.z - .004) * halfView / (radius * (1 + halfView))));
        let inspectionDepth = view ? distance - radius * fit / halfView : distance * .15;
        if (bounds)
            inspectionDepth = Math.max(inspectionDepth, bounds.max.z + radius * fit + .004);
        let sideRoute = false;
        if (disc.pocket) {
            const normal = disc.normal.clone().applyMatrix3(new THREE.Matrix3().setFromMatrix4(carrier));
            let lift = travel.lift;
            if (bounds && !paperMouth) {
                // Clear a lateral edge with the complete disc before moving towards the
                // camera. The raised opposite leaf must not be crossed on that trip.
                const direction = normal.clone().normalize(), clearance = radius * Math.max(1, fit) + .003;
                let needed = Infinity, side = 1;
                for (const sign of [1, -1])
                    for (const axis of ['x', 'y'])
                        if (Math.abs(direction[axis]) > 1e-6) {
                            const component = direction[axis] * sign;
                            const edge = component > 0 ? bounds.max[axis] + clearance : bounds.min[axis] - clearance;
                            const travel = Math.max(0, (edge - this.point[axis]) / component);
                            if (travel < needed) {
                                needed = travel;
                                side = sign;
                            }
                        }
                if (Number.isFinite(needed))
                    lift *= side * Math.max(1, needed / (.018 * normal.length()));
            }
            this.point.addScaledVector(normal, lift);
            if (bounds && paperMouth && normal.z <= .15) {
                // When the opened package faces away from the camera, stay above its
                // paper, leave a lateral edge, then come forwards around that edge.
                let needed = Infinity;
                const tangent = new THREE.Vector3();
                for (const local of [new THREE.Vector3(disc.mouth, 0, 0), new THREE.Vector3(0, 0, 1), new THREE.Vector3(0, 0, -1)]) {
                    const direction = local.transformDirection(disc.parent.matrixWorld);
                    for (const axis of ['x', 'y']) {
                        const component = direction[axis];
                        if (Math.abs(component) < 1e-6)
                            continue;
                        const clearance = radius * Math.max(1, fit) + .003;
                        const edge = component > 0 ? bounds.max[axis] + clearance : bounds.min[axis] - clearance;
                        const amount = Math.max(0, (edge - this.point[axis]) / component);
                        if (amount < needed) {
                            needed = amount;
                            tangent.copy(direction);
                        }
                    }
                }
                if (Number.isFinite(needed)) {
                    this.point.addScaledVector(tangent, needed * smooth(travel.inspect / .25));
                    sideRoute = true;
                }
            }
        }
        const alignment = bounds ? smooth((travel.inspect - (sideRoute ? .5 : .4)) / (sideRoute ? .3 : .4)) : travel.inspect;
        if (bounds) {
            const clearanceDepth = bounds.max.z + radius * Math.max(1, fit) + .004;
            this.point.z += (clearanceDepth - this.point.z) * (sideRoute ? smooth((travel.inspect - .25) / .25) : smooth(travel.inspect / .4));
            this.point.x *= 1 - alignment;
            this.point.y *= 1 - alignment;
            // Recenter before approaching the inspection camera; moving a large CD
            // close while it is still off-centre would crop it on a phone viewport.
            this.point.z += (inspectionDepth - this.point.z) * smooth((travel.inspect - .8) / .2);
        }
        else
            this.point.lerp(new THREE.Vector3(0, 0, inspectionDepth), travel.inspect);
        const inspection = new THREE.Quaternion().setFromEuler(new THREE.Euler(THREE.MathUtils.degToRad(-pose.x), THREE.MathUtils.degToRad(pose.y), THREE.MathUtils.degToRad(pose.z ?? 0)))
            .multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), Math.PI / 2));
        this.rotation.slerp(inspection, alignment);
        this.scale.multiplyScalar(1 + alignment * (fit - 1));
        this.desired.compose(this.point, this.rotation, this.scale);
        this.matrix.copy(disc.parent.matrixWorld).invert().multiply(this.desired)
            .decompose(disc.object.position, disc.object.quaternion, disc.object.scale);
        disc.object.updateMatrixWorld(true);
    }
}
exports.AlbumDiscs = AlbumDiscs;
