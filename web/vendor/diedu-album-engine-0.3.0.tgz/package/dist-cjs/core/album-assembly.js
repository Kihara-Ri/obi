"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.accessoryAssembly = accessoryAssembly;
const album_model_assets_1 = require("./album-model-assets");
const album_packaging_1 = require("./album-packaging");
const capabilities_1 = require("../capabilities");
const album_accessories_1 = require("./album-accessories");
/** Resolve a declared semantic socket; never fall back to another pocket/leaf. */
function accessoryAssembly(record, entry, root, discMetrics, seatDisc) {
    if (!record.assembly || !entry.mount)
        throw new Error('Accessory has no validated assembly');
    const packagePart = (0, capabilities_1.packageComponent)(record.assembly);
    const socket = capabilities_1.MODEL_DEFINITIONS[packagePart.definition]?.sockets[entry.mount];
    if (!socket || socket.kind !== entry.kind)
        throw new Error('Accessory socket is unsupported');
    const holder = socket.node === '$root' ? root : root.getObjectByName(socket.node);
    if (!holder)
        throw new Error('Album rig is missing its declared socket');
    const discIndex = entry.discIndex ?? null;
    const disc = discIndex === null ? undefined : discMetrics(discIndex);
    if (entry.kind === 'inner-sleeve' && !disc)
        throw new Error('Disc metrics must exist before accessory assembly');
    if (entry.kind === 'inner-sleeve' && disc && entry.dimensions) {
        const lip = holder.children.find(child => child.userData.pocketLip);
        const walls = holder.children.filter(child => child.userData.pocketWall);
        if (!lip || !walls.length)
            throw new Error('Inner sleeve requires an authored pocket cavity');
        const floors = walls.map(wall => (0, album_accessories_1.boundsInRigSpace)(wall, holder).min.y);
        const floor = Math.min(...floors);
        const before = (0, album_accessories_1.boundsInRigSpace)(lip, holder).min.y;
        const depth = entry.dimensions.depth * .001;
        const ceiling = Math.max(before, floor + depth + .0002);
        lip.position.y += ceiling - before;
        for (const wall of walls) {
            const bounds = (0, album_accessories_1.boundsInRigSpace)(wall, holder);
            const height = bounds.max.y - bounds.min.y;
            wall.scale.y *= (ceiling - floor) / height;
            wall.position.y += (ceiling + floor) / 2 - (bounds.max.y + bounds.min.y) / 2;
        }
        // The old rig's generic paper sheet is replaced by the declared specimen.
        for (const child of holder.children)
            if (child.name.startsWith('Inner_sleeve'))
                child.visible = false;
        disc.center.y = floor + depth / 2 + .0001;
        seatDisc?.(discIndex, disc.center);
        holder.updateWorldMatrix(true, true);
    }
    const physical = (0, album_accessories_1.measureInsertMetrics)(root, holder, disc);
    if (entry.kind === 'booklet') {
        const leaf = holder.children.find(child => child.userData.printLeaf);
        if (leaf)
            physical.pocket.min.y = (0, album_accessories_1.boundsInRigSpace)(leaf, holder).max.y;
        // A leaf-mounted booklet is a separate object above its fixed carrier,
        // not intersecting the CD or trapped inside the holder's solid front.
        for (const carrier of holder.children.filter(child => child.visible && child.userData.holder))
            physical.pocket.min.y = Math.max(physical.pocket.min.y, (0, album_accessories_1.boundsInRigSpace)(carrier, holder, true).max.y);
    }
    return { kind: packagePart.configuration.structure ?? 'unknown', holder, discIndex, opening: socket.opening, physical,
        finish: (0, album_packaging_1.albumPackaging)(packagePart.configuration).finish,
        ...(entry.kind === 'booklet' && socket.panel !== undefined && holder.children.some(child => child.visible && child.userData.holder) ? { coversDiscs: (0, album_model_assets_1.albumPanelDiscs)((0, album_packaging_1.albumPackaging)(packagePart.configuration), socket.panel) } : {}) };
}
