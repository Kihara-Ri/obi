"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.insertWorkspace = insertWorkspace;
exports.inspectionCardPixels = inspectionCardPixels;
exports.workspaceDistance = workspaceDistance;
exports.inspectionCameraComposition = inspectionCameraComposition;
exports.unfoldOBI = unfoldOBI;
exports.paintInsertInspection = paintInsertInspection;
/** Camera-independent inspection transforms for authored, withdrawn paper parts. */
const THREE = __importStar(require("three"));
/** Reserve room once, rather than zooming/recentering as contents move. */
function insertWorkspace(width, height, depth, panels, inserts) {
    const radius = Math.hypot(width * Math.max(1, panels) / 2, height / 2, depth);
    const clearanceRadius = radius + Math.hypot(width, height) / 2 + .015;
    return { coverWidth: width, coverHeight: height, coverDepth: depth, radius, clearanceRadius, halfWidth: inserts ? clearanceRadius : radius,
        halfHeight: inserts ? clearanceRadius : radius,
        paperTop: height / 2 + .048, paperSide: width / 2 + .062 };
}
function inspectionCardPixels(width, height) {
    return Math.min(width * .82, height * (width <= 650 ? .69 : .72), width <= 650 ? Infinity : 680);
}
function workspaceDistance(workspace, aspect, zoom, viewport = { width: aspect * 900, height: 900 }) {
    const slope = Math.tan(THREE.MathUtils.degToRad(18));
    const pixels = inspectionCardPixels(viewport.width, viewport.height);
    const cover = Math.max(workspace.coverHeight, workspace.coverWidth);
    return (cover * viewport.height / (2 * slope * pixels) + workspace.coverDepth * .6) / zoom;
}
/** Camera composition follows the actual reversible withdrawal/fold progress.
 * Same parameter yields the same frame in either direction; no camera state
 * accumulates between ticks, and an untouched album stays in its old frame. */
function inspectionCameraComposition(obi, sheet, viewportWidth) {
    const smooth = (n) => { const t = Math.max(0, Math.min(1, n)); return t * t * (3 - 2 * t); };
    const focus = smooth((obi - .32) / .68), unfold = smooth(sheet);
    const multiplier = 1 + Math.max(.15 * focus, .23 * unfold);
    return { multiplier, shiftX: viewportWidth >= 850 ? .012 * focus * (1 - unfold) : 0 };
}
/** Only author-provided Blender shape keys are driven here. */
function unfoldOBI(part, amount) {
    if (part.kind !== 'obi')
        return;
    const authored = part.group.getObjectByName('Component_obi');
    const count = authored?.userData.unfoldSamples;
    if (!count)
        return;
    const sample = Math.max(0, Math.min(1, amount)) * count;
    part.group.traverse(node => {
        if (!(node instanceof THREE.Mesh) || !node.morphTargetInfluences || !node.morphTargetDictionary)
            return;
        const weights = node.morphTargetInfluences, keys = node.morphTargetDictionary;
        const depth = weights[keys.case_depth], width = weights[keys.band_width];
        for (let index = 1; index <= count; index++) {
            const weight = Math.max(0, 1 - Math.abs(sample - index));
            const suffix = String(index).padStart(2, '0');
            for (const [prefix, factor] of [['unfold_', 1], ['unfold_depth_', depth], ['unfold_width_', width]]) {
                const key = keys[prefix + suffix];
                if (key === undefined)
                    throw new Error('Blender OBI unfolding morph is missing');
                weights[key] = weight * factor;
            }
        }
    });
}
/** Remain on the physical withdrawal path until its trailing edge is free,
 * then blend to an independent, camera-facing pose. The same rule stows it. */
function paintInsertInspection(part, workspace, view) {
    const start = part.kind === 'obi' ? .62 : part.kind === 'inner-sleeve' ? .78 : .9;
    const n = Math.max(0, Math.min(1, (part.progress - start) / (1 - start)));
    const smooth = (value) => { const t = Math.max(0, Math.min(1, value)); return t * t * (3 - 2 * t); };
    const escape = smooth(n / .3), free = smooth((n - .3) / .7);
    unfoldOBI(part, free);
    if (!n)
        return;
    const group = part.group, parent = group.parent;
    if (!parent)
        return;
    parent.updateWorldMatrix(true, true);
    const point = group.getWorldPosition(new THREE.Vector3());
    const quaternion = group.getWorldQuaternion(new THREE.Quaternion());
    const scale = group.getWorldScale(new THREE.Vector3());
    let slot = part.kind === 'obi' ? new THREE.Vector3(0, workspace.paperTop, workspace.radius + .10)
        : new THREE.Vector3(part.kind === 'booklet' ? -workspace.paperSide : workspace.paperSide, .025, workspace.radius + .10);
    let viewScale = 1;
    let localCenter = new THREE.Vector3();
    if (view) {
        // Only the withdrawn copy is fitted to a reading workspace. Neither the
        // document's physical dimensions nor the mounted transform are changed.
        group.updateWorldMatrix(true, true);
        const inverse = group.matrixWorld.clone().invert(), bounds = new THREE.Box3().makeEmpty();
        group.traverse(node => {
            if (!(node instanceof THREE.Mesh))
                return;
            for (let ancestor = node; ancestor && ancestor !== group; ancestor = ancestor.parent)
                if (!ancestor.visible)
                    return;
            const localToPart = inverse.clone().multiply(node.matrixWorld);
            if (node.morphTargetInfluences?.length) {
                // Morph target unions are NOT the current paper surface: using the
                // union's ghost centre pushes a folded OBI behind the camera.
                const vertex = new THREE.Vector3();
                for (let i = 0; i < node.geometry.getAttribute('position').count; i++)
                    bounds.expandByPoint(node.getVertexPosition(i, vertex).applyMatrix4(localToPart));
            }
            else {
                node.geometry.computeBoundingBox();
                if (node.geometry.boundingBox)
                    bounds.union(node.geometry.boundingBox.clone().applyMatrix4(localToPart));
            }
        });
        const size = bounds.getSize(new THREE.Vector3());
        localCenter = bounds.getCenter(localCenter);
        const card = inspectionCardPixels(view.width, view.height);
        const unfold = part.foldProgress ?? 0;
        // Free OBI is a portrait strip, not a tiny horizontal ribbon. Use the
        // printed short edge as width and its long fold axis as height.
        const nominalWidth = size.x, nominalHeight = size.z;
        const obiHeight = Math.min(view.height * (view.width < 650 ? .5 : .60), view.width < 650 ? 350 : 480);
        let targetWidth = part.kind === 'obi' ? obiHeight * nominalWidth / Math.max(.001, nominalHeight)
            : THREE.MathUtils.lerp(Math.min(card * .72, view.width * .62), Math.min(view.width * .84, 1180), unfold);
        targetWidth = Math.min(targetWidth, nominalWidth / Math.max(.001, nominalHeight) * view.height * .68);
        // Solve depth and uniform inspection scale together: even a tilted sheet's
        // enclosing sphere remains in front of every possible album attitude.
        const fitFactor = targetWidth * 2 * view.slope / (view.height * Math.max(.001, nominalWidth));
        const paperRadius = Math.hypot(size.x, size.y, size.z) / 2;
        const idealDepth = (workspace.radius + .006 + paperRadius * fitFactor * view.distance) / (1 + paperRadius * fitFactor);
        // Four-panel jackets may have a clearance sphere almost as large as the
        // camera distance. Never put inspection paper at/behind the camera plane:
        // that projects its grip thousands of pixels outside the viewport.
        const depth = Math.min(idealDepth, view.distance - Math.max(.05, view.distance * .26));
        const unitsPerPixel = 2 * view.slope * (view.distance - depth) / view.height;
        // Magnify only a free OBI into a readable inspection strip; this never
        // alters its mounted stock/rig or any other component's physical scale.
        viewScale = Math.min(part.kind === 'obi' ? 3.5 : 1, targetWidth * unitsPerPixel / Math.max(.001, nominalWidth));
        const side = view.width >= 900 ? Math.min(view.width * .32, (card + targetWidth) * .52 + 30) : 0;
        const cy = 0;
        slot = new THREE.Vector3((part.kind === 'obi' ? side : part.kind === 'booklet' ? -side * (1 - unfold) : side) * unitsPerPixel, cy * unitsPerPixel, depth);
    }
    // First clear a sphere enclosing every album attitude while still folded.
    // Then travel around it, rather than cutting through the box on a straight
    // chord. The same route and staged folding apply in reverse on reinsertion.
    const length = point.length(), direction = length > 1e-8 ? point.clone().divideScalar(length) : new THREE.Vector3(0, 1, 0);
    const radius = THREE.MathUtils.lerp(length, Math.max(length, workspace.clearanceRadius), escape);
    const arc = new THREE.Quaternion().setFromUnitVectors(direction, slot.clone().normalize());
    direction.applyQuaternion(new THREE.Quaternion().slerp(arc, free));
    point.copy(direction).multiplyScalar(THREE.MathUtils.lerp(radius, slot.length(), free));
    const rotation = part.inspection ?? { x: 0, y: 0, z: 0 };
    const desired = new THREE.Quaternion().setFromEuler(new THREE.Euler(THREE.MathUtils.degToRad(-rotation.x), THREE.MathUtils.degToRad(rotation.y), THREE.MathUtils.degToRad(rotation.z ?? 0)));
    // A withdrawn OBI is presented upright like the original vertical paper,
    // not laid sideways over the gallery's toolbar.
    desired.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), Math.PI / 2));
    quaternion.slerp(desired, free);
    if (view) {
        scale.multiplyScalar(THREE.MathUtils.lerp(1, viewScale, free));
        point.addScaledVector(localCenter.multiply(scale).applyQuaternion(quaternion), -free);
    }
    const matrix = new THREE.Matrix4().compose(point, quaternion, scale);
    new THREE.Matrix4().copy(parent.matrixWorld).invert().multiply(matrix).decompose(group.position, group.quaternion, group.scale);
    group.updateMatrixWorld(true);
}
