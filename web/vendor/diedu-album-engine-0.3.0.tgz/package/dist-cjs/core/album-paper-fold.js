"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paintPaperFold = paintPaperFold;
/** 0 is the physical stowed stack, 1 is the complete two-sided sheet.
 * The scene owns foldProgress/foldTarget and folds before beginning withdrawal
 * reversal. This final safety gate keeps a stale unfolding request out of a slot.
 */
function paintPaperFold(part, amount) {
    if (!part.fold || part.kind !== 'booklet')
        return;
    const authored = part.group.getObjectByName('Component_foldout');
    const variant = authored?.children.find(child => child.userData.foldPanels === part.fold.panels);
    if (!variant || authored?.userData.foldPattern !== 'accordion')
        throw new Error('Blender foldout variant is missing');
    const phase = part.progress >= 1 - 1e-6 ? Math.max(0, Math.min(1, Number.isFinite(amount) ? amount : 0)) : 0;
    // Both endpoints have zero hinge velocity; reversing follows the same angle.
    const value = phase * phase * (3 - 2 * phase);
    variant.position.x = Number(variant.userData.foldFlatOffsetMm) * .001 * value;
    variant.traverse(node => {
        if (typeof node.userData.foldHinge !== 'number')
            return;
        const closed = node.userData.foldClosedRadians;
        if (typeof closed !== 'number')
            throw new Error('Blender accordion hinge is missing');
        node.rotation.set(0, 0, closed * (1 - value));
    });
}
