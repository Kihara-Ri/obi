"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.albumMaterial = albumMaterial;
/** Engine-owned physical substrates; photographs supply ink, never fake relief. */
const three_1 = require("three");
function albumMaterial(source, finish) {
    const material = source instanceof three_1.MeshPhysicalMaterial ? source.clone() : new three_1.MeshPhysicalMaterial();
    if (!(source instanceof three_1.MeshPhysicalMaterial)) {
        // Copy every authored standard property while retaining physical defaults.
        three_1.MeshStandardMaterial.prototype.copy.call(material, source);
        material.defines = { STANDARD: '', PHYSICAL: '' };
    }
    const name = source.name.replace(/\.\d+$/, '');
    const paper = /^Paper_|^Accessory_|^Print_(?!disc)/.test(name);
    if (paper) {
        const cut = /Paper_Cut|Accessory_Paper/.test(name);
        const coating = cut ? 'uncoated' : finish;
        material.metalness = 0;
        material.transmission = 0;
        material.ior = 1.46;
        material.roughness = coating === 'uncoated' ? .90 : coating === 'matte' ? .64 : .28;
        material.clearcoat = coating === 'uncoated' ? 0 : coating === 'matte' ? .12 : .72;
        material.clearcoatRoughness = coating === 'gloss' ? .18 : .48;
        material.specularIntensity = coating === 'uncoated' ? .28 : .48;
        material.sheen = coating === 'uncoated' ? .10 : .02;
        material.sheenRoughness = .88;
        material.userData = { ...source.userData, substrate: 'paper', finish: coating };
    }
    else if (/Polystyrene_Clear|Tray_Clear|Disc_Hub/.test(name)) {
        material.color.setHex(0xf5f8fc);
        material.roughness = .075;
        material.metalness = 0;
        material.ior = /Disc_Hub/.test(name) ? 1.58 : 1.59;
        material.transmission = .94;
        material.thickness = .0012;
        material.attenuationColor.setHex(0xe8eff8);
        material.attenuationDistance = .45;
        material.clearcoat = .8;
        material.clearcoatRoughness = .12;
        material.transparent = false;
        material.opacity = 1;
        material.userData = { ...source.userData, substrate: 'clear-plastic' };
    }
    else if (/Tray_Graphite/.test(name)) {
        material.metalness = 0;
        material.transmission = 0;
        material.roughness = .48;
        material.clearcoat = .16;
        material.clearcoatRoughness = .42;
        material.userData = { ...source.userData, substrate: 'molded-tray' };
    }
    else if (/Disc_Aluminium/.test(name)) {
        material.metalness = 1;
        material.roughness = .12;
        material.iridescence = .45;
        material.userData = { ...source.userData, substrate: 'aluminium' };
    }
    else if (/Print_disc/.test(name)) {
        material.roughness = .38;
        material.clearcoat = .38;
        material.clearcoatRoughness = .22;
        material.userData = { ...source.userData, substrate: 'printed-disc' };
    }
    return material;
}
