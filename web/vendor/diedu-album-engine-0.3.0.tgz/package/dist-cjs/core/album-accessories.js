"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.accessoryLabel = void 0;
exports.boundsInRigSpace = boundsInRigSpace;
exports.measureInsertMetrics = measureInsertMetrics;
exports.accessoryTemplateName = accessoryTemplateName;
exports.buildAccessory = buildAccessory;
exports.validAccessories = validAccessories;
exports.advanceAccessoryProgress = advanceAccessoryProgress;
exports.positionAccessory = positionAccessory;
/** Physical, independent supplements assembled in a packaging-local coordinate frame.
 * Units are metres, with print in X/Z and paper thickness along Y (glTF Y-up).
 * No host data, DOM controls, or application state belongs in this module.
 */
const THREE = __importStar(require("three"));
const album_materials_1 = require("./album-materials");
const album_paper_material_1 = require("./album-paper-material");
const album_paper_fold_1 = require("./album-paper-fold");
/** Transform authored mesh bounds into the selected rig's local coordinate space. */
function boundsInRigSpace(object, space, shellOnly = false) {
    space.updateWorldMatrix(true, true);
    const inverse = space.matrixWorld.clone().invert();
    const bounds = new THREE.Box3().makeEmpty();
    object.traverse(node => {
        if (!(node instanceof THREE.Mesh) || !node.geometry)
            return;
        if (shellOnly) {
            for (let ancestor = node; ancestor && ancestor !== object.parent; ancestor = ancestor.parent)
                if (!ancestor.visible || typeof ancestor.userData.discSlot === 'number' || ancestor.userData.accessoryId)
                    return;
        }
        const matrix = inverse.clone().multiply(node.matrixWorld);
        if (node.morphTargetInfluences?.length) {
            const vertex = new THREE.Vector3();
            for (let i = 0; i < node.geometry.getAttribute('position').count; i++)
                bounds.expandByPoint(node.getVertexPosition(i, vertex).applyMatrix4(matrix));
        }
        else {
            node.geometry.computeBoundingBox();
            if (node.geometry.boundingBox)
                bounds.union(node.geometry.boundingBox.clone().applyMatrix4(matrix));
        }
    });
    return bounds;
}
/** Never use overall root bounds for panel height: discs, hinges, and attachments
 * can have a larger envelope than the authored printed cover.
 */
function measureInsertMetrics(root, holder, disc) {
    const board = root.getObjectByName('Back_board') ?? root.getObjectByName('Front_board') ?? root;
    const panel = boundsInRigSpace(board, root);
    const packageEnvelope = boundsInRigSpace(root, root, true);
    // A fold wrap sits outside the assembled jacket, not inside the thin
    // back-board sheet: derive its two surfaces from the actual Y envelope.
    panel.min.y = packageEnvelope.min.y;
    panel.max.y = packageEnvelope.max.y;
    const pocket = holder && holder !== root ? boundsInRigSpace(holder, holder) : panel.clone();
    // Panel and holder axes match for these album rigs; permit a conservative
    // board fallback on a partially authored or unknown packaging template.
    return { panel, shell: packageEnvelope, pocket, disc };
}
function accessoryTemplateName(entry) {
    return entry.kind === 'booklet' && entry.fold ? 'foldout' : entry.kind;
}
const accessoryLabel = (kind) => kind === 'obi' ? '侧标 OBI' : kind === 'booklet' ? '歌词册' : '内袋';
exports.accessoryLabel = accessoryLabel;
/** Templates are authored/exported by Blender. Runtime assembly never creates
 * accessory vertices, faces or replacement solids.
 */
function prepareTemplate(template, kind, texture, region, geometries, materials, backTexture, finish, fold) {
    const body = template.clone(true);
    const authored = body.getObjectByProperty('name', 'Component_' + (fold ? 'foldout' : kind));
    if (!authored || authored.userData.componentKind !== kind)
        throw new Error('Blender component template is incompatible');
    if (fold) {
        if (kind !== 'booklet' || fold.pattern !== 'accordion' || !Number.isInteger(fold.panels) || fold.panels < 2 || fold.panels > 6
            || authored.userData.foldPattern !== fold.pattern)
            throw new Error('Blender foldout template is incompatible');
        const variant = authored.children.find(child => child.userData.foldPanels === fold.panels);
        if (!variant)
            throw new Error('Blender foldout panel variant is missing');
        // Remove unused authored variants from this private clone so bounds and
        // raycasting see exactly the selected physical sheet, including all leaves.
        for (const child of [...authored.children])
            if (child !== variant)
                authored.remove(child);
    }
    body.traverse(node => {
        if (!(node instanceof THREE.Mesh))
            return;
        node.geometry = node.geometry.clone();
        geometries.push(node.geometry);
        const originals = Array.isArray(node.material) ? node.material : [node.material];
        const painted = originals.map(original => {
            const material = (0, album_materials_1.albumMaterial)(original, finish);
            if (original.name === 'Accessory_Print_front' || original.name === 'Accessory_Print_back') {
                const map = original.name === 'Accessory_Print_back' ? backTexture : texture;
                material.map = map;
                material.color.setHex(map ? 0xffffff : 0xd8cfba);
                const uv = node.geometry.getAttribute('uv');
                if (region && uv) {
                    const [left, top, right, , , bottom] = region;
                    for (let i = 0; i < uv.count; i++)
                        uv.setXY(i, left + uv.getX(i) * (right - left), 1 - bottom + uv.getY(i) * (bottom - top));
                    uv.needsUpdate = true;
                }
            }
            material.side = THREE.DoubleSide;
            const nominal = authored.userData.nominal_mm;
            (0, album_paper_material_1.paperGrain)(material, [kind === 'obi' ? nominal[0] * 2 + nominal[2] : nominal[0] * (fold?.panels ?? 1), nominal[1]], finish, 1);
            materials.push(material);
            return material;
        });
        node.material = Array.isArray(node.material) ? painted : painted[0];
    });
    return body;
}
function sizeTemplate(body, width, height, depth) {
    const authored = body.children.find(child => child.userData.nominal_mm);
    const nominal = authored?.userData.nominal_mm;
    if (!authored || !nominal)
        throw new Error('Blender component has no nominal dimensions');
    authored.scale.set(width / (nominal[0] * .001), depth / (nominal[2] * .001), height / (nominal[1] * .001));
}
function fitOBI(body, panel, dimensions) {
    const authored = body.getObjectByName('Component_obi');
    const ranges = authored.userData.morphRanges;
    const values = {
        case_depth: (panel.max.y - panel.min.y + .0011) * 1000,
        band_width: dimensions?.width ?? (panel.max.x - panel.min.x) * 170,
        height: dimensions?.height ?? (panel.max.z - panel.min.z) * 1000 - 1.5,
    };
    if (values.height > (panel.max.z - panel.min.z) * 1000)
        throw new Error('OBI height exceeds its package');
    body.traverse(node => {
        if (!(node instanceof THREE.Mesh))
            return;
        node.morphTargetInfluences?.fill(0);
        for (const [name, value] of Object.entries(values)) {
            const index = node.morphTargetDictionary?.[name], range = ranges[name];
            if (index === undefined || !range || !node.morphTargetInfluences)
                throw new Error('Blender OBI morph is missing');
            node.morphTargetInfluences[index] = (value - range[0]) / (range[1] - range[0]);
        }
    });
}
function buildAccessory(entry, texture, assembly, template, backTexture = null) {
    const geometries = [], materials = [];
    const body = prepareTemplate(template, entry.kind, texture, entry.region, geometries, materials, backTexture, entry.kind === 'obi' ? assembly.finish ?? 'matte' : 'uncoated', entry.fold);
    body.name = 'Accessory_' + entry.id;
    body.userData = { accessoryId: entry.id, kind: entry.kind };
    const home = new THREE.Vector3(), extract = new THREE.Vector3();
    const opening = assembly.opening ?? 1;
    const panel = assembly.physical?.panel ?? new THREE.Box3(new THREE.Vector3(-.0675, -.006, -.0675), new THREE.Vector3(.0675, .006, .0675));
    const panelWidth = panel.max.x - panel.min.x, panelHeight = panel.max.z - panel.min.z;
    if (entry.kind === 'obi') {
        fitOBI(body, panel, entry.dimensions);
        const shell = assembly.physical?.shell ?? panel;
        const gauge = body.getObjectByName('Component_obi').userData.paperStockMm * .001;
        // The inner spine surface is one paper gauge inside the authored exterior.
        // A board edge omits the curved/scored spine outside that board.
        home.set(shell.min.x - gauge - .00025, (panel.min.y + panel.max.y) / 2, (panel.min.z + panel.max.z) / 2);
        extract.copy(home).add(new THREE.Vector3(0, 0, -panelHeight * 1.08));
    }
    else if (entry.kind === 'booklet') {
        const pocket = assembly.physical?.pocket ?? panel;
        const width = entry.dimensions ? entry.dimensions.width * .001 : Math.min(.112, panelWidth - .010);
        const height = entry.dimensions ? entry.dimensions.height * .001 : Math.min(.116, panelHeight - .008);
        const depth = entry.dimensions ? entry.dimensions.depth * .001 : .0008;
        if (width > pocket.max.x - pocket.min.x || height > pocket.max.z - pocket.min.z)
            throw new Error('Booklet does not fit its mount');
        if (entry.fold && depth + 1e-9 < entry.fold.panels * .0001)
            throw new Error('Foldout stock exceeds its declared depth');
        sizeTemplate(body, width, height, depth);
        // Fold dimensions reserve the mount envelope, never compress the authored
        // .1 mm stock merely because a smaller number of leaves is selected.
        if (entry.fold)
            body.getObjectByName('Component_foldout').scale.y = 1;
        // The booklet lives under a cover/leaf, not behind the whole jacket.
        // Keep a leaf-mounted booklet above its fixed carrier and CD.
        home.copy(pocket.getCenter(new THREE.Vector3()));
        home.y = pocket.min.y + depth / 2 + .0002;
        home.x = opening > 0 ? pocket.max.x - width / 2 - .001 : pocket.min.x + width / 2 + .001;
        extract.copy(home).add(new THREE.Vector3(opening * (width + .018), .010, 0));
    }
    else {
        const pocket = assembly.physical?.pocket ?? panel;
        const disc = assembly.physical?.disc;
        const diameter = (disc?.radius ?? .06) * 2;
        const clearance = Math.max(.00065, diameter * .006);
        const center = disc?.center ?? pocket.getCenter(new THREE.Vector3());
        // Offset discs are common in authored pockets: derive usable *symmetric*
        // space about the actual disc center, not merely the pocket's total width.
        const halfWidth = Math.min(center.x - pocket.min.x, pocket.max.x - center.x) - .00045;
        const halfHeight = Math.min(center.z - pocket.min.z, pocket.max.z - center.z) - .00045;
        if (Math.min(halfWidth, halfHeight) < diameter / 2 + clearance) {
            throw new Error('Album rig pocket cannot contain its disc');
        }
        const w = entry.dimensions ? entry.dimensions.width * .001 : Math.min(halfWidth * 2, diameter + .0036);
        const h = entry.dimensions ? entry.dimensions.height * .001 : Math.min(halfHeight * 2, diameter + .0036);
        const gap = entry.dimensions ? entry.dimensions.depth * .001 / 2 : Math.max(.0008, (disc?.thickness ?? .0012) / 2 + .0002);
        if (w > halfWidth * 2 || h > halfHeight * 2 || w < diameter + 2 * clearance || h < diameter + 2 * clearance
            || gap < (disc?.thickness ?? .0012) / 2 + .00015)
            throw new Error('Inner sleeve dimensions violate disc containment');
        sizeTemplate(body, w, h, gap * 2);
        const closedSeam = body.getObjectByName('InnerSleeve_Seam');
        if (!closedSeam || closedSeam.userData.seam !== 'closed-end')
            throw new Error('Blender sleeve opening seam is missing');
        closedSeam.position.x = -opening * Math.abs(closedSeam.position.x);
        home.copy(disc?.center ?? pocket.getCenter(new THREE.Vector3()));
        extract.copy(home).add(new THREE.Vector3(opening * (w + .018), .006, 0));
        // The disc and the paper leaves now have the SAME center, not an offset
        // of 14 mm along the height and 8 mm across the width.
    }
    body.position.copy(home);
    const localBounds = boundsInRigSpace(body, body);
    const grip = localBounds.getCenter(new THREE.Vector3());
    grip.x = opening > 0 ? localBounds.max.x - .0006 : localBounds.min.x + .0006;
    grip.y = localBounds.max.y;
    const placement = { id: entry.id, kind: entry.kind, group: body, home, extract,
        holder: assembly.holder ?? null, discIndex: assembly.discIndex ?? null, progress: 0, target: 0,
        mouthDirection: opening, grip, coversDiscs: assembly.coversDiscs,
        pocketMouthX: assembly.physical ? opening > 0 ? assembly.physical.pocket.max.x - .004 : assembly.physical.pocket.min.x + .004 : undefined,
        ...(entry.fold ? { fold: { ...entry.fold }, foldProgress: 0, foldTarget: 0 } : {}) };
    if (placement.fold)
        (0, album_paper_fold_1.paintPaperFold)(placement, 0);
    return { placement, geometries, materials };
}
/** Only explicitly supplied prints are assembled. No guesses from cover roles. */
function validAccessories(record) {
    const seen = new Set();
    return (record.modelAccessories ?? []).filter(item => {
        if (!/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$/.test(item.id) || seen.has(item.id))
            return false;
        if (!['obi', 'booklet', 'inner-sleeve'].includes(item.kind) || !item.source)
            return false;
        seen.add(item.id);
        return true;
    }).slice(0, 8).map(item => ({ ...item }));
}
/** A reversible position phase: one second forward, one second backward.
 * Geometry follows the same smooth curve in both directions, never jumps to
 * a new exponential velocity when switching from take to return. */
function advanceAccessoryProgress(progress, target, seconds, duration = 1.12) {
    if (progress === target)
        return target;
    const step = Math.max(0, seconds) / duration;
    return target > progress ? Math.min(target, progress + step) : Math.max(target, progress - step);
}
/** A pocket insert stays in its cavity plane until its trailing edge clears. */
function positionAccessory(part) {
    part.group.quaternion.identity();
    part.group.scale.set(1, 1, 1);
    const smooth = (value) => { const n = Math.max(0, Math.min(1, value)); return n * n * (3 - 2 * n); };
    if (part.kind === 'obi') {
        // Keep both leaves outside the jacket until the full band slides clear.
        // Only then move it forward/aside; reversal follows this same path.
        const free = smooth((part.progress - .62) / .38);
        part.group.position.set(part.home.x + (part.extract.x - part.home.x) * free, part.home.y + (part.extract.y - part.home.y) * free, part.home.z + (part.extract.z - part.home.z) * smooth(part.progress / .62));
        return;
    }
    if (part.kind !== 'inner-sleeve') {
        part.group.position.copy(part.home).lerp(part.extract, smooth(part.progress));
        return;
    }
    part.group.position.copy(part.home);
    part.group.position.x += (part.extract.x - part.home.x) * smooth(part.progress / .78);
    part.group.position.y += (part.extract.y - part.home.y) * smooth((part.progress - .78) / .22);
}
