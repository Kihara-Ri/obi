"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.albumPanelDiscs = exports.albumModelAsset = void 0;
exports.albumSceneIdentity = albumSceneIdentity;
exports.albumTextureSource = albumTextureSource;
/** Polling creates new record objects; only changed scene inputs require a new renderer. */
function albumSceneIdentity(record) {
    return JSON.stringify([record.id, record.packaging, record.modelTextures,
        record.modelWarpRows, record.modelDiscCalibrations, record.modelCalibration, record.modelAssets, record.modelAccessories, record.assembly]);
}
/** A specified but unavailable front photograph must not become a different cover. */
function albumTextureSource(record, role) {
    return record.modelTextures[role] ?? '';
}
var album_model_metadata_1 = require("./album-model-metadata");
Object.defineProperty(exports, "albumModelAsset", { enumerable: true, get: function () { return album_model_metadata_1.albumModelAsset; } });
Object.defineProperty(exports, "albumPanelDiscs", { enumerable: true, get: function () { return album_model_metadata_1.albumPanelDiscs; } });
