"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.advanceDiscMotion = advanceDiscMotion;
exports.discFramingRoom = discFramingRoom;
const FULL_TRAVEL_SECONDS = 1.5;
/**
 * The forward and return paths are time reverses of one ease-in-out curve.
 * If direction changes mid-flight, cubic Hermite interpolation preserves the
 * current velocity, letting the disc brake smoothly before returning.
 * Progress is driven by elapsed seconds, not by the display refresh rate.
 */
function advanceDiscMotion(motion, goal, seconds) {
    if (seconds <= 0)
        return motion;
    if (Math.abs(goal - motion.out) < 1e-9 && Math.abs(motion.velocity) < 1e-9)
        return { out: goal, velocity: 0 };
    const retarget = motion.from === undefined || motion.to !== goal || motion.elapsed === undefined;
    const from = retarget ? motion.out : motion.from;
    const duration = retarget
        ? Math.max(.38, FULL_TRAVEL_SECONDS * Math.sqrt(Math.abs(goal - from)))
        : motion.duration;
    const initialVelocity = retarget ? motion.velocity : (motion.velocityStart ?? 0);
    const elapsed = Math.min(duration, (retarget ? 0 : motion.elapsed) + seconds);
    const t = elapsed / duration, t2 = t * t, t3 = t2 * t;
    // Cubic Hermite: position and velocity are continuous through a reversal.
    const delta = goal - from, tangent = initialVelocity * duration;
    const value = from + (t3 - 2 * t2 + t) * tangent + (3 * t2 - 2 * t3) * delta;
    const speed = ((3 * t2 - 4 * t + 1) * tangent + (6 * t - 6 * t2) * delta) / duration;
    if (elapsed >= duration - 1e-8)
        return { out: goal, velocity: 0 };
    const out = Math.max(0, Math.min(1, value));
    return { out, velocity: out === value ? speed : 0, from, to: goal, elapsed, duration,
        velocityStart: initialVelocity };
}
function discFramingRoom(out, pocket) {
    const smooth = (value) => { const t = Math.max(0, Math.min(1, value)); return t * t * (3 - 2 * t); };
    return pocket ? .09 * smooth(out / .52) * (1 - smooth((out - .52) / .48)) : 0;
}
