"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.initialAlbumPose = initialAlbumPose;
exports.albumCameraFraming = albumCameraFraming;
/** Canonical radians become the viewer's historical degree-based input pose. */
function initialAlbumPose(presentation) {
    const camera = presentation?.initialCamera;
    return { x: camera?.pitch === undefined ? -8 : camera.pitch * 180 / Math.PI,
        y: camera?.yaw === undefined ? -16 : camera.yaw * 180 / Math.PI,
        zoom: camera?.zoom ?? 1, open: 0, disc: { index: -1, out: 0, x: 0, y: 0 }, hint: { index: -1, amount: 0 } };
}
/** Shift camera and target equally, preserving the package's physical center. */
function albumCameraFraming(presentation, width, height) {
    return { x: (presentation?.initialCamera.framingX ?? 0) * width,
        y: (presentation?.initialCamera.framingY ?? 0) * height };
}
