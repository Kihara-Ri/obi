"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rotationDelta = rotationDelta;
exports.inspectionRim = inspectionRim;
/** Continuous in-plane rotation shared by touch, pointer and keyboard input. */
function rotationDelta(previous, next) {
    return Math.atan2(Math.sin(next - previous), Math.cos(next - previous)) * 180 / Math.PI;
}
function inspectionRim(frame, x, y) {
    return Math.hypot((x - frame.x) / Math.max(1, frame.width / 2), (y - frame.y) / Math.max(1, frame.height / 2)) > .68;
}
