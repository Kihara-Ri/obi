"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumScene = void 0;
const album_presentation_1 = require("./album-presentation");
/** Loaded only by the focused lightbox. No shared renderer, cache or mutable singleton. */
const THREE = __importStar(require("three"));
const GLTFLoader_js_1 = require("three/addons/loaders/GLTFLoader.js");
const RoomEnvironment_js_1 = require("three/addons/environments/RoomEnvironment.js");
const album_model_assets_1 = require("./album-model-assets");
const album_rib_material_1 = require("./album-rib-material");
const album_photo_material_1 = require("./album-photo-material");
const album_photo_projection_1 = require("./album-photo-projection");
const album_spine_fit_1 = require("./album-spine-fit");
const album_fold_calibration_1 = require("./album-fold-calibration");
const album_paper_material_1 = require("./album-paper-material");
const album_disc_1 = require("./album-disc");
const album_disc_material_1 = require("./album-disc-material");
const album_disc_calibration_1 = require("./album-disc-calibration");
const album_accessories_1 = require("./album-accessories");
const album_assembly_1 = require("./album-assembly");
const album_photo_raster_1 = require("./album-photo-raster");
const album_paper_fold_1 = require("./album-paper-fold");
const album_insert_inspection_1 = require("./album-insert-inspection");
const album_materials_1 = require("./album-materials");
class AlbumScene {
    stage;
    record;
    model;
    renderer;
    world = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(36, 1, .002, 5);
    spin = new THREE.Group();
    conversion = new THREE.Group();
    environmentMap;
    abort = new AbortController();
    geometries = new Set();
    materials = new Set();
    textures = new Set();
    photoBitmaps = new Map();
    decodedPhotos = new Set();
    assets = [];
    mixers = [];
    folds = [];
    visibleMeshes = [];
    calibratedFolds = [];
    box = new THREE.Box3();
    center = new THREE.Vector3();
    size = new THREE.Vector3();
    mouse = new THREE.Vector2();
    ray = new THREE.Raycaster();
    observer;
    slip = null;
    discs = null;
    discDirections = null;
    accessoryMeshes = [];
    accessoryAnimation = 0;
    primaryAsset = null;
    renderedOpen = 0;
    pendingClose = false;
    disposed = false;
    ready = false;
    pose = { x: -8, y: -16, open: 0, zoom: 1, disc: { index: -1, out: 0, x: 0, y: 0 }, hint: { index: -1, amount: 0 } };
    slipWidth = .15;
    slipHeight = .15;
    workspace = (0, album_insert_inspection_1.insertWorkspace)(.135, .135, .012, 1, false);
    constructor(stage, canvas, record, model) {
        this.stage = stage;
        this.record = record;
        this.model = model;
        this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.outputColorSpace = THREE.SRGBColorSpace;
        // Only real insert materials use local clipping; package geometry stays intact.
        this.renderer.localClippingEnabled = true;
        this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        this.renderer.toneMappingExposure = .9;
        const environment = new RoomEnvironment_js_1.RoomEnvironment();
        const pmrem = new THREE.PMREMGenerator(this.renderer);
        this.environmentMap = pmrem.fromScene(environment, .025);
        environment.dispose();
        pmrem.dispose();
        this.world.environment = this.environmentMap.texture;
        this.world.environmentIntensity = .5;
        this.world.add(this.spin);
        this.conversion.rotation.x = Math.PI / 2;
        this.spin.add(this.conversion);
        const light = new THREE.DirectionalLight(0xffffff, .35);
        light.position.set(-.3, .5, .5);
        this.world.add(light, new THREE.AmbientLight(0xffffff, .12));
        this.observer = new ResizeObserver(() => this.resize());
        this.observer.observe(stage);
        this.resize();
    }
    async load() {
        const asset = await this.loadAsset((0, album_model_assets_1.albumModelAsset)(this.model, !!this.record.modelCalibration, this.record.modelAssets));
        if (this.disposed)
            return;
        this.conversion.add(asset);
        this.primaryAsset = asset;
        const root = asset.children.find(child => Array.isArray(child.userData.nominal_mm));
        const nominal = root?.userData.nominal_mm ?? [135, 135, 2];
        const measured = this.record.packaging?.size;
        // glTF is Y-up: scale axes before converting back to the printed XY plane.
        if (measured) {
            (0, album_fold_calibration_1.resizePaperShell)(asset, measured.width / nominal[0], measured.height / nominal[1]);
        }
        this.configure(asset);
        if (this.model.slipcase) {
            const outside = await this.loadAsset(this.record.modelAssets.baseUrl.replace(/\/?$/, '/') + 'slipcase.glb');
            if (this.disposed)
                return;
            this.configure(outside, true);
            this.slip = new THREE.Group();
            this.slip.scale.set((nominal[0] + 2) / 150, (nominal[2] + 1.8) / 30, (nominal[1] + 2) / 150);
            this.slip.add(outside);
            this.conversion.add(this.slip);
            this.slipWidth = (nominal[0] + 5) * .001;
            this.slipHeight = (nominal[1] + 4) * .001;
        }
        this.poseRig(0);
        asset.updateMatrixWorld(true);
        await this.applyTextures();
        if (this.disposed)
            return;
        this.discs = new album_disc_1.AlbumDiscs(asset, object => this.discIndex(object), object => this.isVisible(object), this.model.kind === 'card-sleeve', this.model.kind === 'gatefold' && this.model.panels === 2 && this.model.holder === 'pocket' && this.model.pocketOpening === 'inner');
        await this.buildAccessories();
        if (this.disposed)
            return;
        this.workspace = (0, album_insert_inspection_1.insertWorkspace)(nominal[0] * .001, nominal[1] * .001, nominal[2] * .001, this.model.panels, this.accessoryMeshes.length > 0);
        this.conversion.traverse(object => {
            if (object instanceof THREE.Mesh && this.isVisible(object))
                this.visibleMeshes.push(object);
        });
        this.ready = true;
        this.stage.dataset.accessoryCount = String(this.accessoryMeshes.length);
        this.stage.dataset.modelAsset = (0, album_model_assets_1.albumModelAsset)(this.model, !!this.record.modelCalibration, this.record.modelAssets);
        this.stage.dataset.renderer = 'webgl';
        this.stage.dataset.ready = 'true';
        this.paint(this.pose);
    }
    async loadAsset(url) {
        const response = await fetch(url, { signal: this.abort.signal });
        if (!response.ok)
            throw new Error('Packaging model unavailable');
        const gltf = await new GLTFLoader_js_1.GLTFLoader().parseAsync(await response.arrayBuffer(), new URL('.', new URL(url, document.baseURI)).href);
        this.assets.push(gltf.scene);
        gltf.scene.traverse(object => {
            if (!(object instanceof THREE.Mesh))
                return;
            this.geometries.add(object.geometry);
            for (const material of Array.isArray(object.material) ? object.material : [object.material])
                this.materials.add(material);
        });
        if (this.disposed) {
            this.releaseAssets();
            throw new Error('Viewer closed');
        }
        if (gltf.animations.length) {
            const mixer = new THREE.AnimationMixer(gltf.scene);
            const actions = gltf.animations.map(clip => {
                const action = mixer.clipAction(clip);
                action.setLoop(THREE.LoopOnce, 1);
                action.clampWhenFinished = true;
                action.play();
                action.paused = true;
                return action;
            });
            this.mixers.push({ mixer, actions });
        }
        return gltf.scene;
    }
    isVisible(object) {
        for (let item = object; item; item = item.parent)
            if (!item.visible)
                return false;
        return true;
    }
    configure(asset, outside = false) {
        const fit = (0, album_spine_fit_1.spineCalibrationFit)(this.record);
        const calibratedSheets = [];
        asset.traverse(object => {
            const extras = object.userData;
            const stack = Math.max(0, (0, album_model_assets_1.albumPanelDiscs)(this.model, extras.panel ?? object.parent?.userData.panel ?? 1).length - 1) * .00125;
            if (extras.pocketLip)
                object.position.y += stack;
            if (extras.pocketWall) {
                object.scale.y *= 1 + stack / ((extras.wallHeight ?? 2.5) * .001);
                object.position.y += stack / 2;
            }
            if (extras.sleeveFront)
                object.position.y += stack;
            if (extras.sleeveWall) {
                object.scale.y *= 1 + stack / .0032;
                object.position.y += stack / 2;
            }
            if (extras.foldSheet || extras.foldJoint) {
                const holderDepth = (panel) => (0, album_spine_fit_1.albumCarrierDepth)(this.record, this.model, panel, !!fit?.compactPockets);
                const needed = extras.foldIndex === 0 ? Array.from({ length: this.model.panels }, (_, panel) => holderDepth(panel)).reduce((a, b) => a + b, this.model.kind === 'gatefold' && this.model.pocketOpening === 'inner' ? .12 : .7)
                    : holderDepth(extras.foldIndex + 1) + holderDepth(1) + .7;
                const calibrated = fit && extras.foldIndex === 0;
                const factor = calibrated ? fit.factor : Math.max(1, needed / extras.foldGap);
                if (extras.foldSheet) {
                    if (calibrated)
                        calibratedSheets.push(object);
                    else {
                        object.scale.x *= factor;
                        object.scale.y *= factor;
                    }
                }
                else
                    this.folds.push({ object, factor, position: object.position.clone() });
            }
            if (extras.holder) {
                const expected = this.model.kind === 'jewel' ? 'tray' : this.model.holder;
                object.visible = extras.holder === expected && (0, album_model_assets_1.albumPanelDiscs)(this.model, extras.panel).length > 0;
                if (object.visible && extras.holder === 'pocket' && fit?.compactPockets)
                    (0, album_fold_calibration_1.compactPaperPocket)(object);
            }
            if (extras.extraDisc)
                object.visible = (0, album_model_assets_1.albumPanelDiscs)(this.model, extras.panel).length > 1;
            if (typeof extras.discSlot === 'number')
                object.visible = this.discIndex(object) >= 0;
            if (!(object instanceof THREE.Mesh))
                return;
            const dimensions = new THREE.Box3().setFromBufferAttribute(object.geometry.attributes.position)
                .getSize(new THREE.Vector3());
            const originals = Array.isArray(object.material) ? object.material : [object.material];
            const next = originals.map(original => {
                const material = original;
                let clone = (0, album_materials_1.albumMaterial)(material, this.model.finish);
                const print = /^Print_([^\.]+)/.exec(material.name)?.[1];
                if (print) {
                    let role = print;
                    if (role === 'disc') {
                        let item = object;
                        while (item && typeof item.userData.discSlot !== 'number')
                            item = item.parent;
                        const index = item ? Math.max(0, this.discIndex(item)) : 0;
                        role = index === 0 ? 'disc' : ('disc' + (index + 1));
                    }
                    const ratio = (role === 'spine' && !object.morphTargetInfluences?.length ? dimensions.y : dimensions.x) / Math.max(.00001, dimensions.z);
                    clone.userData = { role, outside, ratio };
                }
                if (/Tray_Graphite/.test(material.name) && this.model.tray !== 'black') {
                    clone = new THREE.MeshPhysicalMaterial({ name: material.name,
                        color: this.model.tray === 'white' ? 0xd8d8d2 : 0xf4f9fc,
                        roughness: this.model.tray === 'white' ? .42 : .12,
                        transmission: this.model.tray === 'clear' ? .94 : 0, ior: 1.59 });
                }
                if (/Disc_Aluminium/.test(material.name)) {
                    if (!this.discDirections) {
                        this.discDirections = (0, album_disc_material_1.discAnisotropy)();
                        this.textures.add(this.discDirections);
                    }
                    const reflector = new THREE.MeshPhysicalMaterial({ name: material.name, color: material.color,
                        roughness: .12, metalness: 1, anisotropy: .85, anisotropyMap: this.discDirections,
                        iridescence: .45, iridescenceIOR: 1.35, envMapIntensity: 1.3 });
                    (0, album_disc_material_1.discDiffraction)(reflector);
                    clone = reflector;
                }
                if (/Tray_Graphite_Ribbed/.test(material.name)) {
                    let surface = object;
                    while (surface && !surface.userData.ribbedSpine)
                        surface = surface.parent;
                    if (surface)
                        (0, album_rib_material_1.filterSpineRibs)(clone, surface.userData, this.renderer.getPixelRatio());
                }
                if (/^Paper_/.test(material.name) || print && !print.startsWith('disc')) {
                    let fold = object;
                    while (fold && !fold.userData.foldSheet)
                        fold = fold.parent;
                    (0, album_paper_material_1.paperGrain)(clone, [fold?.userData.foldLengthMm ? fold.userData.foldLengthMm * (fold.userData.foldIndex === 0 ? fit?.factor ?? 1 : 1) : dimensions.x * 1000,
                        fold?.userData.foldHeightMm ?? dimensions.z * 1000], this.model.finish, this.renderer.getPixelRatio());
                }
                this.materials.add(clone);
                return clone;
            });
            object.material = Array.isArray(object.material) ? next : next[0];
        });
        for (const sheet of calibratedSheets) {
            const joint = sheet.parent?.children.find(object => object.userData.foldJoint && object.userData.foldIndex === sheet.userData.foldIndex);
            if (joint)
                this.calibratedFolds.push((0, album_fold_calibration_1.calibrateFold)(sheet, joint, fit.factor, this.record.modelCalibration?.spine.reliefMm));
        }
        if (fit && !outside) {
            this.stage.dataset.spineCalibration = fit.status;
            this.stage.dataset.spineRequestedMm = fit.requestedMm.toFixed(3);
            this.stage.dataset.spineAppliedMm = fit.appliedMm.toFixed(3);
            this.stage.dataset.spineBasis = fit.basis;
        }
    }
    async photoBitmap(source) {
        if (!this.photoBitmaps.has(source))
            this.photoBitmaps.set(source, (async () => {
                const response = await fetch(source, { signal: this.abort.signal });
                if (!response.ok)
                    throw new Error('Supplement image unavailable');
                const bitmap = await createImageBitmap(await response.blob());
                if (this.disposed) {
                    bitmap.close();
                    throw new Error('Viewer closed');
                }
                this.decodedPhotos.add(bitmap);
                return bitmap;
            })());
        return this.photoBitmaps.get(source);
    }
    async accessoryTexture(surface) {
        const bitmap = await this.photoBitmap(surface.source);
        const image = document.createElement('canvas');
        image.width = bitmap.width;
        image.height = bitmap.height;
        const ctx = image.getContext('2d');
        ctx.drawImage(bitmap, 0, 0);
        if (surface.region || surface.warpRows) {
            const pixels = ctx.getImageData(0, 0, image.width, image.height);
            const projected = (0, album_photo_raster_1.rasterPackagingPhoto)(pixels.data, pixels.width, pixels.height, surface.region ?? undefined, surface.warpRows);
            if (!projected)
                throw new Error('Accessory photograph cannot be projected');
            image.width = projected.width;
            image.height = projected.height;
            ctx.putImageData(new ImageData(projected.data, projected.width, projected.height), 0, 0);
        }
        const map = new THREE.CanvasTexture(image);
        map.colorSpace = THREE.SRGBColorSpace;
        map.anisotropy = Math.min(8, this.renderer.capabilities.getMaxAnisotropy());
        this.textures.add(map);
        return map;
    }
    async buildAccessories() {
        for (const entry of (0, album_accessories_1.validAccessories)(this.record).sort((a, b) => a.kind === 'booklet' ? -1 : b.kind === 'booklet' ? 1 : 0)) {
            if (this.disposed)
                return;
            let texture = null, backTexture = null;
            try {
                [texture, backTexture] = await Promise.all([this.accessoryTexture(entry), entry.back ? this.accessoryTexture(entry.back) : Promise.resolve(null)]);
            }
            catch (error) {
                if (this.disposed)
                    return;
                if (this.record.assembly)
                    throw error;
            }
            if (this.disposed)
                return;
            const root = this.primaryAsset;
            // The physical parent is a GLB pocket or hinged leaf. Its transform is
            // animated by the artist-authored rig and inherited by the supplement.
            const assembly = (0, album_assembly_1.accessoryAssembly)(this.record, entry, root, index => this.discs?.metrics(index), (index, center) => this.discs.seat(index, center));
            const holder = assembly.holder;
            const base = this.record.modelAssets.baseUrl.replace(/\/?$/, '/');
            const template = await this.loadAsset(base + 'component-' + (0, album_accessories_1.accessoryTemplateName)(entry) + '.glb');
            const part = (0, album_accessories_1.buildAccessory)({ ...entry, region: undefined }, texture, assembly, template, backTexture);
            // Authored pocket lips/notches and the fitted cavity occlude inserts.
            // A straight clipping plane would incorrectly erase paper in the notch.
            for (const geometry of part.geometries)
                this.geometries.add(geometry);
            for (const material of part.materials)
                this.materials.add(material);
            holder.add(part.placement.group);
            this.accessoryMeshes.push(part.placement);
        }
    }
    /** A real insert is reachable when its container is open or has no lid. */
    accessoryReachable(part) {
        return part.kind === 'obi' || !this.model.canOpen || this.renderedOpen >= .82 || part.progress > .05;
    }
    canTakeDisc(index) {
        // The driver may reach its target before OBI/slipcase clearance lets the
        // actual authored lid open. Keyboard and raycast must share this gate.
        if (this.model.canOpen && this.renderedOpen < .9
            && !(this.pose.disc.index === index && this.pose.disc.out > .001))
            return false;
        // The CD belongs to the inner sleeve, not to the outer case while sleeved.
        return !this.accessoryMeshes.some(part => part.kind === 'inner-sleeve'
            && part.discIndex === index && part.progress < .8 || part.coversDiscs?.includes(index) && part.progress < .92);
    }
    /** Remove the folded OBI before an opening leaf would intersect its wrap. */
    releaseWrapBeforeOpen() {
        this.pendingClose = false;
        let changed = false;
        for (const part of this.accessoryMeshes)
            if (part.kind === 'obi' && part.target === 0) {
                part.target = 1;
                changed = true;
            }
        if (changed)
            this.animateAccessories();
    }
    /** Enforce insertion order before folding the cover shut. */
    prepareForClose() {
        this.pendingClose = true;
        for (const part of this.accessoryMeshes) {
            if (part.kind !== 'obi' && !((part.kind === 'inner-sleeve' && part.discIndex === this.pose.disc.index
                || part.coversDiscs?.includes(this.pose.disc.index)) && this.pose.disc.out > .01)) {
                part.target = 0;
                if (part.fold)
                    part.foldTarget = 0;
            }
        }
        this.animateAccessories();
    }
    /** All manipulations live in the engine. The host never controls these parts. */
    toggleAccessory(id) {
        const part = this.accessoryMeshes.find(item => item.id === id);
        if (!part || !this.accessoryReachable(part))
            return;
        if (part.kind === 'obi' && part.target && this.renderedOpen > .08)
            return;
        if (part.target > 0 && part.coversDiscs?.includes(this.pose.disc.index) && this.pose.disc.out > .01)
            return;
        if (part.target > 0 && part.kind === 'inner-sleeve' && part.discIndex === this.pose.disc.index
            && this.pose.disc.out > .01)
            return;
        part.target = part.target ? 0 : 1;
        if (!part.target && part.fold)
            part.foldTarget = 0;
        this.stage.dataset.accessory = id;
        this.animateAccessories();
    }
    accessoryPose(id) {
        const part = this.accessoryMeshes.find(item => item.id === id);
        return part && part.progress > .98 && part.target === 1 ? { ...(part.inspection ?? { x: 0, y: 0, z: 0 }) } : null;
    }
    rotateAccessory(id, x, y, z) {
        if (!this.accessoryPose(id))
            return;
        this.accessoryMeshes.find(item => item.id === id).inspection = { x, y, z: z ?? this.accessoryPose(id)?.z ?? 0 };
        this.paint(this.pose);
    }
    paperFoldState(id) {
        const part = this.accessoryMeshes.find(item => item.id === id);
        return part?.fold ? part.foldProgress ?? 0 : null;
    }
    togglePaperFold(id) {
        const part = this.accessoryMeshes.find(item => item.id === id);
        if (!part?.fold || part.target !== 1)
            return;
        // A user can request unfolding while the sheet is being withdrawn; the
        // authored hinges begin only after the trailing edge leaves the pocket.
        part.foldTarget = part.foldTarget ? 0 : 1;
        this.animateAccessories();
    }
    /** Project the current independent component, used by rim-rotation gestures. */
    inspectionFrame(id) {
        const part = this.accessoryMeshes.find(p => p.id === id);
        const bounds = id === 'disc' ? this.discs?.inspectionBounds(this.pose.disc.index) : new THREE.Box3().makeEmpty();
        if (!bounds)
            return null;
        if (part && this.accessoryPose(id))
            part.group.traverse(node => {
                if (node instanceof THREE.Mesh && this.isVisible(node))
                    bounds.union(new THREE.Box3().setFromObject(node));
            });
        if (bounds.isEmpty())
            return null;
        const rect = this.stage.getBoundingClientRect();
        const pixels = this.projectBounds(bounds, rect.width, rect.height);
        return { x: rect.left + (pixels.left + pixels.right) / 2, y: rect.top + (pixels.top + pixels.bottom) / 2,
            width: pixels.right - pixels.left, height: pixels.bottom - pixels.top };
    }
    projectBounds(bounds, width, height) {
        const result = { left: Infinity, right: -Infinity, top: Infinity, bottom: -Infinity };
        for (const x of [bounds.min.x, bounds.max.x])
            for (const y of [bounds.min.y, bounds.max.y])
                for (const z of [bounds.min.z, bounds.max.z]) {
                    const v = new THREE.Vector3(x, y, z).project(this.camera), px = (v.x + 1) * width / 2, py = (1 - v.y) * height / 2;
                    result.left = Math.min(result.left, px);
                    result.right = Math.max(result.right, px);
                    result.top = Math.min(result.top, py);
                    result.bottom = Math.max(result.bottom, py);
                }
        return result;
    }
    animateAccessories() {
        if (this.accessoryAnimation)
            return;
        let previous = performance.now();
        const tick = (now) => {
            if (this.disposed)
                return;
            const dt = Math.min(.05, Math.max(0, (now - previous) / 1000));
            previous = now;
            let moving = false;
            for (const part of this.accessoryMeshes) {
                // Refold every leaf while fully withdrawn before the stack enters its slot.
                if (part.fold) {
                    if (!part.target)
                        part.foldTarget = 0;
                    const goal = part.progress >= 1 - 1e-6 ? part.foldTarget ?? 0 : 0;
                    part.foldProgress = (0, album_accessories_1.advanceAccessoryProgress)(part.foldProgress ?? 0, goal, dt, .9);
                    if (Math.abs(part.foldProgress - goal) < .0005)
                        part.foldProgress = goal;
                    else
                        moving = true;
                }
                const travelGoal = !part.target && (part.foldProgress ?? 0) > .0001 ? 1 : part.target;
                // Advance a reversible phase at a fixed rate. All physical transforms
                // use smooth path geometry; reverse playback retraces each same frame
                // instead of starting with an exponential full-speed return impulse.
                part.progress = (0, album_accessories_1.advanceAccessoryProgress)(part.progress, travelGoal, dt);
                if (Math.abs(part.progress - travelGoal) < .0005)
                    part.progress = travelGoal;
                else
                    moving = true;
                if (part.fold && part.target === 1 && Math.abs((part.foldTarget ?? 0) - (part.foldProgress ?? 0)) > .0005)
                    moving = true;
                (0, album_accessories_1.positionAccessory)(part);
            }
            this.stage.dataset.accessoryMoving = String(moving);
            this.stage.dataset.accessoryProgress = this.accessoryMeshes.map(p => p.id + '=' + p.progress.toFixed(3)).join(';');
            this.paint(this.pose);
            this.accessoryAnimation = moving ? requestAnimationFrame(tick) : 0;
        };
        this.accessoryAnimation = requestAnimationFrame(tick);
    }
    discIndex(object) {
        let slot = object.userData.discSlot;
        if (this.model.label.startsWith('Multi-CD')) {
            let rear = false;
            for (let node = object; node; node = node.parent)
                if (node.userData.rearChamber)
                    rear = true;
            const frontCount = Math.ceil(this.model.discs / 2);
            if (rear) {
                slot -= 2;
                return slot < this.model.discs - frontCount ? slot + frontCount : -1;
            }
            return slot < frontCount ? slot : -1;
        }
        return (0, album_model_assets_1.albumPanelDiscs)(this.model, object.userData.panel ?? 1)[slot] ?? -1;
    }
    placeholder(role, failed) {
        if (role.startsWith('disc') || role === 'spine' || role === 'insideSpine')
            return null;
        const canvas = document.createElement('canvas');
        canvas.width = canvas.height = 512;
        const context = canvas.getContext('2d');
        if (!context)
            return null;
        const swatch = document.createElement('span');
        swatch.className = 'album-surface-note';
        swatch.hidden = true;
        this.stage.append(swatch);
        const colors = getComputedStyle(swatch), background = colors.backgroundColor, foreground = colors.color;
        swatch.remove();
        context.fillStyle = background;
        context.fillRect(0, 0, 512, 512);
        context.fillStyle = foreground;
        context.font = '22px sans-serif';
        context.textAlign = 'center';
        const text = failed ? '贴图载入失败' : role === 'front' ? '暂无封面'
            : role === 'back' ? '示意背面' : role === 'outer' ? '示意外套' : '示意中面';
        context.fillText(text, 256, 267);
        const texture = new THREE.CanvasTexture(canvas);
        texture.flipY = false;
        texture.colorSpace = THREE.SRGBColorSpace;
        this.textures.add(texture);
        return texture;
    }
    async texture(role) {
        const source = (0, album_model_assets_1.albumTextureSource)(this.record, role);
        if (!source)
            return this.placeholder(role, false);
        try {
            if (!this.photoBitmaps.has(source))
                this.photoBitmaps.set(source, (async () => {
                    const response = await fetch(source, { signal: this.abort.signal });
                    if (!response.ok)
                        throw new Error('Photograph unavailable');
                    const bitmap = await createImageBitmap(await response.blob());
                    if (this.disposed) {
                        bitmap.close();
                        throw new Error('Viewer closed');
                    }
                    this.decodedPhotos.add(bitmap);
                    return bitmap;
                })());
            const original = await this.photoBitmaps.get(source);
            let bitmap = original;
            if (this.disposed)
                return null;
            let region = this.record.packaging?.photoRegions?.[role];
            let warpRows = this.record.modelWarpRows?.[role];
            // Crop each face's whole curved ROI in memory. Original source pixels and
            // task assets remain untouched; narrow spines get their own GPU budget.
            const givenDisc = role.startsWith('disc') ? this.record.modelDiscCalibrations?.[role] : undefined;
            const manualDisc = givenDisc && (0, album_disc_calibration_1.validDiscCalibration)(givenDisc) ? givenDisc : undefined;
            // Calibrations refer to the complete source, so never crop these first.
            const crop = manualDisc ? null : (0, album_photo_projection_1.photoTextureCrop)(bitmap.width, bitmap.height, region, warpRows);
            if (crop) {
                bitmap = await createImageBitmap(bitmap, crop.x, crop.y, crop.width, crop.height);
                region = crop.region;
                warpRows = crop.warpRows;
            }
            const limit = this.stage.clientWidth < 600 ? 1024 : 1536;
            const scale = Math.min(1, limit / Math.max(bitmap.width, bitmap.height));
            let canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(bitmap.width * scale));
            canvas.height = Math.max(1, Math.round(bitmap.height * scale));
            // Halftone print scans alias when a large photograph is reduced in one
            // bilinear step. Filter at each half-size before the final GPU texture.
            let input = bitmap;
            while (input.width > canvas.width * 2 || input.height > canvas.height * 2) {
                const half = document.createElement('canvas');
                half.width = Math.max(1, Math.ceil(input.width / 2));
                half.height = Math.max(1, Math.ceil(input.height / 2));
                const context = half.getContext('2d');
                context.imageSmoothingQuality = 'high';
                context.drawImage(input, 0, 0, half.width, half.height);
                if (input instanceof HTMLCanvasElement)
                    input.width = input.height = 1;
                input = half;
            }
            const context = canvas.getContext('2d');
            context.imageSmoothingQuality = 'high';
            context.drawImage(input, 0, 0, canvas.width, canvas.height);
            if (input instanceof HTMLCanvasElement)
                input.width = input.height = 1;
            if (bitmap !== original)
                bitmap.close();
            if (role.startsWith('disc')) {
                try {
                    const sourcePixels = context.getImageData(0, 0, canvas.width, canvas.height);
                    const ellipse = manualDisc ?? (0, album_disc_calibration_1.detectDiscEllipse)(sourcePixels.data, canvas.width, canvas.height);
                    const corrected = ellipse && (0, album_disc_calibration_1.rasterDisc)(sourcePixels.data, canvas.width, canvas.height, ellipse, Math.min(1024, Math.max(canvas.width, canvas.height)));
                    if (corrected) {
                        const rectified = document.createElement('canvas');
                        rectified.width = corrected.width;
                        rectified.height = corrected.height;
                        rectified.getContext('2d').putImageData(new ImageData(corrected.data, corrected.width, corrected.height), 0, 0);
                        canvas.width = canvas.height = 1;
                        canvas = rectified;
                        region = undefined;
                        warpRows = undefined;
                    }
                }
                catch { /* Keep the source if automatic rectification is unavailable. */ }
            }
            const texture = new THREE.CanvasTexture(canvas);
            texture.flipY = false;
            texture.colorSpace = THREE.SRGBColorSpace;
            texture.anisotropy = Math.min(4, this.renderer.capabilities.getMaxAnisotropy());
            texture.userData.photoSource = true;
            texture.userData.photoRegion = region;
            texture.userData.photoWarpRows = warpRows;
            this.textures.add(texture);
            return texture;
        }
        catch (error) {
            if (!this.disposed && this.record.assembly)
                throw error;
            return this.disposed ? null : this.placeholder(role, true);
        }
    }
    async applyTextures() {
        const active = new Set();
        this.conversion.traverse(object => {
            if (!(object instanceof THREE.Mesh) || !this.isVisible(object))
                return;
            for (const material of Array.isArray(object.material) ? object.material : [object.material])
                if (material instanceof THREE.MeshStandardMaterial && material.userData.role)
                    active.add(material);
        });
        const printed = [...active];
        const roles = [...new Set(printed.map(material => material.userData.role))];
        // A spread photograph can supply several calibrated faces. Decode it once
        // per lightbox; each printed material keeps its own projection matrix.
        const sources = new Map();
        const loaded = await Promise.all(roles.map(async (role) => {
            const source = (0, album_model_assets_1.albumTextureSource)(this.record, role);
            if (!source)
                return [role, this.placeholder(role, false)];
            const key = source + '/' + JSON.stringify([this.record.packaging?.photoRegions?.[role] ?? null, this.record.modelWarpRows?.[role] ?? null]);
            if (!sources.has(key))
                sources.set(key, this.texture(role));
            const texture = await sources.get(key);
            return [role, texture?.userData.photoSource ? texture : this.disposed ? null : this.placeholder(role, true)];
        }));
        for (const bitmap of this.decodedPhotos)
            bitmap.close();
        this.decodedPhotos.clear();
        this.photoBitmaps.clear();
        if (this.disposed) {
            this.releaseAssets();
            return;
        }
        const maps = new Map(loaded);
        // A calibrated spread includes the exposed paper at its centre fold. Use
        // its diffuse colour for the unprinted bag lining and cut/glued edges.
        const spineRole = this.record.modelTextures?.insideSpine || false ? 'insideSpine' : 'spine';
        const spineSource = (0, album_model_assets_1.albumTextureSource)(this.record, spineRole);
        const paperReference = maps.get(spineRole);
        const spineRegion = paperReference?.userData.photoRegion ?? this.record.packaging?.photoRegions?.[spineRole];
        const spineRows = paperReference?.userData.photoWarpRows;
        if (this.model.kind === 'gatefold' && this.model.pocketOpening === 'inner' && !this.model.slipcase
            && (spineRegion || spineRows) && paperReference?.userData.photoSource
            && spineSource === (0, album_model_assets_1.albumTextureSource)(this.record, 'insideLeft')
            && spineSource === (0, album_model_assets_1.albumTextureSource)(this.record, 'insideRight')) {
            const projection = spineRegion ? (0, album_photo_projection_1.photoProjection)(spineRegion) : null;
            const photograph = paperReference.image;
            const context = photograph.getContext('2d');
            if ((projection || spineRows) && context) {
                const channels = [[], [], []];
                for (let y = 1; y <= 5; y++)
                    for (let x = 1; x <= 5; x++) {
                        const u = x / 6, v = y / 6, q = projection ? projection[6] * u + projection[7] * v + 1 : 1;
                        const point = spineRows ? (0, album_photo_projection_1.photoWarpPoint)(spineRows, u, v) : projection ?
                            [(projection[0] * u + projection[1] * v + projection[2]) / q, (projection[3] * u + projection[4] * v + projection[5]) / q] : null;
                        if (!point)
                            continue;
                        const px = Math.min(photograph.width - 1, Math.max(0, Math.round(point[0] * photograph.width)));
                        const py = Math.min(photograph.height - 1, Math.max(0, Math.round(point[1] * photograph.height)));
                        const sample = context.getImageData(px, py, 1, 1).data;
                        channels.forEach((channel, i) => channel.push(sample[i]));
                    }
                const [r, g, b] = channels.map(channel => channel.sort((a, b) => a - b)[12] / 255);
                const color = new THREE.Color().setRGB(r, g, b, THREE.SRGBColorSpace);
                for (const material of this.materials)
                    if (material instanceof THREE.MeshStandardMaterial && /^Paper_(Cut|Wrap)/.test(material.name))
                        material.color.copy(color);
            }
        }
        for (const material of printed) {
            const role = material.userData.role;
            const source = maps.get(role);
            material.map = source?.clone() ?? null;
            if (material.map) {
                const image = source.image;
                const ratio = image.width / image.height, target = material.userData.ratio;
                const region = source.userData.photoRegion, rows = source.userData.photoWarpRows;
                if ((region || rows) && source.userData.photoSource)
                    (0, album_photo_material_1.projectPackagingPhoto)(material, region, rows);
                else if (ratio > target) {
                    material.map.repeat.x = target / ratio;
                    material.map.offset.x = (1 - material.map.repeat.x) / 2;
                }
                else {
                    material.map.repeat.y = ratio / target;
                    material.map.offset.y = (1 - material.map.repeat.y) / 2;
                }
                material.map.needsUpdate = true;
                this.textures.add(material.map);
            }
            material.color.setRGB(1, 1, 1);
            if (!material.map)
                material.color.setRGB(role === 'insideSpine' ? .72 : role.startsWith('disc') ? .6 : .3, role === 'insideSpine' ? .69 : role.startsWith('disc') ? .63 : .31, role === 'insideSpine' ? .61 : role.startsWith('disc') ? .65 : .3);
            material.needsUpdate = true;
        }
    }
    /** Materialize the same authored crease pose before measurement and drawing. */
    poseRig(progress) {
        // PropertyMixer may skip writing an unchanged track. Restore its unscaled
        // value before updating, so repeated hover/resize paints never accumulate.
        for (const fold of this.folds)
            fold.object.position.copy(fold.position);
        for (const { mixer, actions } of this.mixers) {
            for (const action of actions) {
                action.enabled = true;
                action.time = action.getClip().duration * progress;
            }
            mixer.update(0);
        }
        for (const fold of this.folds) {
            fold.position.copy(fold.object.position);
            fold.object.position.x *= fold.factor;
            fold.object.position.y *= fold.factor;
        }
        for (const update of this.calibratedFolds)
            update();
    }
    paint(pose) {
        this.pose = { ...pose, disc: { ...pose.disc }, hint: { ...pose.hint } };
        if (!this.ready || this.disposed || document.hidden)
            return;
        if (this.pendingClose && pose.disc.out < .01) {
            let needsReturn = false;
            for (const part of this.accessoryMeshes) {
                if (part.kind !== 'obi' && part.target !== 0) {
                    part.target = 0;
                    needsReturn = true;
                }
            }
            if (needsReturn)
                this.animateAccessories();
        }
        // A paper OBI wraps the cover and spine. The fold cannot move through it:
        // wait for the band to clear the hinge, then open over the remaining travel.
        const wrapping = this.accessoryMeshes.filter(part => part.kind === 'obi');
        const clearance = wrapping.length && pose.open > .01
            ? Math.min(...wrapping.map(part => part.progress)) : 1;
        const opening = Math.min(1, Math.max(0, (clearance - .55) / .42));
        const insertProgress = this.pendingClose
            ? Math.max(0, ...this.accessoryMeshes.filter(part => part.kind !== 'obi').map(part => part.progress)) : 0;
        const retreat = Math.min(1, Math.max(0, (insertProgress - .06) / .22));
        this.renderedOpen = Math.max(pose.open * (opening * opening * (3 - 2 * opening)), this.pendingClose ? retreat * retreat * (3 - 2 * retreat) : 0);
        const progress = this.model.slipcase ? Math.max(0, (this.renderedOpen - .45) / .55) : this.renderedOpen;
        this.poseRig(progress);
        if (this.slip) {
            this.slip.position.x = -this.slipWidth * Math.min(1, pose.open / .25);
            // Set the extracted sleeve below the hinge sweep before opening the case.
            this.slip.position.z = this.slipHeight * 1.05 * Math.max(0, Math.min(1, (pose.open - .25) / .2));
        }
        for (const part of this.accessoryMeshes) {
            // Undo last frame's independent world pose before measuring its mount.
            (0, album_accessories_1.positionAccessory)(part);
            (0, album_paper_fold_1.paintPaperFold)(part, part.foldProgress ?? 0);
            // Loose paper is enclosed by a closed jacket. A folded cover's rest
            // geometry is not itself a stencil, so hide the internal print until the
            // leaves separate; do not let hidden supplements affect picking/framing.
            part.group.visible = part.kind === 'obi' || !this.model.canOpen || this.renderedOpen > .35;
        }
        this.spin.position.set(0, 0, 0);
        this.spin.rotation.set(THREE.MathUtils.degToRad(-pose.x), THREE.MathUtils.degToRad(pose.y), 0);
        this.spin.updateMatrixWorld(true);
        this.box.makeEmpty();
        // Morph bounding boxes union every possible bend. Only the small spine
        // grids need precise current vertices; rigid parts keep their cheap bounds.
        for (const mesh of this.visibleMeshes) {
            if (!this.isVisible(mesh))
                continue;
            // Contents never determine the album center or camera framing.
            let accessory = false;
            for (let node = mesh; node; node = node.parent) {
                if (node.userData.accessoryId || typeof node.userData.discSlot === 'number') {
                    accessory = true;
                    break;
                }
            }
            if (!accessory)
                this.box.expandByObject(mesh, !!mesh.morphTargetInfluences?.length);
        }
        if (this.box.isEmpty())
            return;
        this.box.getCenter(this.center);
        this.box.getSize(this.size);
        this.spin.position.copy(this.center).multiplyScalar(-1);
        this.box.translate(this.spin.position);
        const slope = Math.tan(THREE.MathUtils.degToRad(this.camera.fov / 2));
        const width = this.stage.clientWidth || this.camera.aspect * 900, height = this.stage.clientHeight || 900;
        const cameraFocus = (0, album_insert_inspection_1.inspectionCameraComposition)(Math.max(0, ...this.accessoryMeshes.filter(part => part.kind === 'obi').map(part => part.progress)), Math.max(0, ...this.accessoryMeshes.filter(part => part.fold).map(part => part.foldProgress ?? 0)), width);
        const distance = (0, album_insert_inspection_1.workspaceDistance)(this.workspace, this.camera.aspect, pose.zoom, { width, height }) * cameraFocus.multiplier;
        // Translate camera and look target together; the album does not orbit.
        // Both directions use the same reversible progress-dependent composition.
        const framing = (0, album_presentation_1.albumCameraFraming)(this.record.presentation, 2 * distance * slope * this.camera.aspect, 2 * distance * slope);
        this.camera.position.set(cameraFocus.shiftX + framing.x, framing.y, distance);
        this.camera.near = Math.max(.002, distance * .12);
        this.camera.far = distance + this.workspace.radius * 5;
        this.camera.updateProjectionMatrix();
        this.camera.lookAt(cameraFocus.shiftX + framing.x, framing.y, 0);
        this.camera.updateMatrixWorld(true);
        const room = cameraFocus.multiplier;
        this.spin.updateMatrixWorld(true);
        for (const part of this.accessoryMeshes) {
            (0, album_insert_inspection_1.paintInsertInspection)(part, this.workspace, { width: this.stage.clientWidth || this.camera.aspect * 900, height: this.stage.clientHeight || 900, distance, slope });
            if (part.kind === 'inner-sleeve' && part.discIndex !== null) {
                part.group.updateMatrix();
                this.discs?.setSleeveTransform(part.discIndex, part.group.matrix.clone().multiply(new THREE.Matrix4().makeTranslation(-part.home.x, -part.home.y, -part.home.z)));
            }
        }
        this.discs?.reset(pose.disc);
        for (const part of this.accessoryMeshes)
            if (part.clipPlane && part.holder) {
                const planePoint = new THREE.Vector3(part.pocketMouthX ?? .064, 0, 0).applyMatrix4(part.holder.matrixWorld);
                // Keep the exposed +local X side of the physical pocket mouth.
                // The normal must match Three's shader clipping half-space.
                const normal = new THREE.Vector3(part.mouthDirection, 0, 0).transformDirection(part.holder.matrixWorld);
                part.clipPlane.setFromNormalAndCoplanarPoint(normal, planePoint);
            }
        this.discs?.paint(pose.disc, distance * pose.zoom, { slope, aspect: this.camera.aspect, bounds: this.box, inspectionFraction: Math.min(.62, (0, album_insert_inspection_1.inspectionCardPixels)(this.stage.clientWidth || this.camera.aspect * 900, this.stage.clientHeight || 900) * .82 / Math.min(this.stage.clientWidth || this.camera.aspect * 900, this.stage.clientHeight || 900)) }, pose.hint);
        this.renderer.render(this.world, this.camera);
        this.stage.dataset.progress = pose.open.toFixed(5);
        this.stage.dataset.packageProgress = progress.toFixed(5);
        this.stage.dataset.renderedOpen = this.renderedOpen.toFixed(5);
        this.stage.dataset.yaw = pose.y.toFixed(3);
        this.stage.dataset.pitch = pose.x.toFixed(3);
        this.stage.dataset.disc = pose.disc.out > 0 ? String(pose.disc.index + 1) : '';
        this.stage.dataset.discProgress = pose.disc.out.toFixed(5);
        this.stage.dataset.cameraDistance = distance.toFixed(5);
        this.stage.dataset.cameraRoom = room.toFixed(5);
        this.stage.dataset.discYaw = pose.disc.y.toFixed(3);
        this.stage.dataset.discRoll = (pose.disc.z ?? 0).toFixed(3);
        const pixels = this.projectBounds(this.box, this.stage.clientWidth || this.camera.aspect * 900, this.stage.clientHeight || 900);
        this.stage.dataset.packageWidth = (pixels.right - pixels.left).toFixed(2);
        this.stage.dataset.packageHeight = (pixels.bottom - pixels.top).toFixed(2);
        this.stage.dataset.discHint = pose.hint.amount > 0 ? String(pose.hint.index + 1) : '';
        this.stage.dataset.discHintProgress = pose.hint.amount.toFixed(5);
        this.stage.dataset.accessoryGrips = JSON.stringify(this.accessoryMeshes.filter(p => p.group.visible).map(p => {
            const v = p.group.localToWorld(p.grip.clone()).project(this.camera);
            return { id: p.id, x: (v.x + 1) * (this.stage.clientWidth || this.camera.aspect * 900) / 2,
                y: (1 - v.y) * (this.stage.clientHeight || 900) / 2, progress: p.progress };
        }));
        this.stage.dataset.paperFolds = this.accessoryMeshes.filter(p => p.fold).map(p => p.id + '=' + (p.foldProgress ?? 0).toFixed(3)).join(';');
        this.stage.dataset.accessoryRotations = this.accessoryMeshes.map(part => part.id + '=' + (part.inspection?.x ?? 0).toFixed(3) + ',' + (part.inspection?.y ?? 0).toFixed(3) + ',' + (part.inspection?.z ?? 0).toFixed(3)).join(';');
    }
    get discIndices() { return this.discs?.indices ?? []; }
    /** Only reachable CDs react; pocket proximity uses a fixed holder anchor. */
    hoverDisc(x, y, preferred = -1) {
        if (this.pose.disc.out > .001 || (this.model.canOpen && this.pose.open < 1))
            return undefined;
        return this.pick(x, y, 34, preferred)?.disc;
    }
    /** The visible paper edge is a finger-sized target, not a separate UI button.
     * Project its physical position through the same 3D camera as the model.
     */
    accessoryGripAt(x, y) {
        const rect = this.stage.getBoundingClientRect();
        let best, nearest = 23 * 23;
        this.spin.updateMatrixWorld(true);
        for (const part of this.accessoryMeshes) {
            if (part.kind === 'obi' || !part.group.visible || !this.accessoryReachable(part))
                continue;
            const point = part.group.localToWorld(part.grip.clone()).project(this.camera);
            if (point.z < -1 || point.z > 1)
                continue;
            const dx = (point.x + 1) * rect.width / 2 + rect.left - x;
            const dy = (1 - point.y) * rect.height / 2 + rect.top - y;
            const distance = dx * dx + dy * dy;
            if (distance < nearest) {
                nearest = distance;
                best = part.id;
            }
        }
        return best;
    }
    pick(x, y, gripRadius = 22, preferred = -1) {
        if (!this.ready || this.disposed)
            return null;
        const rect = this.stage.getBoundingClientRect();
        this.mouse.set((x - rect.left) / rect.width * 2 - 1, 1 - (y - rect.top) / rect.height * 2);
        this.ray.setFromCamera(this.mouse, this.camera);
        const reachable = !this.model.canOpen || this.renderedOpen > .9;
        const candidateGrip = reachable && this.pose.disc.out < .001
            ? this.discs?.gripAt(x - rect.left, y - rect.top, this.camera, rect.width, rect.height, gripRadius, preferred) : undefined;
        const grip = candidateGrip !== undefined && this.canTakeDisc(candidateGrip) ? candidateGrip : undefined;
        const insertGrip = this.accessoryGripAt(x, y);
        const hits = this.ray.intersectObjects(this.visibleMeshes, false);
        for (const hit of hits) {
            if (!this.isVisible(hit.object))
                continue;
            const clipped = this.accessoryMeshes.some(part => {
                if (!part.clipPlane || part.clipPlane.distanceToPoint(hit.point) >= -.0001)
                    return false;
                for (let n = hit.object; n; n = n.parent)
                    if (n === part.group)
                        return true;
                return false;
            });
            if (clipped)
                continue;
            for (let node = hit.object; node; node = node.parent) {
                if (!node.userData.accessoryId)
                    continue;
                const part = this.accessoryMeshes.find(part => part.id === node.userData.accessoryId);
                if (part && this.accessoryReachable(part))
                    return { accessory: part.id };
                // The closed lid owns access; an inaccessible insert is not clickable.
                return {};
            }
            const disc = this.discs?.owner(hit.object);
            if (disc !== undefined && reachable && this.canTakeDisc(disc))
                return { disc };
            const materials = hit.object.material;
            const material = Array.isArray(materials) ? materials[hit.face?.materialIndex ?? 0] : materials;
            if (material instanceof THREE.MeshPhysicalMaterial && material.transmission > .8)
                continue;
            return insertGrip ? { accessory: insertGrip } : grip !== undefined ? { disc: grip } : {};
        }
        return insertGrip ? { accessory: insertGrip }
            : grip !== undefined && this.canTakeDisc(grip) ? { disc: grip } : hits.length ? {} : null;
    }
    hits(x, y) { return this.pick(x, y) !== null; }
    resize() {
        const { clientWidth: width, clientHeight: height } = this.stage;
        if (!width || !height || this.disposed)
            return;
        this.renderer.setSize(width, height, false);
        this.camera.aspect = width / height;
        this.paint(this.pose);
    }
    releaseAssets() {
        for (const geometry of this.geometries)
            geometry.dispose();
        this.geometries.clear();
        for (const material of this.materials)
            material.dispose();
        this.materials.clear();
        for (const texture of this.textures)
            texture.dispose();
        this.textures.clear();
        for (const bitmap of this.decodedPhotos)
            bitmap.close();
        this.decodedPhotos.clear();
        this.photoBitmaps.clear();
    }
    dispose() {
        if (this.disposed)
            return;
        this.disposed = true;
        cancelAnimationFrame(this.accessoryAnimation);
        this.abort.abort();
        this.observer.disconnect();
        for (const { mixer } of this.mixers) {
            mixer.stopAllAction();
            for (const asset of this.assets)
                mixer.uncacheRoot(asset);
        }
        this.calibratedFolds.length = 0;
        this.discs?.dispose();
        this.releaseAssets();
        this.environmentMap.dispose();
        this.world.clear();
        this.renderer.dispose();
        this.renderer.forceContextLoss();
    }
}
exports.AlbumScene = AlbumScene;
