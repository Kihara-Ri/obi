"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.albumPanelDiscs = exports.albumModelAsset = void 0;
exports.packagingName = packagingName;
exports.albumPackaging = albumPackaging;
function packagingName(kind, spec = {}) {
    let name = kind === 'jewel' ? spec.thickness === 'slim' ? 'Slimline Jewel Case'
        : spec.thickness === 'thick' ? 'Multi-CD Jewel Case' : 'Jewel Case'
        : kind === 'card-sleeve' ? 'Card Sleeve'
            : kind === 'gatefold' ? (spec.panels ?? 2) === 2 ? 'Gatefold Sleeve' : 'Digisleeve'
                : kind === 'digipak' ? 'Digipak' : kind === 'digibook' ? 'Digibook'
                    : kind === 'rigid-box' ? 'Rigid Box' : '';
    if ((kind === 'gatefold' || kind === 'digipak') && (spec.panels ?? 2) > 2)
        name = (spec.panels ?? 2) * 2 + '-panel ' + name;
    if (spec.miniLP && kind === 'card-sleeve')
        name = 'Mini LP Sleeve';
    else if (spec.miniLP && name)
        name += ' · Mini LP';
    if (spec.slipcase && name)
        name += ' + Slipcase';
    return name;
}
/** A copy's explicit structure wins; legacy names supply conservative defaults only. */
function albumPackaging(spec = {}) {
    const data = spec;
    const kind = data.structure ?? 'unknown';
    const ratio = kind === 'jewel' ? 142.4 / 124.5 : kind === 'digipak' ? 1.1 : 1;
    const baseDepth = kind === 'jewel' ? data.thickness === 'thick' ? .16 : data.thickness === 'slim' ? .037 : .073
        : kind === 'rigid-box' ? .16 : kind === 'digibook' ? .09
            : kind === 'digipak' ? .045 : kind === 'gatefold' ? .026 : data.miniLP ? .02 : .012;
    const depth = kind !== 'jewel' && kind !== 'rigid-box' ? baseDepth * (data.thickness === 'slim' ? .7 : data.thickness === 'thick' ? 1.6 : 1) : baseDepth;
    const finish = data.finish ?? (kind === 'jewel' ? 'gloss' : 'matte');
    return {
        kind, label: packagingName(kind, data), thickness: data.thickness ?? 'standard', aspect: data.size ? data.size.width / data.size.height : ratio,
        depth: data.size ? data.size.depth / data.size.width : depth,
        gloss: finish === 'gloss' ? .85 : finish === 'matte' ? .2 : .08, finish,
        panels: data.panels ?? 2, pockets: data.pockets ?? 'right', pocketOpening: data.pocketOpening ?? 'outer',
        holder: data.holder ?? (kind === 'jewel' || kind === 'digipak' ? 'tray' : 'pocket'),
        tray: data.tray ?? (kind === 'jewel' ? 'black' : 'clear'), discs: data.discs ?? 1,
        miniLP: data.miniLP ?? false, slipcase: data.slipcase ?? false,
        canOpen: kind !== 'unknown' && kind !== 'card-sleeve' || !!data.slipcase,
    };
}
var album_model_metadata_1 = require("./album-model-metadata");
Object.defineProperty(exports, "albumModelAsset", { enumerable: true, get: function () { return album_model_metadata_1.albumModelAsset; } });
Object.defineProperty(exports, "albumPanelDiscs", { enumerable: true, get: function () { return album_model_metadata_1.albumPanelDiscs; } });
