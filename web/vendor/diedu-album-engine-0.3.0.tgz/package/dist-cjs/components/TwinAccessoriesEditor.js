"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TwinAccessoriesEditor = TwinAccessoriesEditor;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const generation_1 = require("../generation");
function TwinAccessoriesEditor({ photos, candidate, components, resolveSource, onSubmit, onClose }) {
    const images = (0, react_1.useMemo)(() => (0, generation_1.generationSources)(photos, candidate), [candidate, photos]);
    const ids = images.map(item => item.sourceId);
    const [selection, setSelection] = (0, react_1.useState)(() => {
        const mapped = {};
        for (const part of components) {
            mapped[part.kind] = (0, generation_1.sourceForAccessory)(part, ids);
        }
        return mapped;
    });
    const [saving, setSaving] = (0, react_1.useState)(false);
    const [error, setError] = (0, react_1.useState)('');
    if (!images.length)
        return (0, jsx_runtime_1.jsx)("p", { className: "small-note", children: "\u5F53\u524D\u5B9E\u4F53\u6CA1\u6709\u53EF\u590D\u7528\u7684\u5DF2\u6838\u9A8C\u56FE\u96C6\u6216\u5B9E\u7269\u7167\u7247\uFF0C\u6682\u4E0D\u80FD\u589E\u5220\u9644\u4EF6\u3002\u8BF7\u5148\u8865\u5145\u5B9E\u7269\u7167\u7247\u3002" });
    const save = async () => {
        if (saving)
            return;
        setSaving(true);
        setError('');
        try {
            await onSubmit((0, generation_1.buildAccessorySelections)(selection, components));
            onClose();
        }
        catch (err) {
            setError(err instanceof Error ? err.message : '附件保存失败');
        }
        finally {
            setSaving(false);
        }
    };
    return (0, jsx_runtime_1.jsxs)("section", { className: "twin-guided", "aria-label": "\u66F4\u65B0\u72EC\u7ACB\u5305\u88C5\u9644\u4EF6", children: [(0, jsx_runtime_1.jsx)("p", { className: "small-note", children: "\u8865\u5145\u6216\u79FB\u9664\u9644\u4EF6\uFF0C\u4E0D\u91CD\u65B0\u751F\u6210\u5C01\u5957\u548C CD\u3002\u53EA\u5141\u8BB8\u4F7F\u7528\u5DF2\u6838\u9A8C\u7684\u53D1\u884C\u7248\u539F\u56FE\u548C\u5F53\u524D\u5B9E\u7269\u7167\u7247\uFF1B\u672A\u9009\u62E9\u7684\u9644\u4EF6\u4E0D\u4F1A\u521B\u5EFA\u6A21\u578B\u3002" }), (0, jsx_runtime_1.jsx)("div", { className: "twin-guided-gallery", children: images.map(item => (0, jsx_runtime_1.jsxs)("figure", { children: [(0, jsx_runtime_1.jsx)("img", { alt: item.accessoryLabel, loading: "lazy", src: resolveSource(item.sourceId) }), (0, jsx_runtime_1.jsx)("figcaption", { children: item.accessoryLabel })] }, item.sourceId)) }), (0, jsx_runtime_1.jsx)("div", { className: "twin-guided-mapping", children: generation_1.GENERATION_PARTS.map(kind => (0, jsx_runtime_1.jsxs)("label", { children: [kind.shortLabel, (0, jsx_runtime_1.jsxs)("select", { value: selection[kind.kind] || '', onChange: e => setSelection(old => ({ ...old, [kind.kind]: e.target.value })), children: [(0, jsx_runtime_1.jsx)("option", { value: "", children: "\u65E0\u9644\u4EF6 / \u79FB\u9664" }), images.map(image => (0, jsx_runtime_1.jsxs)("option", { value: image.sourceId, children: [image.accessoryLabel, " \u00B7 ", image.sourceId] }, image.sourceId))] })] }, kind.kind)) }), error ? (0, jsx_runtime_1.jsx)("p", { role: "alert", className: "twin-error", children: error }) : null, (0, jsx_runtime_1.jsxs)("div", { className: "twin-generate-actions", children: [(0, jsx_runtime_1.jsx)("button", { type: "button", className: "primary", disabled: saving, onClick: () => void save(), children: saving ? '保存中…' : '保存附件' }), (0, jsx_runtime_1.jsx)("button", { type: "button", className: "quiet", disabled: saving, onClick: onClose, children: "\u53D6\u6D88" })] })] });
}
