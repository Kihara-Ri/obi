"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumModel = AlbumModel;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const album_packaging_1 = require("../core/album-packaging");
const album_model_assets_1 = require("../core/album-model-assets");
const album_presentation_1 = require("../core/album-presentation");
const album_inspection_input_1 = require("../core/album-inspection-input");
const album_disc_motion_1 = require("../core/album-disc-motion");
const useAlbumOrientation_1 = require("./useAlbumOrientation");
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
/** One lazy WebGL scene per lightbox; gallery tracks retain their small CSS proxies. */
function AlbumModel({ record, permission, onDismiss, onUnavailable, lifecycle }) {
    return (0, jsx_runtime_1.jsx)(AlbumModelSession, { lifecycle: lifecycle, record: record, permission: permission, onDismiss: onDismiss, onUnavailable: onUnavailable }, (0, album_model_assets_1.albumSceneIdentity)(record));
}
function AlbumModelSession({ record, permission, onDismiss, onUnavailable, lifecycle }) {
    const stage = (0, react_1.useRef)(null);
    const [input] = (0, react_1.useState)(() => ({ record, model: (0, album_packaging_1.albumPackaging)(record.packaging) }));
    const scene = (0, react_1.useRef)(null);
    const [initialPose] = (0, react_1.useState)(() => (0, album_presentation_1.initialAlbumPose)(record.presentation));
    const pose = (0, react_1.useRef)(initialPose);
    const base = (0, react_1.useRef)({ x: initialPose.x, y: initialPose.y });
    const discBase = (0, react_1.useRef)({ x: -8, y: -12, z: 0 });
    const selectedAccessory = (0, react_1.useRef)(null);
    const accessoryBase = (0, react_1.useRef)({ x: 0, y: 0, z: 0 });
    const clickTimer = (0, react_1.useRef)(0);
    const offset = (0, react_1.useRef)({ x: 0, y: 0 });
    const target = (0, react_1.useRef)({ x: initialPose.x, y: initialPose.y, open: 0, discOut: 0, hintIndex: -1 });
    const mouse = (0, react_1.useRef)(null);
    const nextDisc = (0, react_1.useRef)(null);
    const discMotionState = (0, react_1.useRef)({ out: 0, velocity: 0 });
    const closeAfterReturn = (0, react_1.useRef)(false);
    const requestedOpen = (0, react_1.useRef)(false);
    const frame = (0, react_1.useRef)(0);
    const reduced = (0, react_1.useRef)(false);
    const live = (0, react_1.useRef)(!document.hidden);
    const drag = (0, react_1.useRef)(null);
    const tapCase = (0, react_1.useRef)(null);
    const trailing = (0, react_1.useRef)(false);
    const [dragging, setDragging] = (0, react_1.useState)(false);
    const [failed, setFailed] = (0, react_1.useState)(false);
    const unavailable = (0, react_1.useRef)(onUnavailable);
    unavailable.current = onUnavailable;
    const [opened, setOpened] = (0, react_1.useState)(false);
    const [ready, setReady] = (0, react_1.useState)(false);
    const [discStatus, setDiscStatus] = (0, react_1.useState)('');
    const [paperTools, setPaperTools] = (0, react_1.useState)(null);
    const [inspecting, setInspecting] = (0, react_1.useState)(false);
    const model = input.model;
    const move = (0, react_1.useCallback)((instant = false) => {
        if (lifecycle?.aborted)
            return;
        target.current.x = clamp(base.current.x + offset.current.x, -72, 72);
        target.current.y = base.current.y + offset.current.y;
        if (instant || reduced.current) {
            pose.current.x = target.current.x;
            pose.current.y = target.current.y;
        }
        if (reduced.current)
            pose.current.open = target.current.open;
        // Direct manipulation must paint synchronously even while an opening or
        // extraction animation owns the next RAF. Otherwise keyboard/pointer
        // rotations appear frozen until the compositor schedules another frame.
        if (instant)
            scene.current?.paint(pose.current);
        if (!live.current || frame.current)
            return;
        let previous = performance.now();
        const tick = (now) => {
            const dt = clamp((now - previous) / 1000, 0, .05);
            previous = now;
            const shown = pose.current, goal = target.current;
            const amount = 1 - Math.exp(-20 * dt);
            shown.x += (goal.x - shown.x) * amount;
            shown.y += (goal.y - shown.y) * amount;
            shown.open += (goal.open - shown.open) * (reduced.current ? 1 : 1 - Math.exp(-12 * dt));
            const discMotion = reduced.current ? { out: goal.discOut, velocity: 0 }
                : (0, album_disc_motion_1.advanceDiscMotion)(discMotionState.current, goal.discOut, dt);
            shown.disc.out = discMotion.out;
            discMotionState.current = discMotion;
            let hintGoal = shown.hint.index === goal.hintIndex && goal.hintIndex >= 0 ? 1 : 0;
            if (goal.discOut && shown.disc.index === shown.hint.index && shown.disc.out < .52)
                hintGoal = shown.hint.amount;
            shown.hint.amount += (hintGoal - shown.hint.amount) * (1 - Math.exp(-16 * dt));
            if (Math.abs(hintGoal - shown.hint.amount) < .001) {
                shown.hint.amount = hintGoal;
                if (!hintGoal)
                    shown.hint.index = goal.hintIndex;
            }
            if (discMotionState.current.from === undefined && Math.abs(goal.discOut - shown.disc.out) < .001) {
                shown.disc.out = goal.discOut;
                discMotionState.current = { out: goal.discOut, velocity: 0 };
                if (!goal.discOut) {
                    if (nextDisc.current !== null) {
                        shown.disc = { index: nextDisc.current, out: 0, x: -8, y: -12 };
                        goal.discOut = 1;
                        nextDisc.current = null;
                        discMotionState.current = { out: 0, velocity: 0 };
                        discBase.current = { x: -8, y: -12 };
                    }
                    else {
                        setInspecting(false);
                        if (closeAfterReturn.current) {
                            goal.open = 0;
                            closeAfterReturn.current = false;
                        }
                    }
                }
            }
            const caseSettled = Math.abs(goal.x - shown.x) + Math.abs(goal.y - shown.y) < .02
                && Math.abs(goal.open - shown.open) < .001 && discMotionState.current.from === undefined
                && Math.abs(goal.discOut - shown.disc.out) < .001;
            if (caseSettled) {
                shown.x = goal.x;
                shown.y = goal.y;
                shown.open = goal.open;
            }
            scene.current?.paint(shown);
            // Recheck after tilting: the pointer can stay still while the package moves.
            const pointer = mouse.current;
            if (pointer && !drag.current && !goal.discOut && !reduced.current) {
                goal.hintIndex = scene.current?.hoverDisc(pointer.x, pointer.y, goal.hintIndex) ?? -1;
            }
            if (stage.current)
                stage.current.dataset.discHover = String(goal.hintIndex >= 0);
            const settled = caseSettled && shown.hint.index === goal.hintIndex
                && Math.abs((goal.hintIndex >= 0 ? 1 : 0) - shown.hint.amount) < .001;
            frame.current = settled ? 0 : requestAnimationFrame(tick);
        };
        frame.current = requestAnimationFrame(tick);
    }, [lifecycle]);
    const onTilt = (0, react_1.useCallback)((x, y) => {
        const insert = selectedAccessory.current;
        if (insert && scene.current?.accessoryPose(insert)) {
            scene.current.rotateAccessory(insert, clamp(accessoryBase.current.x + x, -65, 65), accessoryBase.current.y + y, accessoryBase.current.z ?? 0);
        }
        else if (pose.current.disc.out > 0 || target.current.discOut) {
            pose.current.disc.x = clamp(discBase.current.x + x, -65, 65);
            pose.current.disc.y = discBase.current.y + y;
        }
        else
            offset.current = { x, y };
        move();
    }, [move]);
    const motion = (0, useAlbumOrientation_1.useAlbumOrientation)({ lifecycle, active: ready && !dragging && !failed, permission, onTilt });
    (0, react_1.useEffect)(() => {
        let alive = true;
        const space = stage.current;
        if (!space || failed || lifecycle?.aborted)
            return;
        // Disposal intentionally loses its GL context. Never reuse that canvas,
        // including React's effect replay or late context-loss events after cleanup.
        const surface = document.createElement('canvas');
        surface.className = 'album-webgl-canvas';
        surface.setAttribute('aria-hidden', 'true');
        space.prepend(surface);
        setReady(false);
        let owned = null;
        const wheel = (event) => {
            event.preventDefault();
            pose.current.zoom = clamp(pose.current.zoom * Math.exp(-event.deltaY * .001), .7, 2);
            move();
        };
        const unavailableModel = () => {
            if (!alive)
                return;
            setFailed(true);
            setReady(false);
            unavailable.current?.();
        };
        const contextLost = (event) => { event.preventDefault(); unavailableModel(); };
        space.addEventListener('wheel', wheel, { passive: false });
        surface.addEventListener('webglcontextlost', contextLost);
        void Promise.resolve().then(() => __importStar(require('../core/album-scene'))).then(async ({ AlbumScene }) => {
            if (!alive)
                return;
            const instance = new AlbumScene(space, surface, input.record, input.model);
            owned = instance;
            scene.current = instance;
            await instance.load();
            if (alive) {
                instance.paint(pose.current);
                setReady(true);
            }
        }).catch(() => {
            owned?.dispose();
            if (alive) {
                scene.current = null;
                unavailableModel();
            }
        });
        const cleanup = () => {
            lifecycle?.removeEventListener('abort', cleanup);
            alive = false;
            space.removeEventListener('wheel', wheel);
            surface.removeEventListener('webglcontextlost', contextLost);
            owned?.dispose();
            if (scene.current === owned)
                scene.current = null;
            surface.remove();
        };
        lifecycle?.addEventListener('abort', cleanup, { once: true });
        return cleanup;
    }, [input, failed, move, lifecycle]);
    (0, react_1.useEffect)(() => {
        if (lifecycle?.aborted)
            return;
        const media = matchMedia('(prefers-reduced-motion: reduce)');
        const preference = () => {
            reduced.current = media.matches;
            offset.current = { x: 0, y: 0 };
            mouse.current = null;
            target.current.hintIndex = -1;
            pose.current.hint = { index: -1, amount: 0 };
            move(true);
        };
        const visibility = () => {
            live.current = !document.hidden;
            if (!live.current) {
                mouse.current = null;
                target.current.hintIndex = -1;
                pose.current.hint = { index: -1, amount: 0 };
                cancelAnimationFrame(frame.current);
                frame.current = 0;
            }
            else
                move(true);
        };
        preference();
        media.addEventListener('change', preference);
        document.addEventListener('visibilitychange', visibility);
        const cleanup = () => {
            lifecycle?.removeEventListener('abort', cleanup);
            const pointer = drag.current;
            if (pointer && stage.current?.hasPointerCapture(pointer.id))
                stage.current.releasePointerCapture(pointer.id);
            drag.current = null;
            cancelAnimationFrame(frame.current);
            frame.current = 0;
            window.clearTimeout(clickTimer.current);
            media.removeEventListener('change', preference);
            document.removeEventListener('visibilitychange', visibility);
        };
        lifecycle?.addEventListener('abort', cleanup, { once: true });
        return cleanup;
    }, [move, lifecycle]);
    const clearHint = () => {
        mouse.current = null;
        target.current.hintIndex = -1;
        if (stage.current)
            stage.current.dataset.accessoryHover = '';
    };
    const stopDrag = () => {
        const pointer = drag.current;
        if (pointer?.moved)
            trailing.current = true;
        drag.current = null;
        setDragging(false);
        if (pointer && stage.current?.hasPointerCapture(pointer.id))
            stage.current.releasePointerCapture(pointer.id);
        motion.recalibrate();
    };
    const down = (event) => {
        tapCase.current = null;
        const previouslyHovered = stage.current?.dataset.accessoryHover || null;
        clearHint();
        move();
        if (!event.isPrimary) {
            stopDrag();
            trailing.current = true;
            return;
        }
        trailing.current = false;
        if (!ready || event.button !== 0 || event.clientX < 28 || drag.current)
            return;
        const picked = scene.current?.pick(event.clientX, event.clientY);
        // Pointer-hover and pointerdown may bracket a parallax/hinge frame.
        // Keep the actual hovered paper target across this click rather than
        // dismissing the lightbox when the ray slides off its narrow grip.
        const hit = previouslyHovered && !picked?.accessory && picked?.disc === undefined
            ? { accessory: previouslyHovered } : picked;
        if (!hit)
            return;
        tapCase.current = hit;
        const insert = hit.accessory ? scene.current?.accessoryPose(hit.accessory) : null;
        selectedAccessory.current = hit.accessory ?? null;
        const inspecting = hit.disc === pose.current.disc.index && pose.current.disc.out > .95;
        if (insert) {
            accessoryBase.current = insert;
            // Freeze the current album pose when a free object takes pointer ownership.
            base.current = { x: pose.current.x, y: pose.current.y };
            offset.current = { x: 0, y: 0 };
            move(true);
        }
        else if (inspecting)
            discBase.current = { x: pose.current.disc.x, y: pose.current.disc.y };
        else {
            base.current = { x: pose.current.x, y: pose.current.y };
            offset.current = { x: 0, y: 0 };
        }
        const inspectionFrame = insert ? scene.current?.inspectionFrame(hit.accessory) : inspecting ? scene.current?.inspectionFrame('disc') : null;
        const rim = inspectionFrame && (0, album_inspection_input_1.inspectionRim)(inspectionFrame, event.clientX, event.clientY);
        drag.current = { id: event.pointerId, x: event.clientX, y: event.clientY,
            rx: insert?.x ?? (inspecting ? pose.current.disc.x : base.current.x), ry: insert?.y ?? (inspecting ? pose.current.disc.y : base.current.y),
            rz: insert?.z ?? (inspecting ? pose.current.disc.z ?? 0 : 0),
            ...(inspectionFrame && (rim || event.shiftKey) ? { roll: { x: inspectionFrame.x, y: inspectionFrame.y,
                    angle: Math.atan2(inspectionFrame.y - event.clientY, event.clientX - inspectionFrame.x), linear: event.shiftKey } } : {}),
            width: event.currentTarget.clientWidth, moved: false, disc: inspecting, accessory: insert ? hit.accessory : undefined };
        if (stage.current) {
            stage.current.dataset.rotationTarget = insert ? hit.accessory : inspecting ? 'disc' : 'album';
            stage.current.dataset.rotationMode = drag.current.roll ? 'roll' : 'orbit';
        }
        setDragging(true);
        event.currentTarget.focus({ preventScroll: true });
        event.currentTarget.setPointerCapture(event.pointerId);
    };
    const pointerMove = (event) => {
        const start = drag.current;
        if (start?.id === event.pointerId) {
            if (Math.hypot(event.clientX - start.x, event.clientY - start.y) > 6)
                start.moved = true;
            const rotation = { x: clamp(start.rx - (event.clientY - start.y) / start.width * 150, -65, 65),
                y: start.ry + (event.clientX - start.x) / start.width * (start.disc || start.accessory ? 360 : 220), z: start.rz };
            if (start.roll) {
                rotation.x = start.rx;
                rotation.y = start.ry;
                if (start.roll.linear)
                    rotation.z = start.rz + (event.clientX - start.x) / start.width * 360;
                else {
                    const angle = Math.atan2(start.roll.y - event.clientY, event.clientX - start.roll.x);
                    start.rz += (0, album_inspection_input_1.rotationDelta)(start.roll.angle, angle);
                    start.roll.angle = angle;
                    rotation.z = start.rz;
                }
            }
            if (start.accessory) {
                scene.current?.rotateAccessory(start.accessory, rotation.x, rotation.y, rotation.z);
                accessoryBase.current = rotation;
            }
            else if (start.disc) {
                pose.current.disc.x = rotation.x;
                pose.current.disc.y = rotation.y;
                pose.current.disc.z = rotation.z;
                discBase.current = rotation;
            }
            else
                base.current = rotation;
            move(true);
            return;
        }
        if (!ready || event.pointerType !== 'mouse' || event.buttons || reduced.current || inspecting) {
            clearHint();
            move();
            return;
        }
        mouse.current = { x: event.clientX, y: event.clientY };
        const hovered = scene.current?.pick(event.clientX, event.clientY, 34, target.current.hintIndex);
        target.current.hintIndex = hovered?.disc ?? -1;
        if (stage.current) {
            stage.current.dataset.accessoryHover = hovered?.accessory ?? '';
            stage.current.dataset.discHover = String(hovered?.disc !== undefined);
        }
        if (hovered?.accessory) {
            // Hold the grip still for mounted as well as free paper. Hover-driven
            // parallax otherwise moves the target away between hover and mousedown.
            offset.current = { x: 0, y: 0 };
        }
        else if (!motion.intended) {
            const rect = event.currentTarget.getBoundingClientRect();
            offset.current = { x: (.5 - clamp((event.clientY - rect.top) / rect.height, 0, 1)) * 24,
                y: (clamp((event.clientX - rect.left) / rect.width, 0, 1) - .5) * 32 };
        }
        move();
    };
    const toggle = () => {
        if (!ready || !model.canOpen)
            return;
        clearHint();
        requestedOpen.current = !requestedOpen.current;
        if (requestedOpen.current)
            scene.current?.releaseWrapBeforeOpen();
        else
            scene.current?.prepareForClose();
        closeAfterReturn.current = !requestedOpen.current && pose.current.disc.out > 0;
        nextDisc.current = null;
        if (!requestedOpen.current) {
            target.current.discOut = 0;
            setDiscStatus('');
        }
        target.current.open = closeAfterReturn.current ? 1 : Number(requestedOpen.current);
        setOpened(requestedOpen.current);
        move();
    };
    const takeDisc = (index) => {
        if (!ready || (model.canOpen && (!requestedOpen.current || pose.current.open < .9))
            || !scene.current?.discIndices.includes(index) || !scene.current.canTakeDisc(index))
            return;
        clearHint();
        selectedAccessory.current = null;
        closeAfterReturn.current = false;
        const disc = pose.current.disc;
        setInspecting(true);
        if (disc.index === index && target.current.discOut) {
            target.current.discOut = 0;
            nextDisc.current = null;
            setDiscStatus('CD ' + (index + 1) + ' 放回原位');
        }
        else if (disc.out > 0 && disc.index !== index) {
            target.current.discOut = 0;
            nextDisc.current = index;
            setDiscStatus('CD ' + (index + 1) + ' 取出查看');
        }
        else {
            if (disc.index !== index || !disc.out) {
                pose.current.disc = { index, out: 0, x: -8, y: -12 };
                discBase.current = { x: -8, y: -12 };
            }
            target.current.discOut = 1;
            nextDisc.current = null;
            setDiscStatus('CD ' + (index + 1) + ' 取出查看');
        }
        offset.current = { x: 0, y: 0 };
        move();
    };
    const key = (event) => {
        if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey)
            return;
        if (/^[1-4]$/.test(event.key)) {
            event.preventDefault();
            event.stopPropagation();
            takeDisc(Number(event.key) - 1);
            return;
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            event.stopPropagation();
            if (selectedAccessory.current && scene.current?.accessoryPose(selectedAccessory.current)) {
                scene.current.toggleAccessory(selectedAccessory.current);
                setPaperTools(null);
            }
            else if (target.current.discOut)
                takeDisc(pose.current.disc.index);
            else
                toggle();
            return;
        }
        if (event.key.toLowerCase() === 'f' && selectedAccessory.current && scene.current?.paperFoldState(selectedAccessory.current) !== null) {
            event.preventDefault();
            event.stopPropagation();
            scene.current?.togglePaperFold(selectedAccessory.current);
            setPaperTools(current => current?.id === selectedAccessory.current ? { ...current, expanded: !current.expanded } : current);
            return;
        }
        const insert = selectedAccessory.current ? scene.current?.accessoryPose(selectedAccessory.current) : null;
        const rotation = insert ?? (pose.current.disc.out > .95 ? pose.current.disc : base.current);
        if (event.key === 'Home') {
            event.preventDefault();
            rotation.x = 0;
            rotation.y = Math.round(rotation.y / 360) * 360;
            rotation.z = 0;
            pose.current.zoom = 1;
        }
        else if ((event.key.toLowerCase() === 'q' || event.key.toLowerCase() === 'e') && (insert || pose.current.disc.out > .95)) {
            event.preventDefault();
            event.stopPropagation();
            rotation.z = (rotation.z ?? 0) + (event.key.toLowerCase() === 'e' ? 90 : -90);
        }
        else if (event.key.startsWith('Arrow')) {
            event.preventDefault();
            event.stopPropagation();
            rotation.x = clamp(rotation.x + (event.key === 'ArrowUp' ? 15 : event.key === 'ArrowDown' ? -15 : 0), -65, 65);
            rotation.y += event.key === 'ArrowRight' ? 25 : event.key === 'ArrowLeft' ? -25 : 0;
        }
        else
            return;
        clearHint();
        if (insert && selectedAccessory.current) {
            scene.current?.rotateAccessory(selectedAccessory.current, rotation.x, rotation.y, rotation.z ?? 0);
            accessoryBase.current = rotation;
        }
        else if (pose.current.disc.out > .95) {
            pose.current.disc.z = rotation.z ?? 0;
            discBase.current = { ...rotation };
        }
        offset.current = { x: 0, y: 0 };
        motion.recalibrate();
        move(true);
    };
    if (failed)
        return (0, jsx_runtime_1.jsx)("div", { className: "album-model-unavailable", role: "status", children: "\u5F53\u524D\u8BBE\u5907\u65E0\u6CD5\u663E\u793A 3D \u6A21\u578B" });
    return (0, jsx_runtime_1.jsxs)("div", { className: "album-viewer", children: [(0, jsx_runtime_1.jsxs)("div", { className: `album-model-scene album-webgl-scene${dragging ? ' is-dragging' : ''}`, ref: stage, role: "group", tabIndex: 0, "aria-label": `3D 专辑：${record.title}`, "aria-expanded": model.canOpen ? opened : undefined, "aria-busy": !ready, "aria-description": "\u62D6\u52A8\u6216\u65B9\u5411\u952E\u65CB\u8F6C\u3002\u53D6\u51FA\u7684\u4FA7\u6807\u3001\u6B4C\u8BCD\u518C\u3001\u5185\u888B\u548C CD \u53EF\u5404\u81EA\u72EC\u7ACB\u65CB\u8F6C\uFF1B\u62D6\u52A8\u8FB9\u7F18\u6216\u6309\u4F4F Shift \u62D6\u52A8\u53EF\u8F6C\u6B63\u6587\u5B57\uFF0CQ/E \u6BCF\u6B21\u65CB\u8F6C90\u5EA6\uFF0CHome \u56DE\u6B63\u3002\u6298\u9875\u53D6\u51FA\u540E\u5355\u51FB\u7EB8\u9762\u6216\u6309 F \u5C55\u5F00/\u6298\u8D77\uFF0C\u4F7F\u7528\u53EF\u89C1\u7684\u6536\u56DE\u6309\u94AE\u653E\u56DE\u6298\u9875\u3002\u70B9\u51FB\u5305\u88C5\u5F00\u5408\uFF0C\u70B9\u51FB\u5176\u4ED6\u5185\u5BB9\u7269\u53D6\u51FA\u6216\u653E\u56DE\u3002\u5148\u5C55\u5F00\u5305\u88C5\u624D\u80FD\u53D6\u51FA\u5185\u90E8\u7EB8\u4EF6\uFF1B\u5185\u888B\u62BD\u51FA\u540E\u624D\u80FD\u53D6\u51FA\u5176\u4E2D CD\u3002\u6570\u5B57\u952E\u53D6\u653E\u5BF9\u5E94 CD\uFF1B\u6EDA\u8F6E\u653E\u5927\uFF0CHome \u56DE\u6B63\uFF0CEsc \u5173\u95ED\u3002", onKeyDown: key, onDragStart: event => event.preventDefault(), onPointerDown: down, onPointerMove: pointerMove, onPointerUp: stopDrag, onPointerCancel: () => { clearHint(); move(); tapCase.current = null; stopDrag(); trailing.current = true; }, onLostPointerCapture: () => { if (drag.current) {
                    clearHint();
                    move();
                    tapCase.current = null;
                    stopDrag();
                    trailing.current = true;
                } }, onPointerLeave: () => { clearHint(); if (!drag.current && !motion.intended)
                    offset.current = { x: 0, y: 0 }; move(); }, onClick: event => {
                    const startedOnCase = tapCase.current;
                    tapCase.current = null;
                    if (trailing.current) {
                        trailing.current = false;
                        event.preventDefault();
                        event.stopPropagation();
                        return;
                    }
                    if (event.detail !== 0 && !startedOnCase) {
                        if (ready && !scene.current?.hits(event.clientX, event.clientY))
                            onDismiss();
                        return;
                    }
                    if (startedOnCase?.accessory) {
                        const id = startedOnCase.accessory;
                        const foldedSheet = input.record.modelAccessories?.find(part => part.id === id && part.kind === 'booklet' && part.fold);
                        if (foldedSheet?.fold) {
                            if (scene.current?.accessoryPose(id)) {
                                // A free folded sheet is a physical fold, not a button to stow it.
                                // The separate, visible "收回" control handles insertion.
                                scene.current.togglePaperFold(id);
                                setPaperTools(current => ({ id, panels: foldedSheet.fold.panels, expanded: current?.id === id ? !current.expanded : true }));
                            }
                            else {
                                scene.current?.toggleAccessory(id);
                                setPaperTools({ id, panels: foldedSheet.fold.panels, expanded: false });
                            }
                        }
                        else {
                            scene.current?.toggleAccessory(id);
                            setPaperTools(null);
                        }
                    }
                    else if (startedOnCase?.disc !== undefined)
                        takeDisc(startedOnCase.disc);
                    else
                        toggle();
                }, children: [!ready ? (0, jsx_runtime_1.jsxs)("div", { className: "album-model-loading", role: "status", "aria-live": "polite", children: [(0, jsx_runtime_1.jsx)("span", { className: "album-model-loading-spinner", "aria-hidden": "true" }), (0, jsx_runtime_1.jsx)("span", { children: "\u6B63\u5728\u52A0\u8F7D\u4E13\u8F91\u6A21\u578B" })] }) : null, (0, jsx_runtime_1.jsx)("span", { className: "album-model-status", role: "status", children: discStatus })] }), paperTools && ready ? (0, jsx_runtime_1.jsxs)("div", { className: "album-paper-tools", role: "group", "aria-label": `${paperTools.panels} 联折页查看`, children: [(0, jsx_runtime_1.jsxs)("span", { className: "album-paper-tools-label", children: [paperTools.panels, " \u8054\u6298\u9875 \u00B7 \u70B9\u51FB\u7EB8\u9762", paperTools.expanded ? '折起' : '展开'] }), (0, jsx_runtime_1.jsx)("button", { type: "button", "aria-label": paperTools.expanded ? '折起纸张' : '展开纸张', onClick: () => {
                            selectedAccessory.current = paperTools.id;
                            scene.current?.togglePaperFold(paperTools.id);
                            setPaperTools(current => current?.id === paperTools.id ? { ...current, expanded: !current.expanded } : current);
                        }, children: paperTools.expanded ? '折起' : '展开' }), (0, jsx_runtime_1.jsx)("button", { type: "button", "aria-label": "\u6536\u56DE\u7EB8\u5F20", onClick: () => {
                            scene.current?.toggleAccessory(paperTools.id);
                            selectedAccessory.current = null;
                            setPaperTools(null);
                        }, children: "\u6536\u56DE" })] }) : null] });
}
