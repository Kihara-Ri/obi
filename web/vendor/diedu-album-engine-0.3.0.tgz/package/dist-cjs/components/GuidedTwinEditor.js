"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GuidedTwinEditor = GuidedTwinEditor;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const generation_1 = require("../generation");
function GuidedTwinEditor({ candidate, photos, initialSurfaces, resolveSource, onSubmit, disabled = false }) {
    const choices = (0, react_1.useMemo)(() => (0, generation_1.generationSources)(photos, candidate), [candidate, photos]);
    const [kind, setKind] = (0, react_1.useState)(() => (0, generation_1.inferGenerationPackaging)(candidate?.packaging));
    const [miniLP, setMiniLP] = (0, react_1.useState)(false);
    const [confirmedMismatch, setConfirmedMismatch] = (0, react_1.useState)(false);
    const [faces, setFaces] = (0, react_1.useState)(() => (0, generation_1.initialGenerationSurfaces)(initialSurfaces, choices));
    const [accessories, setAccessories] = (0, react_1.useState)({});
    const [busy, setBusy] = (0, react_1.useState)(false);
    const [error, setError] = (0, react_1.useState)('');
    if (!candidate)
        return (0, jsx_runtime_1.jsx)("p", { className: "small-note", children: "\u7B49\u5F85\u786E\u8BA4\u53D1\u884C\u7248\u56FE\u96C6\u6570\u636E\u3002" });
    const count = candidate.discCount || 1;
    const roles = (0, generation_1.generationRoles)(kind, count);
    const fromRelease = (0, generation_1.inferGenerationPackaging)(candidate.packaging);
    const mismatch = !!kind && !!fromRelease && fromRelease !== kind;
    const selection = (0, generation_1.buildGuidedSelection)(candidate, kind, miniLP, confirmedMismatch, faces, accessories, choices);
    const valid = selection !== null;
    const submit = async () => {
        if (!valid || busy)
            return;
        setBusy(true);
        setError('');
        try {
            await onSubmit(selection);
        }
        catch (exc) {
            setError(exc instanceof Error ? exc.message : '图源确认失败');
        }
        finally {
            setBusy(false);
        }
    };
    const options = ((0, jsx_runtime_1.jsxs)(jsx_runtime_1.Fragment, { children: [(0, jsx_runtime_1.jsx)("option", { value: "", children: "\u8BF7\u786E\u8BA4\u56FE\u6E90" }), choices.map(choice => (0, jsx_runtime_1.jsxs)("option", { value: choice.sourceId, children: [choice.guidedLabel, " \u00B7 ", choice.sourceId] }, choice.sourceId))] }));
    return (0, jsx_runtime_1.jsxs)("section", { className: "twin-guided", "aria-label": "\u4EBA\u5DE5\u786E\u8BA4\u6570\u5B57\u5B9E\u4F53\u7D20\u6750", children: [(0, jsx_runtime_1.jsx)("p", { className: "small-note", children: "\u65E0\u9700\u89C6\u89C9\u6A21\u578B\u3002\u53EA\u6709\u5DF2\u9A8C\u8BC1\u7684\u540C\u7248\u6216\u540C\u5C01\u88C5\u56FE\u7247\u53EF\u9009\u62E9\uFF1BDiscogs \u7167\u7247\u6CA1\u6709\u51C6\u786E\u7684\u9762\u7C7B\u578B\u6807\u7B7E\uFF0C\u8BF7\u5BF9\u7167\u7F29\u7565\u56FE\u9010\u4E00\u786E\u8BA4\u3002" }), (0, jsx_runtime_1.jsxs)("div", { className: "twin-guided-packaging", children: [(0, jsx_runtime_1.jsxs)("label", { children: ["\u5B9E\u7269\u5C01\u88C5", (0, jsx_runtime_1.jsxs)("select", { value: kind, onChange: event => setKind(event.target.value), children: [(0, jsx_runtime_1.jsx)("option", { value: "", children: "\u9009\u62E9\u5C01\u88C5\u7C7B\u578B" }), generation_1.GENERATION_PACKAGES.map(p => (0, jsx_runtime_1.jsx)("option", { value: p.value, children: p.label }, p.value))] })] }), (0, jsx_runtime_1.jsxs)("label", { children: [(0, jsx_runtime_1.jsx)("input", { type: "checkbox", checked: miniLP, disabled: kind !== 'card-sleeve' && kind !== 'gatefold', onChange: event => setMiniLP(event.target.checked) }), " Mini LP \u5C3A\u5BF8/\u5F62\u5F0F"] })] }), mismatch ? (0, jsx_runtime_1.jsxs)("label", { children: [(0, jsx_runtime_1.jsx)("input", { type: "checkbox", checked: confirmedMismatch, onChange: event => setConfirmedMismatch(event.target.checked) }), "\u5DF2\u6838\u5BF9\u5B9E\u7269\uFF0C\u786E\u8BA4\u4E0E MusicBrainz \u6240\u5217\u5C01\u88C5\u7C7B\u578B\u4E0D\u540C"] }) : null, (0, jsx_runtime_1.jsx)("div", { className: "twin-guided-gallery", children: choices.map((choice, i) => (0, jsx_runtime_1.jsxs)("figure", { children: [(0, jsx_runtime_1.jsx)("img", { src: resolveSource(choice.sourceId), loading: "lazy", alt: choice.guidedLabel }), (0, jsx_runtime_1.jsxs)("figcaption", { children: [i + 1, ". ", choice.guidedLabel] })] }, choice.sourceId)) }), (0, jsx_runtime_1.jsx)("div", { className: "twin-guided-mapping", children: roles.map(role => (0, jsx_runtime_1.jsxs)("label", { children: [generation_1.GENERATION_FACE_LABELS[role] || role, (0, jsx_runtime_1.jsx)("select", { value: faces[role] || '', onChange: event => setFaces(prev => ({ ...prev, [role]: event.target.value })), children: options })] }, role)) }), (0, jsx_runtime_1.jsx)("p", { className: "small-note", children: "\u53EF\u9009\u72EC\u7ACB 3D \u9644\u4EF6\uFF1A\u4EC5\u5728\u786E\u5B9E\u6709\u7167\u7247\u65F6\u6307\u5B9A\uFF0C\u6B4C\u8BCD\u518C\u3001\u4FA7\u6807\u548C\u5185\u888B\u4E0D\u4F1A\u88AB\u4F2A\u88C5\u6210\u5C01\u5957\u5185\u9875\u3002" }), (0, jsx_runtime_1.jsx)("div", { className: "twin-guided-mapping", children: generation_1.GENERATION_PARTS.map(part => (0, jsx_runtime_1.jsxs)("label", { children: [part.label, (0, jsx_runtime_1.jsxs)("select", { value: accessories[part.kind] || '', onChange: event => setAccessories(prev => ({ ...prev, [part.kind]: event.target.value })), children: [(0, jsx_runtime_1.jsx)("option", { value: "", children: "\u6CA1\u6709\u8FD9\u4E2A\u9644\u4EF6 / \u6682\u4E0D\u5EFA\u6A21" }), choices.map(choice => (0, jsx_runtime_1.jsxs)("option", { value: choice.sourceId, children: [choice.guidedLabel, " \u00B7 ", choice.sourceId] }, choice.sourceId))] })] }, part.kind)) }), error ? (0, jsx_runtime_1.jsx)("p", { className: "twin-error", role: "alert", children: error }) : null, (0, jsx_runtime_1.jsx)("button", { type: "button", className: "primary", disabled: !valid || busy || disabled, onClick: () => void submit(), children: busy ? '正在确认…' : '确认图片与包装，生成 3D 实体' })] });
}
