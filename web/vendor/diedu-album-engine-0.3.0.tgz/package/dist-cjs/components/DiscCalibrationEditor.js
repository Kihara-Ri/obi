"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DiscCalibrationEditor = DiscCalibrationEditor;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const album_disc_calibration_1 = require("../core/album-disc-calibration");
const LIMIT = (v, a, b) => Math.max(a, Math.min(b, v));
const copyEllipse = (e) => ({ ...e });
function DiscCalibrationEditor({ surfaces, resolveAsset, onSave, onClose }) {
    const roles = ['disc', 'disc2', 'disc3', 'disc4'].filter(role => surfaces[role]?.asset);
    const [role, setRole] = (0, react_1.useState)(roles[0] ?? 'disc');
    const [source, setSource] = (0, react_1.useState)(null);
    const [size, setSize] = (0, react_1.useState)({ width: 1, height: 1 });
    const [cal, setCal] = (0, react_1.useState)(null);
    const [automated, setAutomated] = (0, react_1.useState)(null);
    const [error, setError] = (0, react_1.useState)('');
    const [saving, setSaving] = (0, react_1.useState)(false);
    const output = (0, react_1.useRef)(null);
    const drag = (0, react_1.useRef)(null);
    const surface = surfaces[role];
    const url = surface ? resolveAsset(surface.asset) : '';
    const defaultEllipse = (w, h) => ({
        cx: .5, cy: .5, rx: Math.min(.46, .46 * h / w), ry: Math.min(.46, .46 * w / h), angle: 0,
    });
    (0, react_1.useEffect)(() => {
        let active = true;
        setSource(null);
        setError('');
        const image = new Image();
        image.onload = () => {
            if (!active)
                return;
            const scale = Math.min(1, 1100 / Math.max(image.naturalWidth, image.naturalHeight));
            const canvas = document.createElement('canvas');
            canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
            canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
            const ctx = canvas.getContext('2d', { willReadFrequently: true });
            if (!ctx) {
                setError('无法读取图像');
                return;
            }
            ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
            const data = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const found = (0, album_disc_calibration_1.detectDiscEllipse)(data.data, data.width, data.height);
            setSource(data);
            setSize({ width: data.width, height: data.height });
            setAutomated(found);
            setCal(surface?.discCalibration ? structuredClone(surface.discCalibration) :
                found ? structuredClone(found) : { outer: defaultEllipse(data.width, data.height), source: 'manual' });
        };
        image.onerror = () => { if (active)
            setError('无法加载原始盘面图片'); };
        image.src = url;
        return () => { active = false; image.onload = null; image.onerror = null; };
    }, [url, surface?.discCalibration]);
    (0, react_1.useEffect)(() => {
        if (!source || !cal || !output.current || !(0, album_disc_calibration_1.validDiscCalibration)(cal))
            return;
        let disposed = false;
        const handle = window.setTimeout(() => {
            const result = (0, album_disc_calibration_1.rasterDisc)(source.data, source.width, source.height, cal, 440);
            if (disposed || !result || !output.current)
                return;
            const canvas = output.current;
            canvas.width = result.width;
            canvas.height = result.height;
            canvas.getContext('2d')?.putImageData(new ImageData(result.data, result.width, result.height), 0, 0);
        }, 75);
        return () => { disposed = true; window.clearTimeout(handle); };
    }, [source, cal]);
    const adjust = (which, field, n) => {
        if (!cal)
            return;
        const before = which === 'outer' ? cal.outer : cal.inner;
        if (!before)
            return;
        const next = { ...before, [field]: field === 'angle' ? LIMIT(n, -Math.PI, Math.PI) : LIMIT(n, field === 'cx' || field === 'cy' ? 0 : .025, 1) };
        setCal({ ...cal, [which]: next, source: 'manual', confidence: undefined });
    };
    const local = (event) => {
        const rect = event.currentTarget.getBoundingClientRect();
        return { x: LIMIT((event.clientX - rect.left) / rect.width, 0, 1), y: LIMIT((event.clientY - rect.top) / rect.height, 0, 1) };
    };
    const pointerMove = (event) => {
        if (!drag.current || !cal)
            return;
        const { x, y } = local(event);
        const inner = drag.current.startsWith('inner');
        const e = inner ? cal.inner : cal.outer;
        if (!e)
            return;
        if (drag.current === 'center' || drag.current === 'inner-center') {
            setCal(prev => prev ? { ...prev, [inner ? 'inner' : 'outer']: { ...(inner ? prev.inner : prev.outer), cx: x, cy: y }, source: 'manual', confidence: undefined } : prev);
        }
        else {
            const dx = x - e.cx, dy = y - e.cy, c = Math.cos(e.angle), s = Math.sin(e.angle);
            const radius = drag.current.endsWith('x') ? Math.abs(dx * c + dy * s) : Math.abs(-dx * s + dy * c);
            adjust(inner ? 'inner' : 'outer', drag.current.endsWith('x') ? 'rx' : 'ry', radius);
        }
    };
    const mark = (e, color, scope) => {
        const c = Math.cos(e.angle), s = Math.sin(e.angle);
        const controls = [{ k: scope === 'outer' ? 'center' : 'inner-center', x: e.cx, y: e.cy },
            { k: scope === 'outer' ? 'outer-x' : 'inner-x', x: e.cx + e.rx * c, y: e.cy + e.rx * s },
            { k: scope === 'outer' ? 'outer-y' : 'inner-y', x: e.cx - e.ry * s, y: e.cy + e.ry * c }];
        return (0, jsx_runtime_1.jsxs)("g", { children: [(0, jsx_runtime_1.jsx)("ellipse", { cx: e.cx * 1000, cy: e.cy * 1000, rx: e.rx * 1000, ry: e.ry * 1000, transform: 'rotate(' + (e.angle * 180 / Math.PI) + ' ' + (e.cx * 1000) + ' ' + (e.cy * 1000) + ')', fill: "none", stroke: color, strokeWidth: "3", vectorEffect: "non-scaling-stroke" }), controls.map(point => (0, jsx_runtime_1.jsx)("circle", { cx: point.x * 1000, cy: point.y * 1000, r: "11", fill: color, stroke: "#151515", strokeWidth: "2", onPointerDown: event => {
                        event.preventDefault();
                        event.stopPropagation();
                        drag.current = point.k;
                        event.currentTarget.ownerSVGElement?.setPointerCapture(event.pointerId);
                    } }, point.k))] });
    };
    const save = async (reset = false) => {
        if (!cal && !reset)
            return;
        if (!reset && !(0, album_disc_calibration_1.validDiscCalibration)(cal)) {
            setError('椭圆超出原图或中心环尺寸不正确');
            return;
        }
        setSaving(true);
        setError('');
        try {
            await onSave(role, reset ? null : { ...cal, source: 'manual' });
            onClose();
        }
        catch (err) {
            setError(err instanceof Error ? err.message : '保存失败');
        }
        finally {
            setSaving(false);
        }
    };
    const switchRole = (value) => { setRole(value); drag.current = null; };
    return (0, jsx_runtime_1.jsx)("div", { className: "disc-calibration-overlay", role: "dialog", "aria-modal": "true", "aria-label": "\u76D8\u9762\u8D34\u56FE\u6821\u51C6", onClick: event => event.stopPropagation(), onKeyDown: event => { event.stopPropagation(); if (event.key === 'Escape') {
            event.preventDefault();
            onClose();
        } }, children: (0, jsx_runtime_1.jsxs)("div", { className: "disc-calibration-panel", children: [(0, jsx_runtime_1.jsxs)("div", { className: "disc-calibration-heading", children: [(0, jsx_runtime_1.jsx)("strong", { children: "\u76D8\u9762\u6821\u51C6" }), (0, jsx_runtime_1.jsxs)("div", { className: "disc-calibration-heading-actions", children: [cal ? (0, jsx_runtime_1.jsx)("button", { type: "button", disabled: saving || !(0, album_disc_calibration_1.validDiscCalibration)(cal), onClick: () => void save(), children: saving ? '保存中…' : '保存' }) : null, (0, jsx_runtime_1.jsx)("button", { type: "button", className: "quiet", onClick: onClose, children: "\u5173\u95ED" })] })] }), (0, jsx_runtime_1.jsx)("p", { className: "small-note", children: "\u6309\u4F4F\u5706\u5FC3\u6216\u5916\u5708\u63A7\u5236\u70B9\u62D6\u52A8\u3002\u539F\u56FE\u4E0D\u53D8\uFF0C\u6821\u51C6\u7ED3\u679C\u4EC5\u7528\u4E8E\u6570\u5B57\u5B9E\u4F53\u663E\u793A\u3002" }), roles.length > 1 ? (0, jsx_runtime_1.jsx)("div", { className: "disc-calibration-roles", children: roles.map((r, i) => (0, jsx_runtime_1.jsxs)("button", { type: "button", className: r === role ? 'selected' : '', onClick: () => switchRole(r), children: ["CD ", i + 1] }, r)) }) : null, (0, jsx_runtime_1.jsxs)("div", { className: "disc-calibration-workspace", children: [(0, jsx_runtime_1.jsxs)("div", { className: "disc-calibration-source", style: { aspectRatio: size.width + '/' + size.height }, children: [url ? (0, jsx_runtime_1.jsx)("img", { src: url, alt: "\u76D8\u9762\u539F\u59CB\u6765\u6E90" }) : null, cal ? (0, jsx_runtime_1.jsxs)("svg", { viewBox: "0 0 1000 1000", preserveAspectRatio: "none", onPointerMove: pointerMove, onPointerUp: event => { drag.current = null; if (event.currentTarget.hasPointerCapture(event.pointerId))
                                        event.currentTarget.releasePointerCapture(event.pointerId); }, onPointerCancel: () => { drag.current = null; }, "aria-label": "\u62D6\u52A8\u8C03\u6574\u76D8\u9762\u692D\u5706", children: [mark(cal.outer, '#8ae8ff', 'outer'), cal.inner ? mark(cal.inner, '#ffcc80', 'inner') : null] }) : null] }), (0, jsx_runtime_1.jsxs)("div", { className: "disc-calibration-result", children: [(0, jsx_runtime_1.jsx)("canvas", { ref: output, "aria-label": "\u5706\u5F62\u76D8\u9762\u6821\u6B63\u9884\u89C8" }), (0, jsx_runtime_1.jsx)("span", { children: "\u5B9E\u65F6\u6B63\u89C6\u9884\u89C8" })] })] }), cal ? (0, jsx_runtime_1.jsxs)("div", { className: "disc-calibration-settings", children: [(0, jsx_runtime_1.jsxs)("label", { children: ["\u65CB\u8F6C\u89D2\u5EA6 ", (0, jsx_runtime_1.jsx)("input", { type: "range", min: "-180", max: "180", value: Math.round(cal.outer.angle * 180 / Math.PI), onChange: event => adjust('outer', 'angle', Number(event.target.value) * Math.PI / 180) })] }), (0, jsx_runtime_1.jsxs)("label", { children: [(0, jsx_runtime_1.jsx)("input", { type: "checkbox", checked: !!cal.inner, onChange: event => setCal(prev => !prev ? prev : {
                                        ...prev, inner: event.target.checked ? {
                                            ...copyEllipse(prev.outer), rx: prev.outer.rx * .22, ry: prev.outer.ry * .22
                                        } : undefined, source: 'manual'
                                    }) }), "\u6821\u51C6\u4E2D\u5FC3\u73AF\uFF08\u53EF\u9009\uFF09"] }), (0, jsx_runtime_1.jsxs)("div", { className: "disc-calibration-actions", children: [(0, jsx_runtime_1.jsx)("button", { type: "button", className: "quiet", disabled: !automated, onClick: () => automated && setCal(structuredClone(automated)), children: "\u81EA\u52A8\u62DF\u5408\u5916\u5706" }), (0, jsx_runtime_1.jsx)("button", { type: "button", className: "quiet", onClick: () => setCal({
                                        outer: defaultEllipse(size.width, size.height), source: 'manual'
                                    }), children: "\u91CD\u7F6E\u63A7\u5236\u70B9" }), surface?.discCalibration ? (0, jsx_runtime_1.jsx)("button", { type: "button", className: "quiet", disabled: saving, onClick: () => void save(true), children: "\u64A4\u9500\u5DF2\u4FDD\u5B58\u6821\u51C6" }) : null, (0, jsx_runtime_1.jsx)("button", { type: "button", disabled: saving || !(0, album_disc_calibration_1.validDiscCalibration)(cal), onClick: () => void save(), children: saving ? '保存中…' : '保存盘面校准' })] })] }) : (0, jsx_runtime_1.jsx)("p", { className: "small-note", children: "\u6B63\u5728\u52A0\u8F7D\u539F\u59CB\u76D8\u9762\u56FE\u2026" }), error ? (0, jsx_runtime_1.jsx)("p", { className: "disc-calibration-error", role: "alert", children: error }) : null] }) });
}
