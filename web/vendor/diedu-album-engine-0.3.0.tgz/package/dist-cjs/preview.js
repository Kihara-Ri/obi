"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumCover = AlbumCover;
const jsx_runtime_1 = require("react/jsx-runtime");
/** Flat artwork projection. This entry never imports a model or Three.js. */
const react_1 = require("react");
const album_photo_raster_1 = require("./core/album-photo-raster");
function AlbumCover({ surface, resolveAsset, alt, onError }) {
    const canvas = (0, react_1.useRef)(null);
    const [ready, setReady] = (0, react_1.useState)(false);
    const source = resolveAsset(surface.asset);
    (0, react_1.useEffect)(() => {
        let active = true;
        setReady(false);
        if (!surface.region && !surface.warpRows)
            return;
        const image = new Image();
        image.onload = () => {
            if (!active || !canvas.current)
                return;
            try {
                const output = canvas.current, context = output.getContext('2d', { willReadFrequently: true });
                if (!context)
                    throw new Error('Canvas unavailable');
                const scale = Math.min(1, 1536 / Math.max(image.naturalWidth, image.naturalHeight));
                output.width = Math.max(1, Math.round(image.naturalWidth * scale));
                output.height = Math.max(1, Math.round(image.naturalHeight * scale));
                context.drawImage(image, 0, 0, output.width, output.height);
                const pixels = context.getImageData(0, 0, output.width, output.height);
                const projected = (0, album_photo_raster_1.rasterPackagingPhoto)(pixels.data, pixels.width, pixels.height, surface.region ?? undefined, surface.warpRows, 1024);
                if (!projected)
                    throw new Error('Invalid cover projection');
                output.width = projected.width;
                output.height = projected.height;
                context.putImageData(new ImageData(projected.data, projected.width, projected.height), 0, 0);
                setReady(true);
            }
            catch {
                onError?.();
            }
        };
        image.onerror = () => { if (active)
            onError?.(); };
        image.src = source;
        return () => { active = false; image.onload = null; image.onerror = null; };
    }, [source, surface.region, surface.warpRows, onError]);
    return !surface.region && !surface.warpRows
        ? (0, jsx_runtime_1.jsx)("img", { className: "cover album-flat-artwork", src: source, alt: alt, onError: onError })
        : (0, jsx_runtime_1.jsx)("canvas", { ref: canvas, className: "cover album-flat-artwork", role: "img", "aria-label": alt, "aria-busy": !ready });
}
