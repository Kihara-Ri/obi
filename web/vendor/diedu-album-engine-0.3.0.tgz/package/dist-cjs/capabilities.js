"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MODEL_DEFINITIONS = exports.MODEL_SET = void 0;
exports.packageComponent = packageComponent;
exports.normalizeLegacyEntity = normalizeLegacyEntity;
exports.inspectAlbum = inspectAlbum;
/** Lightweight protocol and physical assembly checks. No viewer or renderer imports. */
const model_set_1 = __importDefault(require("./contracts/model-set"));
const album_packaging_1 = require("./core/album-packaging");
const album_model_assets_1 = require("./core/album-model-assets");
const album_photo_projection_1 = require("./core/album-photo-projection");
const album_disc_calibration_1 = require("./core/album-disc-calibration");
const validate_document_1 = require("./contracts/validate-document");
exports.MODEL_SET = model_set_1.default.modelSet;
exports.MODEL_DEFINITIONS = model_set_1.default.models;
function packageComponent(doc) {
    const root = doc.assembly.components.find(c => c.id === doc.assembly.root);
    if (root?.kind !== 'package')
        throw new Error('Missing album package');
    return root;
}
function normalizeLegacyEntity(entity) {
    if (entity.schemaVersion !== 1 || entity.components?.length)
        throw new Error('Legacy attachment ownership is unknown');
    const model = (0, album_packaging_1.albumPackaging)(entity.packaging);
    const stem = (0, album_model_assets_1.albumModelAsset)(model, !!entity.calibration).replace(/\.glb$/, '');
    const profile = exports.MODEL_DEFINITIONS[stem];
    if (!profile)
        throw new Error('Unsupported album model');
    const [width, height, depth] = profile.nominal_mm;
    const parts = [{ id: 'package', kind: 'package', definition: stem, parent: null, mount: null,
            configuration: structuredClone(entity.packaging),
            dimensions: { ...(entity.packaging.size ?? { width, height, depth }), basis: entity.packaging.size ? 'measured' : 'template' },
            surfaces: structuredClone(entity.surfaces) }];
    for (let panel = 0; panel < model.panels; panel++) {
        const discs = (0, album_model_assets_1.albumPanelDiscs)(model, panel);
        if (!discs.length)
            continue;
        const mount = `${model.holder}:${model.kind === 'jewel' ? 0 : panel}`;
        const socket = profile.sockets[mount];
        if (!socket)
            throw new Error('Missing disc carrier socket');
        const holderId = mount.replace(':', '-');
        const [w, h, d] = socket.size_mm;
        parts.push({ id: holderId, kind: model.holder, definition: model.holder, parent: 'package', mount,
            dimensions: { width: w, height: h, depth: d, basis: 'template' }, surfaces: {},
            contains: discs.map(index => 'disc-' + index) });
        for (const index of discs)
            parts.push({ id: 'disc-' + index, kind: 'disc', definition: 'cd', parent: holderId,
                mount: 'disc:' + index, dimensions: { width: 120, height: 120, depth: 1.2, basis: 'template' },
                surfaces: entity.surfaces[(index === 0 ? 'disc' : 'disc' + (index + 1))]
                    ? { front: structuredClone(entity.surfaces[(index === 0 ? 'disc' : 'disc' + (index + 1))]) } : {} });
        if (model.kind === 'jewel' || model.kind === 'card-sleeve' || model.kind === 'rigid-box')
            break;
    }
    const assets = Object.fromEntries(Object.values(entity.surfaces).filter(s => !!s).map(s => [s.asset,
        Object.fromEntries(Object.entries(s).filter(([key, value]) => ['origin', 'sourceUrl', 'sourceReleaseId'].includes(key) && value !== undefined))]));
    if (entity.calibration)
        assets[entity.calibration.spine.asset] ??= { origin: entity.calibration.spine.origin, sourceUrl: entity.calibration.spine.sourceUrl };
    return { schemaVersion: 2, key: entity.key, title: entity.title, modelSet: exports.MODEL_SET,
        assembly: { root: 'package', components: parts }, assets, ...(entity.surfaces.front ? { preview: entity.surfaces.front } : {}),
        ...(entity.calibration ? { calibration: structuredClone(entity.calibration) } : {}),
        ...(entity.placeholderHue === undefined ? {} : { placeholderHue: entity.placeholderHue }) };
}
function validDocument(doc) {
    if (doc.modelSet !== exports.MODEL_SET)
        return 'model';
    if (typeof doc.key !== 'string' || !doc.key || doc.key.length > 200 || typeof doc.title !== 'string' || !doc.assembly || !Array.isArray(doc.assembly.components)
        || !doc.assets || typeof doc.assets !== 'object')
        return 'schema';
    if (Object.keys(doc).some(key => !['schemaVersion', 'key', 'title', 'modelSet', 'assembly', 'assets', 'preview', 'calibration', 'placeholderHue', 'presentation'].includes(key)))
        return 'schema';
    if (Object.keys(doc.assets).length > 64 || Object.entries(doc.assets).some(([asset, provenance]) => !/^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/.test(asset) || asset.includes('..') || !provenance
        || Object.entries(provenance).some(([key, value]) => !['origin', 'sourceUrl', 'sourceReleaseId'].includes(key) || typeof value !== 'string' || value.length > 4096)))
        return 'assets';
    const parts = doc.assembly.components;
    if (!parts.length || parts.length > 32)
        return 'assembly';
    const byId = new Map(parts.map(c => [c.id, c]));
    if (byId.size !== parts.length || parts.some(c => typeof c.id !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$/.test(c.id)))
        return 'assembly';
    const root = byId.get(doc.assembly.root);
    if (root?.kind !== 'package' || root.parent !== null || root.mount !== null)
        return 'assembly';
    const definition = exports.MODEL_DEFINITIONS[root.definition];
    if (!definition || (0, album_model_assets_1.albumModelAsset)((0, album_packaging_1.albumPackaging)(root.configuration), !!doc.calibration).replace(/\.glb$/, '') !== root.definition)
        return 'model';
    if ('photos' in root.configuration || 'photoRegions' in root.configuration)
        return 'assembly';
    const packageModel = (0, album_packaging_1.albumPackaging)(root.configuration);
    // This model set guarantees complete physical fit only at authored dimensions.
    // Keep other measured sizes as 2D until a Blender rig supports their cavity,
    // hinge and attachment clearances together; never stretch 120 mm CDs to fit.
    if (root.configuration.size && ['width', 'height', 'depth'].some((key, index) => Math.abs(root.configuration.size[key] - definition.nominal_mm[index]) > .001))
        return 'model';
    const expected = root.configuration.size
        ? [root.configuration.size.width, root.configuration.size.height, root.configuration.size.depth] : definition.nominal_mm;
    if (['width', 'height', 'depth'].some((key, index) => Math.abs(root.dimensions[key] - expected[index]) > .000001)
        || root.dimensions.basis !== (root.configuration.size ? 'measured' : 'template'))
        return 'assembly';
    const surfaceValid = (surface) => {
        if (!surface || typeof surface.asset !== 'string' || !Object.hasOwn(doc.assets, surface.asset))
            return false;
        if (Object.keys(surface).some(key => !['asset', 'region', 'warpRows', 'discCalibration', 'origin', 'sourceUrl', 'sourceReleaseId'].includes(key)))
            return false;
        if (['origin', 'sourceUrl', 'sourceReleaseId'].some(key => key in surface && surface[key] !== doc.assets[surface.asset][key]))
            return false;
        if (surface.region && (surface.region.length !== 8 || !surface.region.every(n => Number.isFinite(n) && n >= 0 && n <= 1) || !(0, album_photo_projection_1.photoProjection)(surface.region)))
            return false;
        return (!surface.warpRows || (0, album_photo_projection_1.validPhotoWarpRows)(surface.warpRows)) && (!surface.discCalibration || (0, album_disc_calibration_1.validDiscCalibration)(surface.discCalibration));
    };
    const usedMounts = new Set();
    for (const part of parts) {
        const dims = part.dimensions;
        if (Object.keys(part).some(key => !['id', 'kind', 'definition', 'parent', 'mount', 'dimensions', 'surfaces', 'configuration', 'contains', 'fold'].includes(key)))
            return 'assembly';
        if (!dims || !['measured', 'template'].includes(dims.basis)
            || ![dims.width, dims.height, dims.depth].every(n => typeof n === 'number' && Number.isFinite(n) && n > 0 && n <= 700))
            return 'assembly';
        if (part.kind === 'booklet' && part.fold && dims.depth + .000001 < part.fold.panels * .1)
            return 'assembly';
        if ('position' in part || 'scale' in part || 'rotation' in part)
            return 'assembly';
        if (!part.surfaces || typeof part.surfaces !== 'object')
            return 'assets';
        for (const surface of Object.values(part.surfaces)) {
            if (!surfaceValid(surface))
                return 'assets';
        }
        if (part === root)
            continue;
        const renderedRoles = part.kind === 'disc' ? ['front'] : ['obi', 'booklet', 'inner-sleeve'].includes(part.kind) ? ['front', 'back'] : [];
        if (Object.keys(part.surfaces).some(role => !renderedRoles.includes(role)))
            return 'assets';
        const parent = part.parent ? byId.get(part.parent) : undefined;
        if (!parent || !part.mount)
            return 'assembly';
        const mountKey = part.parent + ':' + part.mount;
        if (usedMounts.has(mountKey))
            return 'assembly';
        usedMounts.add(mountKey);
        const ancestors = new Set([part.id]);
        let ancestor = parent;
        while (ancestor) {
            if (ancestors.has(ancestor.id))
                return 'assembly';
            ancestors.add(ancestor.id);
            ancestor = ancestor.parent ? byId.get(ancestor.parent) : undefined;
        }
        if (!ancestors.has(root.id))
            return 'assembly';
        if (part.kind === 'disc') {
            if (!['pocket', 'tray', 'inner-sleeve'].includes(parent.kind) || !/^disc:[0-3]$/.test(part.mount)
                || part.definition !== 'cd' || dims.width !== 120 || dims.height !== 120 || dims.depth !== 1.2)
                return 'assembly';
            const carrier = parent.kind === 'inner-sleeve' ? byId.get(parent.parent) : parent;
            const panel = Number(carrier?.mount?.split(':')[1]);
            if (!(0, album_model_assets_1.albumPanelDiscs)(packageModel, panel).includes(Number(part.mount.split(':')[1])))
                return 'assembly';
            if (parent.kind === 'inner-sleeve' && (parent.contains?.length !== 1 || !parent.contains.includes(part.id)
                || parent.dimensions.width < 121.3 || parent.dimensions.height < 121.3 || parent.dimensions.depth < 1.6))
                return 'assembly';
        }
        else {
            const socket = definition.sockets[part.mount];
            if (!socket || socket.kind !== part.kind || part.definition !== part.kind)
                return 'assembly';
            if (part.kind === 'inner-sleeve' && (parent.kind !== 'pocket' || parent.mount !== 'pocket:' + socket.panel))
                return 'assembly';
            if (part.kind !== 'inner-sleeve' && parent !== root)
                return 'assembly';
            if (part.kind === 'pocket' || part.kind === 'tray') {
                if (part.kind !== packageModel.holder || !(0, album_model_assets_1.albumPanelDiscs)(packageModel, socket.panel).length || Object.keys(part.surfaces).length)
                    return 'assembly';
            }
            else if (!part.surfaces.front)
                return 'assets';
            if ((dims.width > socket.size_mm[0] + .001 || dims.height > socket.size_mm[1] + .001
                || dims.depth > socket.size_mm[2] + .001))
                return 'assembly';
            if (part.kind === 'obi' && (dims.height > root.dimensions.height || dims.width > root.dimensions.width / 2))
                return 'assembly';
            if (part.kind === 'inner-sleeve' && (dims.width > parent.dimensions.width || dims.height > parent.dimensions.height || dims.depth > parent.dimensions.depth))
                return 'assembly';
        }
        if (part.contains) {
            if (!['pocket', 'tray', 'inner-sleeve'].includes(part.kind) || new Set(part.contains).size !== part.contains.length)
                return 'assembly';
            const children = parts.filter(c => c.parent === part.id && c.kind === 'disc');
            if (children.length !== part.contains.length || children.some(c => !part.contains.includes(c.id)))
                return 'assembly';
        }
    }
    const discs = parts.filter(c => c.kind === 'disc');
    if (discs.length !== (0, album_packaging_1.albumPackaging)(root.configuration).discs || new Set(discs.map(c => c.mount)).size !== discs.length)
        return 'assembly';
    if (doc.preview && !surfaceValid(doc.preview))
        return 'assets';
    if (doc.calibration && (!doc.calibration.spine || !Object.hasOwn(doc.assets, doc.calibration.spine.asset)
        || doc.calibration.spine.basis !== 'image-estimate' || !Number.isFinite(doc.calibration.spine.widthRatio)
        || doc.calibration.spine.widthRatio < .001 || doc.calibration.spine.widthRatio > .2))
        return 'assets';
    return null;
}
function inspectAlbum(input, models = { rigVersion: 1 }) {
    if (models.rigVersion !== 1 || !input || typeof input !== 'object')
        return { supported: false, reason: 'schema' };
    try {
        const source = input;
        const entity = source.schemaVersion === 1 ? normalizeLegacyEntity(source) : source;
        if (entity.schemaVersion !== 2)
            return { supported: false, reason: 'schema' };
        if (!(0, validate_document_1.structurallyValidDocument)(entity))
            return { supported: false, reason: 'schema' };
        const reason = validDocument(entity);
        return reason ? { supported: false, reason } : { supported: true, entity, modelSet: exports.MODEL_SET };
    }
    catch {
        return { supported: false, reason: 'assembly' };
    }
}
