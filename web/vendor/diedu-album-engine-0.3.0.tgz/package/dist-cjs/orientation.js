"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestAlbumOrientationPermission = void 0;
var useAlbumOrientation_1 = require("./components/useAlbumOrientation");
Object.defineProperty(exports, "requestAlbumOrientationPermission", { enumerable: true, get: function () { return useAlbumOrientation_1.requestAlbumOrientationPermission; } });
