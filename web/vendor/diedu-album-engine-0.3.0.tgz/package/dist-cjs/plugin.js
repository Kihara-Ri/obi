"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.manifest = exports.spineCalibrationFitForEntity = exports.spineCalibrationFit = exports.editionMaterialSources = exports.requestAlbumOrientationPermission = exports.inspectAlbum = void 0;
exports.mount = mount;
/** Installable browser boundary. Rendering libraries are loaded only by mount. */
const album_plugin_lifecycle_1 = require("./core/album-plugin-lifecycle");
const engine_manifest_json_1 = __importDefault(require("../engine-manifest.json"));
require("./styles/album-model.css");
var capabilities_1 = require("./capabilities");
Object.defineProperty(exports, "inspectAlbum", { enumerable: true, get: function () { return capabilities_1.inspectAlbum; } });
var orientation_1 = require("./orientation");
Object.defineProperty(exports, "requestAlbumOrientationPermission", { enumerable: true, get: function () { return orientation_1.requestAlbumOrientationPermission; } });
var generation_1 = require("./generation");
Object.defineProperty(exports, "editionMaterialSources", { enumerable: true, get: function () { return generation_1.editionMaterialSources; } });
var calibration_1 = require("./calibration");
Object.defineProperty(exports, "spineCalibrationFit", { enumerable: true, get: function () { return calibration_1.spineCalibrationFit; } });
Object.defineProperty(exports, "spineCalibrationFitForEntity", { enumerable: true, get: function () { return calibration_1.spineCalibrationFitForEntity; } });
exports.manifest = Object.freeze({ id: 'album-engine', pluginProtocol: 1, ...engine_manifest_json_1.default });
const mounts = new WeakMap();
async function mount(kind, element, props) {
    let component;
    // Each renderer import stays behind this explicit mounting boundary. In
    // particular, importing plugin.js for inspectAlbum cannot create WebGL.
    switch (kind) {
        case 'viewer':
            component = (await Promise.resolve().then(() => __importStar(require('./index')))).AlbumViewer;
            break;
        case 'guided-editor':
            component = (await Promise.resolve().then(() => __importStar(require('./components/GuidedTwinEditor')))).GuidedTwinEditor;
            break;
        case 'accessories-editor':
            component = (await Promise.resolve().then(() => __importStar(require('./components/TwinAccessoriesEditor')))).TwinAccessoriesEditor;
            break;
        case 'disc-calibration-editor':
            component = (await Promise.resolve().then(() => __importStar(require('./components/DiscCalibrationEditor')))).DiscCalibrationEditor;
            break;
        default: throw new Error('Unknown Album Engine mount kind');
    }
    const [{ createRoot }, { createElement }] = await Promise.all([Promise.resolve().then(() => __importStar(require('react-dom/client'))), Promise.resolve().then(() => __importStar(require('react')))]);
    const previous = mounts.get(element);
    if (previous) {
        previous();
        await Promise.resolve();
    }
    const root = createRoot(element), controller = new AbortController();
    const dispose = (0, album_plugin_lifecycle_1.pluginRootDisposer)(root, controller, () => { if (mounts.get(element) === dispose)
        mounts.delete(element); });
    mounts.set(element, dispose);
    root.render(createElement(component, kind === 'viewer' ? { ...props, lifecycle: controller.signal } : props));
    return dispose;
}
