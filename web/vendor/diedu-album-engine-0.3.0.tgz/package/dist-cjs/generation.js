"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GENERATION_FACE_LABELS = exports.GENERATION_PARTS = exports.GENERATION_PACKAGES = void 0;
exports.inferGenerationPackaging = inferGenerationPackaging;
exports.editionMaterialSources = editionMaterialSources;
exports.generationSources = generationSources;
exports.generationRoles = generationRoles;
exports.initialGenerationSurfaces = initialGenerationSurfaces;
exports.buildGuidedSelection = buildGuidedSelection;
exports.sourceForAccessory = sourceForAccessory;
exports.buildAccessorySelections = buildAccessorySelections;
exports.GENERATION_PACKAGES = [
    { value: 'card-sleeve', label: 'Card Sleeve / 纸封套' },
    { value: 'jewel', label: 'Jewel Case / 塑料盒' },
    { value: 'gatefold', label: 'Gatefold / 对折纸封' },
    { value: 'digipak', label: 'Digipak' }, { value: 'digibook', label: 'Digibook' }, { value: 'rigid-box', label: 'Rigid Box' },
];
exports.GENERATION_PARTS = [
    { kind: 'obi', label: '独立侧标 OBI', shortLabel: '侧标 OBI' },
    { kind: 'booklet', label: '可取出的歌词册', shortLabel: '歌词册' },
    { kind: 'inner-sleeve', label: '纸质内袋', shortLabel: '内袋' },
];
exports.GENERATION_FACE_LABELS = {
    front: '正面', back: '背面', insideLeft: '左内面', insideRight: '右内面',
    disc: 'CD 1', disc2: 'CD 2', disc3: 'CD 3', disc4: 'CD 4', outer: '外套', spine: '书脊',
};
function inferGenerationPackaging(raw) {
    const text = (raw || '').toLowerCase();
    if (text.includes('gatefold'))
        return 'gatefold';
    if (text.includes('digipak'))
        return 'digipak';
    if (text.includes('digibook'))
        return 'digibook';
    if (text.includes('jewel'))
        return 'jewel';
    if (text.includes('cardboard') || text.includes('sleeve'))
        return 'card-sleeve';
    return '';
}
function editionMaterialSources(candidate) {
    if (!candidate)
        return [];
    return [
        ...(candidate.artwork || []).map(image => ({ sourceId: 'caa:' + image.id, types: image.types, origin: 'caa',
            guidedLabel: image.types.join(' / ') || 'CAA', accessoryLabel: 'CAA · ' + image.types.join(', ') })),
        ...(candidate.editionReferences || []).filter(reference => reference.status === 'verified')
            .flatMap(reference => (reference.images || []).map((image, index) => ({ sourceId: image.sourceId, types: [],
            origin: 'verified-discogs', guidedLabel: 'Discogs #' + index, accessoryLabel: 'Discogs #' + (index + 1) }))),
        ...(candidate.compatibleArtwork || []).flatMap(reference => reference.images.map(image => ({ sourceId: image.sourceId,
            types: image.types, origin: 'compatible-edition',
            guidedLabel: '同封装版次 / ' + image.types.join(', '), accessoryLabel: '同封装版 · ' + image.types.join(', ') }))),
    ];
}
function generationSources(photos, candidate) {
    return [...photos.map((photo, index) => ({ ...photo, types: [], origin: 'record-photo',
            guidedLabel: '本人实物照片 #' + (index + 1), accessoryLabel: '实物照片 ' + (index + 1) })), ...editionMaterialSources(candidate)];
}
function generationRoles(kind, count) {
    return ['front', 'back', ...(['jewel', 'gatefold', 'digipak', 'digibook'].includes(kind) ? ['insideLeft'] : []),
        ...(['gatefold', 'digipak', 'digibook'].includes(kind) ? ['insideRight'] : []),
        ...Array.from({ length: count }, (_, index) => index === 0 ? 'disc' : 'disc' + (index + 1))];
}
function initialGenerationSurfaces(initial, sources) {
    const result = { ...initial };
    for (const face of ['front', 'back', 'disc']) {
        const type = face === 'disc' ? 'medium' : face;
        const choice = sources.find(source => source.types.some(label => label.toLowerCase() === type));
        if (choice)
            result[face] = choice.sourceId;
    }
    return result;
}
function buildGuidedSelection(candidate, kind, miniLP, confirmedMismatch, faces, accessories, sources) {
    const count = candidate.discCount || 1;
    if (!Number.isInteger(count) || count < 1 || count > 4 || !kind)
        return null;
    const expected = inferGenerationPackaging(candidate.packaging);
    const mismatch = !!expected && expected !== kind;
    const allowed = new Set(sources.map(source => source.sourceId));
    const roles = generationRoles(kind, count);
    if ((mismatch && !confirmedMismatch) || !roles.every(role => allowed.has(faces[role])) ||
        !Object.values(accessories).every(value => !value || allowed.has(value)))
        return null;
    return { confirmedPackagingOverride: mismatch && confirmedMismatch,
        packaging: { structure: kind, discs: count, miniLP, holder: kind === 'jewel' ? 'tray' : 'pocket' },
        surfaces: Object.fromEntries(roles.map(role => [role, faces[role]])),
        components: exports.GENERATION_PARTS.flatMap(part => accessories[part.kind] ? [{ kind: part.kind, sourceId: accessories[part.kind] }] : []) };
}
/** Asset filenames cannot establish a release when several authorized sources collide. */
function sourceForAccessory(part, ids) {
    const discogs = /^discogs-(\d+)-(\d+)\.(?:jpg|png|webp)$/.exec(part.asset);
    if (discogs)
        return ids.find(id => id === 'discogs:' + discogs[1] + ':' + discogs[2]) || '';
    const photo = /^photo-(\d+)\.(?:jpg|png|webp)$/.exec(part.asset);
    if (photo)
        return ids.find(id => id === 'photo:' + photo[1]) || '';
    const caa = /^caa-(\d+)\.(?:jpg|png|webp)$/.exec(part.asset);
    if (!caa)
        return '';
    if (part.origin === 'compatible-edition-reference' && part.sourceReleaseId)
        return ids.find(id => id === 'related-caa:' + part.sourceReleaseId + ':' + caa[1]) || '';
    const options = ids.filter(id => id === 'caa:' + caa[1] || id.startsWith('related-caa:') && id.endsWith(':' + caa[1]));
    if (part.origin === 'edition-reference')
        return options.find(id => id === 'caa:' + caa[1]) || '';
    return options.length === 1 ? options[0] : '';
}
/** Preserve component identity while the server verifies the frozen source.
 * A changed selection intentionally sends no old fold, crop or verso evidence.
 */
function buildAccessorySelections(selection, components) {
    return exports.GENERATION_PARTS.flatMap(({ kind }) => {
        const sourceId = selection[kind];
        if (!sourceId)
            return [];
        const previous = components.filter(part => part.kind === kind).at(-1);
        return [{ ...(previous ? { id: previous.id } : {}), kind, sourceId }];
    });
}
