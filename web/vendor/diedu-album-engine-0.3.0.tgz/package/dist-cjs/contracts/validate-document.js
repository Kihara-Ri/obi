"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.structurallyValidDocument = structurallyValidDocument;
const entity_schema_1 = __importDefault(require("./entity-schema"));
const root = entity_schema_1.default;
/** The protocol's structural vocabulary, evaluated from its shared schema. */
function matches(value, rule) {
    if (rule.$ref)
        return matches(value, root.$defs[rule.$ref.split('/').at(-1)]);
    if ('const' in rule && value !== rule.const)
        return false;
    if (rule.enum && !rule.enum.includes(value))
        return false;
    if (rule.oneOf && rule.oneOf.filter(child => matches(value, child)).length !== 1)
        return false;
    if (rule.anyOf && !rule.anyOf.some(child => matches(value, child)))
        return false;
    if (rule.type === 'null')
        return value === null;
    if (rule.type === 'boolean')
        return typeof value === 'boolean';
    if (rule.type === 'number' || rule.type === 'integer') {
        if (typeof value !== 'number' || !Number.isFinite(value) || rule.type === 'integer' && !Number.isInteger(value))
            return false;
        return (rule.minimum === undefined || value >= rule.minimum) && (rule.maximum === undefined || value <= rule.maximum)
            && (rule.exclusiveMinimum === undefined || value > rule.exclusiveMinimum) && (rule.exclusiveMaximum === undefined || value < rule.exclusiveMaximum);
    }
    if (rule.type === 'string')
        return typeof value === 'string'
            && (rule.minLength === undefined || Array.from(value).length >= rule.minLength) && (rule.maxLength === undefined || Array.from(value).length <= rule.maxLength)
            && (!rule.pattern || new RegExp(rule.pattern).test(value))
            && (rule.format !== 'uuid' || /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(value));
    if (rule.type === 'array')
        return Array.isArray(value)
            && (rule.minItems === undefined || value.length >= rule.minItems) && (rule.maxItems === undefined || value.length <= rule.maxItems)
            && (!rule.items || value.every(item => matches(item, rule.items)))
            && (!rule.uniqueItems || new Set(value.map(item => JSON.stringify(item))).size === value.length);
    if (rule.type === 'object') {
        if (!value || typeof value !== 'object' || Array.isArray(value))
            return false;
        const obj = value, keys = Object.keys(obj);
        if ((rule.required ?? []).some(key => !Object.hasOwn(obj, key))
            || rule.minProperties !== undefined && keys.length < rule.minProperties
            || rule.maxProperties !== undefined && keys.length > rule.maxProperties)
            return false;
        return keys.every(key => (!rule.propertyNames || matches(key, rule.propertyNames))
            && (rule.properties?.[key] ? matches(obj[key], rule.properties[key]) : rule.additionalProperties === false ? false
                : typeof rule.additionalProperties === 'object' ? matches(obj[key], rule.additionalProperties) : true));
    }
    return true;
}
function structurallyValidDocument(value) { return matches(value, root); }
