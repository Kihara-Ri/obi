"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.spineCalibrationFit = void 0;
exports.spineCalibrationFitForEntity = spineCalibrationFitForEntity;
const capabilities_1 = require("./capabilities");
const record_1 = require("./record");
const album_spine_fit_1 = require("./core/album-spine-fit");
var album_spine_fit_2 = require("./core/album-spine-fit");
Object.defineProperty(exports, "spineCalibrationFit", { enumerable: true, get: function () { return album_spine_fit_2.spineCalibrationFit; } });
function spineCalibrationFitForEntity(entity) {
    const capability = (0, capabilities_1.inspectAlbum)(entity);
    return capability.supported ? (0, album_spine_fit_1.spineCalibrationFit)((0, record_1.createViewerInput)(capability.entity, asset => asset, { baseUrl: '', rigVersion: 1 })) : null;
}
