# Album Engine

Generation/publication accepts an independent `back: {sourceId, region?}` on
OBI, booklet and inner-sleeve selections. The engine freezes its provenance,
includes the verso in asset authorization/backup validation, and compiles it to
the component's canonical `surfaces.back`. Missing verso evidence stays blank;
the front is never copied to the reverse automatically.

唱片实体协议、生成与发布、校准编辑器、查看器和 Blender 模型工具链的独立仓库。当前版本为 `@diedu/album-engine` 0.2.1；Studio 使用合成实体，脱离碟渡后端运行。

## 运行与验证

```sh
npm ci
npm run studio -- --host 127.0.0.1 --port <空闲端口>
npm run typecheck
npm test
npm run build
npm run studio:build
```

Studio 读取固定样本，不连接收藏 API。`fixtures/` 由碟渡的 `tools/seed_samples.py --export-engine-fixtures <输出目录>` 导出，新增场景先扩充该唯一样本源。Vite 将共享模型作为同源 `/packaging/` 提供；生产构建复制到 `studio-dist/packaging/`，纹理由模块导入进入构建。库输出在 `dist/` 和 `dist-cjs/`，Studio 产物作为网站根目录由 HTTP 服务提供。

工作台使用 WebGL 查看器。先点击舞台，再以拖动/方向键旋转、点击/Enter 开合、数字键取放 CD、Home 回正、Esc 关闭。引擎已移除 CSS 模型，WebGL 不可用时返回宿主 2D 封面。浏览器验收覆盖三个代表样本、完整 Gatefold 附件组合、包装开合、两张 CD 及纸件取放的中间位置、关闭重开和 console；浏览器结果不等于真实模型质量、手机感应或实机帧率证据。

查看器样式由外部 CSS 加载，默认模型材质 token 与碟渡一致；宿主可通过自身主题 token 调整界面。独立宿主回归可在构建后运行 `npx vite --config tests/browser/vite.config.mjs --host 127.0.0.1 --port <空闲端口>`，打开 `/standalone.html`，核对无主题 token 时阴影/加载圈、同名宿主节点切换后的键盘输入、关闭/重开与姿态保留。

## 0.2 实体与职责

`AlbumDocument` 是 `schemaVersion: 2` 的可序列化 canonical 文档，包含稳定 `key`、`title`、`modelSet`、`assembly.root`、组件图和不透明资产 ID。组件使用 `parent`、语义 `mount`、`contains` 与各自印刷面描述归属，不含账本 ID、照片序号、金额、交易状态或任务 API URL。结构唯一来源为 `schema/album-document-v2.schema.json`；TypeScript 声明由其生成，Python runtime 校验同一 schema，`src/contracts/model-set.json` 由两端共享。

尺寸统一为毫米，角度为弧度；引擎在装配入口转换为米。尺寸的 `basis` 区分 `template` 与 `measured` 并保留来源；共享模型的 nominal 毫米尺寸不等于实物测量。版本化语义槽位管理局部坐标、可用容积、开口、组件种类与抽出方向，宿主不传任意偏移修画面。侧标、歌词本、内袋和 CD 共用一份装配结果，供模型、raycast、遮挡、动作与镜头使用。

引擎负责模型、素材规划与处理、生成执行、校准、组件约束、发布包构建及发布决策；`python/album_engine/` 为纯标准库 runtime。宿主提供已确认发行版、授权资产/下载、共享目录客户端、视觉模型能力，以及去重、租约和持久化窄接口；实际数据库提交、审计、权限、业务状态及备份仍由宿主事务层负责。引擎不连接账本数据库，也不接收完整宿主 Store。

v1 输入只读兼容；`normalizeLegacyEntity` 仅转换可确定的关系。旧附件若缺少能唯一确定的挂载归属，保持 2D，不自动补归属、写回 canonical 文档或重跑生成。历史成功任务、包装字段或某个 GLB 文件本身均不能替代能力检查。

## 宿主接入：默认 2D、显式 3D

收藏布局与每次打开/换张/重开的灯箱均先显示 2D。封面优先，其次为已发布平面预览；缺少两者保留缺图。`@diedu/album-engine/preview` 可通过轻量 Canvas 投影已发布原图与校准描述，服务端无需图像解码依赖。

```tsx
import {inspectAlbum} from '@diedu/album-engine/capabilities';
import {requestAlbumOrientationPermission} from '@diedu/album-engine/orientation';
import type {AlbumDocument} from '@diedu/album-engine/schema';
import '@diedu/album-engine/style.css';

const capability = inspectAlbum(document, {rigVersion: 1});
// 仅在 capability.supported 时显示 3D 选项；处理用户点击：
async function enable3D() {
  if (!capability.supported) return;
  const permission = requestAlbumOrientationPermission();
  const {AlbumViewer} = await import('@diedu/album-engine');
  mountViewer(<AlbumViewer entity={capability.entity}
    resolveAsset={asset => resolveLocalAsset(asset)}
    models={{baseUrl: '/models/packaging/', rigVersion: 1}}
    permission={permission} onRequestClose={closeViewer} onUnavailable={returnTo2D}/>);
}
```

`schema`、`packaging`、`capabilities` 轻量入口不导入 React、Three.js 或查看器；`orientation` 与 React 平面预览入口 `preview` 不加载 Three.js/GLB。宿主先确认实体为当前有效发布版本，再用 `inspectAlbum` 检查协议、模型、组件关系、尺寸和资产声明。只在同一次点击 3D 的手势内请求感应并加载查看器、Three.js 和 GLB；打开 2D 不创建 WebGL、不下载模型、不请求感应。

提供 `onUnavailable` 的严格查看器在文件缺失、装配失败或 WebGL 不可用/上下文丢失时通知宿主回到原 2D，可由用户显式重试。切回 2D、换实体或关闭时卸载，释放监听、异步载入、动画、指针捕获和 GPU。同一实体正常读回保持已打开的姿态；发布版本改变则重建。校准交互与样式由 `@diedu/album-engine/editor` 导出，宿主只在编辑专辑挂载并注入保存回调；展示灯箱无校准入口。

引擎仅提供 WebGL 查看器，已删除 CSS 模型及其公开入口。WebGL 不可用时调用 onUnavailable，由宿主返回 2D；独立 Studio 显示不可用状态。当前模型结构为 `rigVersion: 1`、model set 为 `album-rig-1`，与文档 schema 版本分开管理。

## Blender 模型与装配

所有包装及附件实体都由 Blender 制作并真实导出 GLB；包括 OBI、歌词本和内袋。`tools/model-library/build_library.py` 及 `build_accessories.py` 为可复现模型源，共享产物位于 `models/packaging/`。运行时加载模板，仅设置其已制作的形状键、节点尺度、材质与装配变换，不用 Three.js Box/Plane/BufferGeometry 另建附件几何。

原 21 个库模型与 `component-obi.glb`、`component-booklet.glb`、`component-inner-sleeve.glb`、`component-foldout.glb` 一起发布。OBI 是连续折叠纸片，使用 `case_depth`、`band_width`、`height` 形状键；内袋保留独立前后纸层、三条封合边和开放袋口。模型坐标/轴心/印刷材质名/GLB extras 的变化必须有明确 rig 兼容策略。缺图保留中性示意，不借主封或另一附件图片补齐；普通歌词本按整册取放；明确声明 fold 的长折页沿 Blender 铰链展开完整长图，不模拟未知装订页。

## Python runtime 回归

`npm run test:python` 独立运行纯标准库回归，不导入宿主。素材检索/版次核验、书脊校准、来源→解释→装配边界和附件裁切测试归属引擎；宿主仅保留兼容入口与错误翻译检查。CI 在打包前执行这组测试。合成几何夹具仍来自宿主固定样本导出，网络响应由离线测试替身提供。

## 发布与更新宿主

引擎发布匹配的 npm tarball 与 Python runtime bundle，二者均标记 0.2.1、schemaVersion 2、rigVersion 1、modelSet `album-rig-1`。完成当次验证后：

```sh
npm run build
npm pack
python3 scripts/package-runtime.py --output <宿主目录>/vendor/album_engine
```

npm 包自包含编译查看器、声明、CSS、模型、能力清单、schema 与 runtime 源。将 tarball 放入宿主 `web/vendor/` 并安装更新 lock，runtime 导出放入 `vendor/album_engine/` 并跟踪；该目录为引擎产物，修改应回引擎源码重新导出。runtime manifest 记录文件 SHA-256；构建/服务组装核对两端版本、modelSet、schemaVersion、rigVersion。

碟渡的前端构建复制包内 GLB 与 manifest，Docker / 裸机包直接包含已锁定 tarball、构建模型及 vendored runtime。克隆宿主无需引擎源码仓库或 pip/Node/Blender 服务端运行依赖。更新时完成引擎检查、脱离源码的包内容检查，再完成宿主前后端、固定样本浏览器、Docker 与数据泄漏检查；命令和验收清单不代表本次已执行或部署。

## 历史实现记录（0.1.x）

以下记录保留历史修复原因；当前文档协议、职责、默认展示和 Blender 模型规则以上述 0.2 说明为准。

## Disc photo calibration (0.1.2)

The engine conservatively fits an outer elliptical rim on a tilted disc photograph and rasterizes it into a front-on round texture. Insufficient perimeter evidence leaves the source texture unchanged. Each disc surface supports discCalibration with source, outer and optional inner ellipses, in normalized image coordinates with angles in radians. Manual calibration overrides auto detection. The WebGL viewer uses this rectification; sources remain untouched and the host manages persistence.


## Individually modeled paper accessories (0.1.3)

AlbumEntity.components optionally includes up to eight independently sourced OBI, booklet, or inner-sleeve paper objects. Each has a stable ID, source image and provenance; it is not a main surface alias. This was the initial accessory contract. As of 0.1.8, the WebGL viewer interacts through physical paper mesh raycasting and exposed-edge grip hit testing, not dedicated DOM controls; Parts without source images are never invented. Dimensions are nominal template proportions until a real specimen is measured. Booklets with explicit fold:{pattern:"accordion",panels:2..6} use a complete two-sided accordion sheet; unknown bound pages are not invented.


## Paper sleeve physical edge refinement (0.1.5)

The original 0.1.4 pass softened printed front/back image corners without
rounding the underlying folded card stock; the exposed Paper_Cut wall could
still look like a sharp white board. This revision repairs the physical
silhouette, not just the photograph: a 1.55 mm plan-profile roundover is
applied consistently to the front/back board, spine and both glued end folds.
Fine-spaced edge control points follow the same rounded envelope, while the
top/bottom board's already-curved 0.08 mm fold cross-section is relaxed into a
0.30 mm roll. Paper-edge material becomes warmer, darker, and more matte, but
the disc, actual sleeve thickness and paper texture images remain unchanged.

The front's finger-cut notch preserves the original mesh fan and outline:
a prototype that eased the notch itself produced back-facing triangles and
a visible cover-art hole in WebGL. In addition to material/UV tests, regression
tests now require consistent winding and preserved print area as well as
rounded substrate corners on all five actual paper shell parts.

Editable Blender sources are stored in source-assets/paper-sleeves, alongside
immutable original imported GLBs. Run Blender 5.x in background mode against
scripts/refine-paper-sleeves.py, followed by npm test.

The export retains Print_front, Print_back, Print_spine, Paper_Cut and
animation/GLB node contracts; existing published photo region mappings,
spine texture and disc animations do not need migration.


## Bonded paper seam taper (0.1.6)

The 0.1.5 Mini LP and Card Sleeve profiles still showed a near-solid 3.2 mm
white wall along their top and bottom glued ends. A folded card sleeve is not
a rigid extruded box: the two ~0.38 mm plies approach one another near those
bonded seams, leaving the center pocket thick enough to accommodate the CD.

The reproducible Blender generator now uses a deterministic, smooth, 6 mm
transition at both horizontal sealed edges, including the physical paper
boards, their front/back photographs, the glued strips, the overlapping flap
and the printed spine. A depth remapping maintains the actual cardboard gauge
and is strictly monotone, so the front/back do not cross and the long spine
wall cannot turn inside out. The central packet and CD rig do not move. The
top/bottom lips end near 1.25 mm thick while central thickness remains about
3.5 mm. Cross-section vertices are inserted ahead of time to avoid sharp
kinks on the original low-poly paper substrates. The submillimetre glued
strips are already subdivided; cutting their cap faces again creates
non-manifold meshes, so they are not bisected.

Tests verify the finished GLB, not source-code constants: central disc
clearance, lip thickness, persistent front/back separation, physical spine
and glued lip dimensions, UV/triangle orientation, corner clearance, and
animation and asset-role compatibility. Blender project sources are
regenerated and saved in source-assets/paper-sleeves and are not shipped in
the browser model bundle. Existing published AlbumEntity v1 assets remain
compatible without user data migration.

## Physical insert assembly and interaction (0.1.8)

All attachment interactions are implemented by Album Engine. The host passes only an AlbumDocument, independent component image assets, and its viewer close callback. The OBI is a connected folded front/spine/back mesh with UV mapping for its own print; a booklet attaches to a hinged inside leaf; an open-mouth inner sleeve occupies a paper pocket and carries its assigned disc. Blender-authored pocket lips and fitted cavities occlude inserted paper; visible rims can be grabbed with 3D-projected finger-size tolerance. Opening first slides an OBI clear of the fold; closing returns internal inserts before the leaves fold. A CD housed in an inner sleeve becomes reachable only after withdrawing the sleeve. The engine supports reverse movement and persists no host state.

The supplied fixtures are synthetic prints used for regression only, not claims about any real pressing. Source image crops are optional per-component `region` values; absent photographs are not replaced by main album artwork. Dimensions/slots derive from the nominal reusable rigs; full bound-book pagination and measured physical tolerances require additional evidence and rig definitions. See `docs/accessory-assembly.md` for state and verification.

- 当前模型集仅对 Blender 模板尺寸保证整件装配；实测尺寸与所选模板不一致时能力检查返回不支持，宿主保留 2D 与原尺寸资料。后续须在引擎内提供对应 Blender 模型及整件净空验收，禁止整体缩放 CD 来凑尺寸。

## Independent contents and materials

The OBI clears the actual closed shell including its outward spine and paper gauge, then unfolds using 32 Blender-authored hinge poses into a horizontal ribbon directly above the album. Paper parts have their own inspection pivots; dragging a withdrawn OBI/booklet/inner sleeve rotates that object independently. A contained CD follows its sleeve until separately extracted. Return motion folds and seats the same object without replacing its mesh.

The camera initially fits the closed album to a readable card-sized footprint. Detached paper is uniformly fitted to its own inspection workspace; physical stowed dimensions remain unchanged. Contents never drive camera zoom or centering; explicit wheel/Home zoom remains available. PBR substrates distinguish uncoated/matte/gloss paper, cut stock, clear molded plastic, trays, disc hubs and aluminium. Paper grain is independent of artwork and enabled without requiring calibration.


## Readable inspection and paper folds (0.2.2)

Initial framing follows min(82vw,72vh,680px), with 69vh on narrow viewports. The camera stays on the album during extraction, rotation and paper unfolding. CD inspection is capped below the full viewport. Free CD/OBI/booklet/sleeve pivots include independent in-plane roll: drag the rim, Shift-drag, or Q/E for 90-degree turns; Home resets attitude. Drag the center to yaw/pitch. Double-click a withdrawn foldout or press F to unfold/refold; single click returns it after refolding, and case close waits for that stack to seat. This is a nominal accordion mechanism, not an assertion about unmeasured real fold types.

Optional canonical booklet fold metadata preserves full front/back sources. Per-panel Blender UVs partition the entire sheet exactly once; missing reverse art stays missing. Editing an unchanged component must preserve its folding/print metadata. Ordinary booklets remain whole objects.

## Installable engine (0.3.0)

`npm run plugin:build` builds `artifacts/album-engine-plugin-0.3.0.zip`. It contains a self-contained browser ES module, its external stylesheet and lazy renderer/editor chunks, the pure standard-library runtime, and all shipped Blender GLBs. `manifest.json` declares `id`, `pluginProtocol`, engine/model/schema/rig versions, entry/style/runtime/models paths and a SHA-256 map for every other archive member. The manifest itself is authenticated by the host's official package catalog hash. No host React singleton, CDN, pip installation or Blender runtime is required.

The browser entry exports `manifest`, `inspectAlbum`, `requestAlbumOrientationPermission`, `editionMaterialSources`, `spineCalibrationFit`, `spineCalibrationFitForEntity`, and `mount(kind, element, props)`. Mount kinds are `viewer`, `guided-editor`, `accessories-editor`, and `disc-calibration-editor`; props match their existing engine component interfaces. Each mount owns a React root and resolves to an idempotent disposal callback. Importing the entry performs no orientation request, WebGL creation, model fetch or generation; the host explicitly mounts only after user action. The host must dispose mounted roots when uninstalling and owns install authorization, immutable package verification and user asset access.

Persistence exports are generated separately:

```sh
python3 scripts/export-data-codec.py --python-output /path/to/host/vendor/album_data --web-output /path/to/host/web/src/vendor/album-data
```

These generated directories have their own version/hash manifest. Python exports only errors, packaging/contracts/schema validation and document compilation for host transactions; no worker, network, generation, rendering, input or model files are retained. TypeScript contains packaging metadata helpers and wire types only. These codecs remain installed with the core host so backup, restore and ordinary 2D metadata remain readable after engine uninstall. The host retains user documents and content-addressed GLB/texture snapshots independently of the executable plugin.

Canonical documents may carry `presentation.initialCamera` with optional `pitch`, `yaw`, `zoom`, `framingX`, and `framingY`. Angles use radians (pitch ±72°, yaw ±2π), zoom is 0.7–2, and framing is ±0.5 of visible width/height. Absent fields preserve the existing viewer defaults. Cleaning, publication and restore validate and retain this authored profile, which drives the viewer's initial pose/framing. Interactive dragging, extraction and sensor movement do not write it back. No new camera editing UI or automatic per-frame persistence is provided.
