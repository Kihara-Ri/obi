"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MODEL_RIG_VERSION = exports.ENTITY_SCHEMA_VERSION = void 0;
exports.ENTITY_SCHEMA_VERSION = 1;
exports.MODEL_RIG_VERSION = 1;
