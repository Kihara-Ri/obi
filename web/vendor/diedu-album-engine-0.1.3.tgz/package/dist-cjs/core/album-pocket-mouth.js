"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaperPocketMouth = void 0;
const three_1 = require("three");
/** A paper pocket opens slightly at its mouth; the album's spine stays still. */
class PaperPocketMouth {
    mouth;
    lip;
    position;
    quaternion;
    closed;
    walls = [];
    angle = 0;
    constructor(pocket, mouth) {
        this.mouth = mouth;
        this.lip = pocket.children.find(object => object.userData.pocketLip);
        this.position = this.lip.position.clone();
        this.quaternion = this.lip.quaternion.clone();
        pocket.updateWorldMatrix(true, true);
        const local = new three_1.Matrix4().copy(pocket.matrixWorld).invert(), box = new three_1.Box3();
        this.lip.traverse(mesh => {
            if (!(mesh instanceof three_1.Mesh))
                return;
            mesh.geometry.computeBoundingBox();
            box.union(mesh.geometry.boundingBox.clone().applyMatrix4(new three_1.Matrix4().multiplyMatrices(local, mesh.matrixWorld)));
        });
        this.closed = mouth > 0 ? box.min.x : box.max.x;
        for (const mesh of pocket.children) {
            if (!(mesh instanceof three_1.Mesh) || !mesh.userData.pocketWall)
                continue;
            const geometry = mesh.geometry.clone(), position = geometry.attributes.position;
            mesh.geometry = geometry;
            position.setUsage(three_1.DynamicDrawUsage);
            geometry.computeBoundingBox();
            const toPocket = new three_1.Matrix4().multiplyMatrices(local, mesh.matrixWorld);
            this.walls.push({ geometry, basis: Float32Array.from(position.array), toPocket, fromPocket: toPocket.clone().invert(),
                min: geometry.boundingBox.min.y, height: geometry.boundingBox.max.y - geometry.boundingBox.min.y });
        }
    }
    paint(out) {
        const t = Math.max(0, Math.min(1, out / .12)), angle = Math.PI / 90 * t * t * (3 - 2 * t);
        if (angle === this.angle)
            return angle;
        this.angle = angle;
        const cosine = Math.cos(angle), sine = Math.sin(angle);
        this.lip.position.copy(this.position);
        this.lip.position.x = this.closed + (this.position.x - this.closed) * cosine;
        this.lip.position.y += this.mouth * (this.position.x - this.closed) * sine;
        this.lip.quaternion.copy(this.quaternion).premultiply(new three_1.Quaternion().setFromAxisAngle(new three_1.Vector3(0, 0, 1), this.mouth * angle));
        const point = new three_1.Vector3();
        for (const { geometry, basis, toPocket, fromPocket, min, height } of this.walls) {
            const position = geometry.attributes.position;
            for (let i = 0; i < position.count; i++) {
                point.fromArray(basis, i * 3);
                const amount = Math.max(0, Math.min(1, (point.y - min) / height));
                point.applyMatrix4(toPocket);
                const span = point.x - this.closed;
                point.x += span * (cosine - 1) * amount;
                point.y += this.mouth * span * sine * amount;
                point.applyMatrix4(fromPocket);
                position.setXYZ(i, point.x, point.y, point.z);
            }
            position.needsUpdate = true;
            geometry.computeVertexNormals();
            geometry.computeBoundingBox();
            geometry.computeBoundingSphere();
        }
        this.lip.updateWorldMatrix(true, true);
        return angle;
    }
    dispose() { for (const wall of this.walls)
        wall.geometry.dispose(); }
}
exports.PaperPocketMouth = PaperPocketMouth;
