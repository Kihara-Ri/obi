"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.accessoryLabel = void 0;
exports.buildAccessory = buildAccessory;
exports.validAccessories = validAccessories;
/** Parametric loose printed components in the model's original Y-up space.
 *
 * The base package remains an artist-authored GLB. Supplements are independently
 * textured and extracted; no component is inferred from a main cover texture.
 */
const THREE = __importStar(require("three"));
const accessoryLabel = (kind) => kind === 'obi' ? '侧标 OBI' : kind === 'booklet' ? '歌词册' : '内袋';
exports.accessoryLabel = accessoryLabel;
const SIZES = {
    obi: { width: .024, height: .135, thickness: .00028, x: -.054, y: -.004, z: 0, pullX: -.09, pullZ: .025 },
    booklet: { width: .116, height: .116, thickness: .0014, x: 0, y: -.005, z: 0, pullX: .145, pullZ: .055 },
    'inner-sleeve': { width: .124, height: .125, thickness: .0009, x: 0, y: -.006, z: 0, pullX: .14, pullZ: -.03 },
};
/** A thin paper solid and a distinct full-color printed face. */
function buildAccessory(entry, texture) {
    const spec = SIZES[entry.kind], body = new THREE.Group();
    body.name = 'Accessory_' + entry.id;
    body.userData = { accessoryId: entry.id, kind: entry.kind };
    const base = new THREE.MeshStandardMaterial({ color: entry.kind === 'obi' ? 0xe7e0cf : 0xf0eddf, roughness: .92 });
    const front = new THREE.MeshStandardMaterial({
        map: texture, color: 0xffffff, side: THREE.DoubleSide, roughness: .8, metalness: 0,
    });
    const core = new THREE.BoxGeometry(spec.width, spec.thickness, spec.height);
    const shell = new THREE.Mesh(core, base);
    shell.name = 'Paper_' + entry.kind;
    body.add(shell);
    const face = new THREE.PlaneGeometry(spec.width, spec.height);
    face.rotateX(-Math.PI / 2);
    const print = new THREE.Mesh(face, front);
    print.name = 'Print_' + entry.kind;
    print.position.y = spec.thickness * .55;
    body.add(print);
    const home = new THREE.Vector3(spec.x, spec.y, spec.z);
    const extract = new THREE.Vector3(spec.x + spec.pullX, spec.y - .012, spec.z + spec.pullZ);
    body.position.copy(home);
    return { placement: { group: body, home, extract, id: entry.id, kind: entry.kind },
        geometries: [core, face], materials: [base, front] };
}
/** Host and engine agree on a stable order; no unknown insert is synthesized. */
function validAccessories(record) {
    const seen = new Set();
    return (record.modelAccessories ?? []).filter(item => {
        if (!/^[a-z][a-z0-9-]{0,39}$/.test(item.id) || seen.has(item.id))
            return false;
        if (!['obi', 'booklet', 'inner-sleeve'].includes(item.kind) || !item.source)
            return false;
        seen.add(item.id);
        return true;
    }).slice(0, 8).map(({ id, kind, source }) => ({ id, kind, source }));
}
