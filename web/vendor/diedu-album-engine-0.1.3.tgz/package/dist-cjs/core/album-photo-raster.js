"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rasterPackagingPhoto = rasterPackagingPhoto;
const album_photo_projection_1 = require("./album-photo-projection");
/** CPU counterpart of the printed-plane shader, also available without WebGL. */
function rasterPackagingPhoto(pixels, width, height, region, warpRows, maxEdge = 768) {
    const rows = warpRows && (0, album_photo_projection_1.validPhotoWarpRows)(warpRows) ? warpRows : undefined;
    const matrix = !rows && region ? (0, album_photo_projection_1.photoProjection)(region) : null;
    if (!rows && !matrix)
        return null;
    const corners = rows ? [...rows[0], rows.at(-1)[2], rows.at(-1)[3], rows.at(-1)[0], rows.at(-1)[1]] : region;
    const edge = (a, b) => Math.hypot((corners[a] - corners[b]) * width, (corners[a + 1] - corners[b + 1]) * height);
    const w = Math.max(edge(0, 2), edge(6, 4)), h = Math.max(edge(0, 6), edge(2, 4));
    const scale = Math.min(1, maxEdge / Math.max(w, h));
    const outWidth = Math.max(1, Math.ceil(w * scale)), outHeight = Math.max(1, Math.ceil(h * scale));
    const data = new Uint8ClampedArray(outWidth * outHeight * 4);
    for (let y = 0; y < outHeight; y++) {
        const v = (y + .5) / outHeight;
        const strip = rows ? Math.min(rows.length - 2, Math.floor(v * (rows.length - 1))) : 0;
        const t = rows ? v * (rows.length - 1) - strip : 0;
        for (let x = 0; x < outWidth; x++) {
            const u = (x + .5) / outWidth;
            let sx, sy;
            if (rows) {
                const a = rows[strip], b = rows[strip + 1];
                sx = ((a[0] * (1 - u) + a[2] * u) * (1 - t) + (b[0] * (1 - u) + b[2] * u) * t) * width - .5;
                sy = ((a[1] * (1 - u) + a[3] * u) * (1 - t) + (b[1] * (1 - u) + b[3] * u) * t) * height - .5;
            }
            else {
                const m = matrix, denominator = m[6] * u + m[7] * v + 1;
                sx = (m[0] * u + m[1] * v + m[2]) / denominator * width - .5;
                sy = (m[3] * u + m[4] * v + m[5]) / denominator * height - .5;
            }
            sx = Math.max(0, Math.min(width - 1, sx));
            sy = Math.max(0, Math.min(height - 1, sy));
            const ix = Math.floor(sx), iy = Math.floor(sy), dx = sx - ix, dy = sy - iy;
            const at = (px, py) => (py * width + px) * 4;
            const a = at(ix, iy), b = at(Math.min(width - 1, ix + 1), iy), c = at(ix, Math.min(height - 1, iy + 1)), d = at(Math.min(width - 1, ix + 1), Math.min(height - 1, iy + 1));
            for (let channel = 0; channel < 4; channel++)
                data[(y * outWidth + x) * 4 + channel] =
                    (pixels[a + channel] * (1 - dx) + pixels[b + channel] * dx) * (1 - dy)
                        + (pixels[c + channel] * (1 - dx) + pixels[d + channel] * dx) * dy;
        }
    }
    return { data, width: outWidth, height: outHeight };
}
