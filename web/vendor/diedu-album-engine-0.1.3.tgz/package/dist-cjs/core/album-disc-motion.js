"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.advanceDiscMotion = advanceDiscMotion;
exports.discFramingRoom = discFramingRoom;
/** Disc progress and the associated camera margin share one continuous clock. */
function advanceDiscMotion(motion, goal, seconds) {
    if (seconds <= 0)
        return motion;
    // Critical damping starts at rest and preserves velocity on reversal. The
    // analytic step produces the same motion at different display refresh rates.
    const rate = 5, error = motion.out - goal, speed = motion.velocity + rate * error;
    const decay = Math.exp(-rate * seconds);
    return { out: goal + (error + speed * seconds) * decay,
        velocity: (motion.velocity - rate * speed * seconds) * decay };
}
function discFramingRoom(out, pocket) {
    const smooth = (value) => { const t = Math.max(0, Math.min(1, value)); return t * t * (3 - 2 * t); };
    return pocket ? .09 * smooth(out / .52) * (1 - smooth((out - .52) / .48)) : 0;
}
