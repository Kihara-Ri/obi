"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.spineCalibrationFit = spineCalibrationFit;
const album_packaging_1 = require("./album-packaging");
const album_model_assets_1 = require("./album-model-assets");
/** The form and renderer use the same nominal geometry and CD clearance rule. */
function spineCalibrationFit(record) {
    const calibration = record.modelCalibration?.spine, model = (0, album_packaging_1.albumPackaging)(record.packaging);
    if (!calibration || !['gatefold', 'digipak', 'digibook'].includes(model.kind))
        return null;
    const inward = model.kind === 'gatefold' && model.holder === 'pocket' && model.pocketOpening === 'inner';
    const nominalWidth = inward ? 138 : model.kind === 'digipak' ? 139 : model.kind === 'digibook' ? 140 : 135;
    const compactPockets = model.kind === 'gatefold' && model.holder === 'pocket' && model.miniLP && !inward
        && Array.from({ length: model.panels }, (_, i) => (0, album_model_assets_1.albumPanelDiscs)(model, i).length).every(count => count <= 1);
    const minimumGap = Array.from({ length: model.panels }, (_, panel) => {
        const count = (0, album_model_assets_1.albumPanelDiscs)(model, panel).length;
        return !count ? 0 : model.holder === 'pocket'
            ? (inward ? 2.07 : compactPockets ? 2.5 : 3.8) + (count - 1) * 1.25 : 4.8 + (count - 1) * 1.8;
    }).reduce((a, b) => a + b, inward ? .12 : .7);
    const nominalGap = (inward ? 4.6 : model.kind === 'digibook' ? 13 : model.kind === 'digipak' ? 7 : 4) * (model.panels - 1);
    const flat = inward || model.kind === 'gatefold' && model.panels === 2 && model.miniLP && model.holder === 'pocket' && model.pocketOpening === 'outer';
    const arc = flat ? 1 : Math.PI / 2;
    const requested = calibration.widthRatio * (record.packaging?.size?.width ?? nominalWidth), minimum = Math.max(minimumGap, model.kind === 'digibook' ? 13 : 0) * arc;
    const applied = Math.max(requested, minimum);
    return { basis: calibration.basis, status: requested < minimum ? 'minimum-cd-fit' : 'applied',
        requestedMm: requested, appliedMm: applied, minimumMm: minimum,
        factor: applied / (nominalGap * arc), compactPockets };
}
