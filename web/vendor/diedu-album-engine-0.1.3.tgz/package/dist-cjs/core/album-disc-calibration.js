"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validDiscEllipse = validDiscEllipse;
exports.validDiscCalibration = validDiscCalibration;
exports.discEllipsePoint = discEllipsePoint;
exports.rasterDisc = rasterDisc;
exports.detectDiscEllipse = detectDiscEllipse;
function validDiscEllipse(e) {
    return !!e && [e.cx, e.cy, e.rx, e.ry, e.angle].every(Number.isFinite)
        && e.cx >= 0 && e.cx <= 1 && e.cy >= 0 && e.cy <= 1
        && e.rx >= .025 && e.rx <= 1 && e.ry >= .025 && e.ry <= 1
        && Math.abs(e.angle) <= Math.PI && e.rx / e.ry >= .18 && e.rx / e.ry <= 5.5
        && e.cx - Math.hypot(e.rx * Math.cos(e.angle), e.ry * Math.sin(e.angle)) >= -.015
        && e.cx + Math.hypot(e.rx * Math.cos(e.angle), e.ry * Math.sin(e.angle)) <= 1.015
        && e.cy - Math.hypot(e.rx * Math.sin(e.angle), e.ry * Math.cos(e.angle)) >= -.015
        && e.cy + Math.hypot(e.rx * Math.sin(e.angle), e.ry * Math.cos(e.angle)) <= 1.015;
}
function validDiscCalibration(cal) {
    if (!cal || !validDiscEllipse(cal.outer) || !['auto', 'manual'].includes(cal.source))
        return false;
    if (cal.inner && (!validDiscEllipse(cal.inner)
        || cal.inner.rx >= cal.outer.rx * .85 || cal.inner.ry >= cal.outer.ry * .85
        || Math.hypot(cal.inner.cx - cal.outer.cx, cal.inner.cy - cal.outer.cy) > Math.max(cal.outer.rx, cal.outer.ry) * .4))
        return false;
    return cal.confidence === undefined || Number.isFinite(cal.confidence) && cal.confidence >= 0 && cal.confidence <= 1;
}
function discEllipsePoint(ellipse, t) {
    return [ellipse.cx + ellipse.rx * Math.cos(t) * Math.cos(ellipse.angle) - ellipse.ry * Math.sin(t) * Math.sin(ellipse.angle),
        ellipse.cy + ellipse.rx * Math.cos(t) * Math.sin(ellipse.angle) + ellipse.ry * Math.sin(t) * Math.cos(ellipse.angle)];
}
/** Rectifies the oblique *printed disc* into a true circular 2D texture.
 * Uses the outer rim for the affine rectification, with a smooth correction
 * around an independently marked centre ring when one is available.
 * Leaves the source image unchanged. */
function rasterDisc(pixels, width, height, cal, size = 768) {
    if (!validDiscCalibration(cal) || width < 2 || height < 2 || pixels.length !== width * height * 4)
        return null;
    const edge = Math.max(16, Math.min(1536, Math.floor(size)));
    const data = new Uint8ClampedArray(edge * edge * 4);
    const outer = cal.outer, inner = cal.inner;
    // The disc's centre hole has a nominal diameter of 15/120; the visual hub
    // ring commonly extends further, so use the annotated inner ring's ratio.
    const innerFraction = inner ? Math.min(.8, Math.max(.125, Math.sqrt(inner.rx * inner.ry / (outer.rx * outer.ry)))) : 0;
    const bilinear = (x, y, dest) => {
        x = Math.min(width - 1, Math.max(0, x));
        y = Math.min(height - 1, Math.max(0, y));
        const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
        const a = (iy * width + ix) * 4, b = (iy * width + Math.min(width - 1, ix + 1)) * 4, c = (Math.min(height - 1, iy + 1) * width + ix) * 4, dd = (Math.min(height - 1, iy + 1) * width + Math.min(width - 1, ix + 1)) * 4;
        for (let k = 0; k < 4; k++)
            data[dest + k] = (pixels[a + k] * (1 - fx) + pixels[b + k] * fx) * (1 - fy)
                + (pixels[c + k] * (1 - fx) + pixels[dd + k] * fx) * fy;
    };
    for (let y = 0; y < edge; y++)
        for (let x = 0; x < edge; x++) {
            const u = (x + .5) / edge * 2 - 1, v = (y + .5) / edge * 2 - 1, r = Math.hypot(u, v);
            if (r > 1)
                continue;
            const t = Math.atan2(v, u);
            const [ox, oy] = discEllipsePoint(outer, t);
            let px = outer.cx + (ox - outer.cx) * r, py = outer.cy + (oy - outer.cy) * r;
            if (inner) {
                const [ix, iy] = discEllipsePoint(inner, t);
                // Interpolate the projected radius around the inner reference ring,
                // using the inner ellipse centre at r=0.
                if (r <= innerFraction) {
                    px = inner.cx + (ix - inner.cx) * r / innerFraction;
                    py = inner.cy + (iy - inner.cy) * r / innerFraction;
                }
                else {
                    const blend = (r - innerFraction) / (1 - innerFraction);
                    px = ix + (ox - ix) * blend;
                    py = iy + (oy - iy) * blend;
                }
            }
            bilinear(px * width - .5, py * height - .5, (y * edge + x) * 4);
        }
    return { data, width: edge, height: edge };
}
/** Fast, conservative edge-fitting of the outer rim. Never infer a tilted
 * view from a printed inner circle alone: absence of an identifiable
 * perimeter yields null and keeps the original texture. */
function detectDiscEllipse(pixels, width, height) {
    if (width < 60 || height < 60 || pixels.length !== width * height * 4)
        return null;
    const factor = Math.min(1, 320 / Math.max(width, height));
    const w = Math.max(16, Math.round(width * factor)), h = Math.max(16, Math.round(height * factor));
    const luminance = new Float32Array(w * h);
    for (let y = 0; y < h; y++)
        for (let x = 0; x < w; x++) {
            const ox = Math.min(width - 1, Math.floor((x + .5) * width / w)), oy = Math.min(height - 1, Math.floor((y + .5) * height / h));
            const at = (oy * width + ox) * 4;
            luminance[y * w + x] = .2126 * pixels[at] + .7152 * pixels[at + 1] + .0722 * pixels[at + 2];
        }
    const sample = (x, y) => {
        const xi = Math.round(x), yi = Math.round(y);
        return xi < 1 || yi < 1 || xi >= w - 1 || yi >= h - 1 ? null : luminance[yi * w + xi];
    };
    const min = Math.min(w, h), angles = Array.from({ length: 64 }, (_, i) => i * Math.PI / 32);
    const state = { best: null };
    const radii = [.3, .34, .38, .42, .46, .49];
    // Broad centre search, then a small local refinement; angle is only used
    // where the axial ratio differs enough to resolve the principal direction.
    const score = (e) => {
        let strength = 0, hits = 0, total = 0;
        for (const t of angles) {
            const [nx, ny] = discEllipsePoint(e, t);
            const cx = e.cx * w, cy = e.cy * h, px = nx * w, py = ny * h, dx = px - cx, dy = py - cy, len = Math.hypot(dx, dy);
            const inside = sample(px - dx / len * 2, py - dy / len * 2), outside = sample(px + dx / len * 2, py + dy / len * 2);
            if (inside === null || outside === null)
                continue;
            const diff = Math.abs(inside - outside);
            strength += Math.min(70, diff);
            if (diff > 13)
                hits++;
            total++;
        }
        if (total < 60)
            return { score: 0, hits: 0 };
        // Distinguish a coherent rim from occasional lettering / glare.
        return { score: strength / total * Math.pow(hits / total, 2), hits: hits / total };
    };
    const evaluate = (e) => {
        if (!validDiscEllipse(e))
            return;
        const r = score(e);
        if (!state.best || r.score > state.best.score)
            state.best = { e, score: r.score, hits: r.hits };
    };
    for (const cx of [.4, .5, .6])
        for (const cy of [.4, .5, .6])
            for (const radius of radii)
                for (const ratio of [1, .85, .7, .55])
                    for (const angle of [0, Math.PI / 4, Math.PI / 2, 3 * Math.PI / 4]) {
                        const rx = radius * min / w, ry = radius * ratio * min / h;
                        evaluate({ cx, cy, rx, ry, angle });
                    }
    if (!state.best)
        return null;
    const step = .035 * min;
    for (const span of [1, .45, .2]) {
        const centre = state.best.e;
        for (const dx of [-1, 0, 1])
            for (const dy of [-1, 0, 1])
                for (const dr of [-1, 0, 1])
                    for (const ratio of [-1, 0, 1]) {
                        const e = { ...centre, cx: centre.cx + dx * step * span / w, cy: centre.cy + dy * step * span / h,
                            rx: centre.rx + dr * step * span / w, ry: centre.ry + ratio * step * span / h };
                        evaluate(e);
                    }
    }
    const best = state.best;
    if (!best || best.hits < .68 || best.score < 9)
        return null;
    // If no meaningful geometric change is detected, still return the result
    // for the manual editor, but avoid guessing at extreme incidence angles.
    const confidence = Math.min(1, Math.max(0, (best.score - 8) / 30)) * best.hits;
    if (confidence < .32)
        return null;
    return { outer: best.e, source: 'auto', confidence };
}
