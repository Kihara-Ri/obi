"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EntityArtwork = EntityArtwork;
const jsx_runtime_1 = require("react/jsx-runtime");
/** The host supplies a presentation hue; no artist or collection metadata is needed. */
function EntityArtwork({ record }) {
    return (0, jsx_runtime_1.jsxs)("span", { className: "gallery-artwork", children: [(0, jsx_runtime_1.jsx)("div", { className: `cover cover-fallback hue-${record.placeholderHue}`, role: "img", "aria-label": `${record.title}，暂无封面`, children: (0, jsx_runtime_1.jsx)("span", { children: record.title.slice(0, 1) }) }), (0, jsx_runtime_1.jsx)("span", { className: "gallery-art-message", children: "\u6682\u65E0\u5C01\u9762" })] });
}
