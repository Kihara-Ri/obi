# Album Engine

唱片包装查看器、材质、动作、镜头和模型工具链的独立仓库。npm 包名为 `@diedu/album-engine`；Studio 使用合成实体，脱离碟渡后端运行。

## 运行 Studio

```sh
npm ci
npm run studio -- --host 127.0.0.1 --port <空闲端口>
```

打开命令输出的地址。工作台提供三个固定样本、WebGL / CSS 切换、查看器关闭重开与感应授权。拖动或方向键旋转，点击包装或 Enter 开合；WebGL 中点击 CD 或使用数字键取放，Home 回正，Esc 关闭。先点击舞台，再使用键盘。感应按钮在点击时请求权限；浏览器授权结果和真实设备感应信号是两个独立的验证项。

`fixtures/entities.json` 与 `fixtures/sample-scan.png` 由碟渡的 `tools/seed_samples.py --export-engine-fixtures <输出目录>` 导出，合成场景以该样本库为准。Studio 不连接收藏 API。Vite 将 `models/packaging/` 作为同源 `/packaging/` 提供；生产构建把模型复制到 `studio-dist/packaging/`，纹理由模块导入进入构建。

## 构建与验证

```sh
npm run typecheck
npm test
npm run build
npm run studio:build
```

库构建输出在 `dist/`，Studio 构建输出在 `studio-dist/`。Studio 产物需作为网站根目录由 HTTP 服务提供。查看器样式由外部 CSS 加载，默认模型材质 token 与碟渡一致；宿主可用自身的未分层 token 覆盖界面主题。

浏览器验收覆盖三个样本、包装开合、两张 CD 的取放、CSS 回退、关闭重开及 console。浏览器结果不等于手机感应或实机帧率证据。

独立宿主边界回归：构建库后运行 `npx vite --config tests/browser/vite.config.mjs --host 127.0.0.1 --port <空闲端口>`，打开 `/standalone.html`。此页只导入公开包与样式，不定义主题 token；阴影与加载圈应正常。切换同名宿主节点后 Enter 仍能开合；显式暂停输入后姿态保持、Enter 不改变状态，恢复后继续开合。

## 宿主接口

```tsx
import {AlbumViewer, CSSAlbumViewer, requestAlbumOrientationPermission} from '@diedu/album-engine';
import type {AlbumEntity} from '@diedu/album-engine/schema';
import '@diedu/album-engine/style.css';

// 在打开查看器的点击处理函数内同步调用，保留浏览器手势授权。
const permission = requestAlbumOrientationPermission();

<AlbumViewer
  entity={entity}
  resolveAsset={asset => resolveLocalAsset(asset)}
  models={{baseUrl: '/models/packaging/', rigVersion: 1}}
  permission={permission}
  onRequestClose={closeViewer}
/>;
```

`AlbumEntity` 是 `schemaVersion: 1` 的纯实体描述，包含稳定的 `key`、`title`、包装、印刷面素材引用与可选校准。宿主负责将资产标识解析为可访问 URL，配置模型目录并响应关闭请求。`CSSAlbumViewer` 接收相同输入，可供宿主明确选用回退。查看器关闭时应卸载组件，以释放监听器与 WebGL 资源。

可选 `fallbackInputEnabled` 默认为 `true`，宿主覆盖 CSS 查看器时传 `false`，暂停感应及开合/旋转输入并保留姿态；它也适用于 WebGL 自动回退到 CSS 的情况。引擎不查询宿主灯箱或抽屉 DOM。

模型结构协议为 `rigVersion: 1`，涵盖 GLB 单位、坐标、轴心、材质名与 extras。查看器和兼容模型一起版本化；同名模型不能在保持版本不变的情况下改变结构协议。

## 更新碟渡中的包

先完成构建与验证，再生成 tarball：

```sh
npm run build
npm pack
```

tarball 自包含编译后的查看器、类型、CSS 和模型。将该文件放入碟渡 `web/vendor/`，安装本地 tarball 并更新 npm lock；碟渡前端构建会将包内模型复制到既有 `static/models/packaging/`。克隆与 Docker 构建只依赖碟渡仓库内锁定的 tarball，不要求第二个源码仓库。更换版本后完成碟渡规定的前后端、浏览器、Docker 和数据泄漏检查。

## 归属

- Album Engine：WebGL / CSS 查看器、感应与资源清理、模型、Blender 工具、投影、校准、材质、实体动作与镜头。
- 碟渡：收藏与交易、九种浏览布局、灯箱历史与浏览位置、发行版确认、生成任务、资产授权与发布事务。

当前阶段抽出完整查看器与模型工具链。生成算法的抽离属于后续阶段；本仓库不包含个人照片、账目、凭证或运行数据。


## Disc photo calibration (0.1.2)

The engine conservatively fits an outer elliptical rim on a tilted disc photograph and rasterizes it into a front-on round texture. Insufficient perimeter evidence leaves the source texture unchanged. Each disc surface supports discCalibration with source, outer and optional inner ellipses, in normalized image coordinates with angles in radians. Manual calibration overrides auto detection. Both WebGL and CSS fallback use the same rectification; sources remain untouched and the host manages persistence.
