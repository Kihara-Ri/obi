"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumModel = AlbumModel;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const album_packaging_1 = require("../core/album-packaging");
const album_model_assets_1 = require("../core/album-model-assets");
const album_disc_motion_1 = require("../core/album-disc-motion");
const CSSAlbumModel_1 = require("./CSSAlbumModel");
const useAlbumOrientation_1 = require("./useAlbumOrientation");
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
/** One lazy WebGL scene per lightbox; gallery tracks retain their small CSS proxies. */
function AlbumModel({ record, permission, fallbackInputEnabled, onDismiss }) {
    return (0, jsx_runtime_1.jsx)(AlbumModelSession, { record: record, permission: permission, fallbackInputEnabled: fallbackInputEnabled, onDismiss: onDismiss }, (0, album_model_assets_1.albumSceneIdentity)(record));
}
function AlbumModelSession({ record, permission, fallbackInputEnabled, onDismiss }) {
    const stage = (0, react_1.useRef)(null);
    const [input] = (0, react_1.useState)(() => ({ record, model: (0, album_packaging_1.albumPackaging)(record.packaging) }));
    const scene = (0, react_1.useRef)(null);
    const pose = (0, react_1.useRef)({ x: -8, y: -16, open: 0, zoom: 1, disc: { index: -1, out: 0, x: 0, y: 0 }, hint: { index: -1, amount: 0 } });
    const base = (0, react_1.useRef)({ x: -8, y: -16 });
    const discBase = (0, react_1.useRef)({ x: -8, y: -12 });
    const offset = (0, react_1.useRef)({ x: 0, y: 0 });
    const target = (0, react_1.useRef)({ x: -8, y: -16, open: 0, discOut: 0, hintIndex: -1 });
    const mouse = (0, react_1.useRef)(null);
    const nextDisc = (0, react_1.useRef)(null);
    const discVelocity = (0, react_1.useRef)(0);
    const closeAfterReturn = (0, react_1.useRef)(false);
    const requestedOpen = (0, react_1.useRef)(false);
    const frame = (0, react_1.useRef)(0);
    const reduced = (0, react_1.useRef)(false);
    const live = (0, react_1.useRef)(!document.hidden);
    const drag = (0, react_1.useRef)(null);
    const tapCase = (0, react_1.useRef)(null);
    const trailing = (0, react_1.useRef)(false);
    const [dragging, setDragging] = (0, react_1.useState)(false);
    const [fallback, setFallback] = (0, react_1.useState)(false);
    const [opened, setOpened] = (0, react_1.useState)(false);
    const [ready, setReady] = (0, react_1.useState)(false);
    const [discStatus, setDiscStatus] = (0, react_1.useState)('');
    const [inspecting, setInspecting] = (0, react_1.useState)(false);
    const model = input.model;
    const move = (0, react_1.useCallback)((instant = false) => {
        target.current.x = clamp(base.current.x + offset.current.x, -72, 72);
        target.current.y = base.current.y + offset.current.y;
        if (instant || reduced.current) {
            pose.current.x = target.current.x;
            pose.current.y = target.current.y;
        }
        if (reduced.current)
            pose.current.open = target.current.open;
        if (!live.current || frame.current)
            return;
        let previous = performance.now();
        const tick = (now) => {
            const dt = clamp((now - previous) / 1000, 0, .05);
            previous = now;
            const shown = pose.current, goal = target.current;
            const amount = 1 - Math.exp(-20 * dt);
            shown.x += (goal.x - shown.x) * amount;
            shown.y += (goal.y - shown.y) * amount;
            shown.open += (goal.open - shown.open) * (reduced.current ? 1 : 1 - Math.exp(-12 * dt));
            const discMotion = reduced.current ? { out: goal.discOut, velocity: 0 }
                : (0, album_disc_motion_1.advanceDiscMotion)({ out: shown.disc.out, velocity: discVelocity.current }, goal.discOut, dt);
            shown.disc.out = discMotion.out;
            discVelocity.current = discMotion.velocity;
            let hintGoal = shown.hint.index === goal.hintIndex && goal.hintIndex >= 0 ? 1 : 0;
            if (goal.discOut && shown.disc.index === shown.hint.index && shown.disc.out < .52)
                hintGoal = shown.hint.amount;
            shown.hint.amount += (hintGoal - shown.hint.amount) * (1 - Math.exp(-16 * dt));
            if (Math.abs(hintGoal - shown.hint.amount) < .001) {
                shown.hint.amount = hintGoal;
                if (!hintGoal)
                    shown.hint.index = goal.hintIndex;
            }
            if (Math.abs(goal.discOut - shown.disc.out) < .001) {
                shown.disc.out = goal.discOut;
                discVelocity.current = 0;
                if (!goal.discOut) {
                    if (nextDisc.current !== null) {
                        shown.disc = { index: nextDisc.current, out: 0, x: -8, y: -12 };
                        goal.discOut = 1;
                        nextDisc.current = null;
                        discBase.current = { x: -8, y: -12 };
                    }
                    else {
                        setInspecting(false);
                        if (closeAfterReturn.current) {
                            goal.open = 0;
                            closeAfterReturn.current = false;
                        }
                    }
                }
            }
            const caseSettled = Math.abs(goal.x - shown.x) + Math.abs(goal.y - shown.y) < .02
                && Math.abs(goal.open - shown.open) < .001 && Math.abs(goal.discOut - shown.disc.out) < .001;
            if (caseSettled) {
                shown.x = goal.x;
                shown.y = goal.y;
                shown.open = goal.open;
            }
            scene.current?.paint(shown);
            // Recheck after tilting: the pointer can stay still while the package moves.
            const pointer = mouse.current;
            if (pointer && !drag.current && !goal.discOut && !reduced.current) {
                goal.hintIndex = scene.current?.hoverDisc(pointer.x, pointer.y, goal.hintIndex) ?? -1;
            }
            if (stage.current)
                stage.current.dataset.discHover = String(goal.hintIndex >= 0);
            const settled = caseSettled && shown.hint.index === goal.hintIndex
                && Math.abs((goal.hintIndex >= 0 ? 1 : 0) - shown.hint.amount) < .001;
            frame.current = settled ? 0 : requestAnimationFrame(tick);
        };
        frame.current = requestAnimationFrame(tick);
    }, []);
    const onTilt = (0, react_1.useCallback)((x, y) => {
        if (pose.current.disc.out > 0 || target.current.discOut) {
            pose.current.disc.x = clamp(discBase.current.x + x, -65, 65);
            pose.current.disc.y = discBase.current.y + y;
        }
        else
            offset.current = { x, y };
        move();
    }, [move]);
    const motion = (0, useAlbumOrientation_1.useAlbumOrientation)({ active: ready && !dragging && !fallback, permission, onTilt });
    (0, react_1.useEffect)(() => {
        let alive = true;
        const space = stage.current;
        if (!space || fallback)
            return;
        // Disposal intentionally loses its GL context. Never reuse that canvas,
        // including React's effect replay or late context-loss events after cleanup.
        const surface = document.createElement('canvas');
        surface.className = 'album-webgl-canvas';
        surface.setAttribute('aria-hidden', 'true');
        space.prepend(surface);
        setReady(false);
        let owned = null;
        const wheel = (event) => {
            event.preventDefault();
            pose.current.zoom = clamp(pose.current.zoom * Math.exp(-event.deltaY * .001), .7, 2);
            move();
        };
        const contextLost = () => { if (alive)
            setFallback(true); };
        space.addEventListener('wheel', wheel, { passive: false });
        surface.addEventListener('webglcontextlost', contextLost);
        void Promise.resolve().then(() => __importStar(require('../core/album-scene'))).then(async ({ AlbumScene }) => {
            if (!alive)
                return;
            const instance = new AlbumScene(space, surface, input.record, input.model);
            owned = instance;
            scene.current = instance;
            await instance.load();
            if (alive) {
                instance.paint(pose.current);
                setReady(true);
            }
        }).catch(() => {
            owned?.dispose();
            if (alive) {
                scene.current = null;
                setFallback(true);
            }
        });
        return () => {
            alive = false;
            space.removeEventListener('wheel', wheel);
            surface.removeEventListener('webglcontextlost', contextLost);
            owned?.dispose();
            if (scene.current === owned)
                scene.current = null;
            surface.remove();
        };
    }, [input, fallback, move]);
    (0, react_1.useEffect)(() => {
        const media = matchMedia('(prefers-reduced-motion: reduce)');
        const preference = () => {
            reduced.current = media.matches;
            offset.current = { x: 0, y: 0 };
            mouse.current = null;
            target.current.hintIndex = -1;
            pose.current.hint = { index: -1, amount: 0 };
            move(true);
        };
        const visibility = () => {
            live.current = !document.hidden;
            if (!live.current) {
                mouse.current = null;
                target.current.hintIndex = -1;
                pose.current.hint = { index: -1, amount: 0 };
                cancelAnimationFrame(frame.current);
                frame.current = 0;
            }
            else
                move(true);
        };
        preference();
        media.addEventListener('change', preference);
        document.addEventListener('visibilitychange', visibility);
        return () => {
            cancelAnimationFrame(frame.current);
            frame.current = 0;
            media.removeEventListener('change', preference);
            document.removeEventListener('visibilitychange', visibility);
        };
    }, [move]);
    const clearHint = () => { mouse.current = null; target.current.hintIndex = -1; };
    const stopDrag = () => {
        const pointer = drag.current;
        if (pointer?.moved)
            trailing.current = true;
        drag.current = null;
        setDragging(false);
        if (pointer && stage.current?.hasPointerCapture(pointer.id))
            stage.current.releasePointerCapture(pointer.id);
        motion.recalibrate();
    };
    const down = (event) => {
        tapCase.current = null;
        clearHint();
        move();
        if (!event.isPrimary) {
            stopDrag();
            trailing.current = true;
            return;
        }
        trailing.current = false;
        if (!ready || event.button !== 0 || event.clientX < 28 || drag.current)
            return;
        const hit = scene.current?.pick(event.clientX, event.clientY);
        if (!hit)
            return;
        tapCase.current = hit;
        const inspecting = hit.disc === pose.current.disc.index && pose.current.disc.out > .95;
        if (inspecting)
            discBase.current = { x: pose.current.disc.x, y: pose.current.disc.y };
        else {
            base.current = { x: pose.current.x, y: pose.current.y };
            offset.current = { x: 0, y: 0 };
        }
        drag.current = { id: event.pointerId, x: event.clientX, y: event.clientY,
            rx: inspecting ? pose.current.disc.x : base.current.x, ry: inspecting ? pose.current.disc.y : base.current.y,
            width: event.currentTarget.clientWidth, moved: false, disc: inspecting };
        setDragging(true);
        event.currentTarget.focus({ preventScroll: true });
        event.currentTarget.setPointerCapture(event.pointerId);
    };
    const pointerMove = (event) => {
        const start = drag.current;
        if (start?.id === event.pointerId) {
            if (Math.hypot(event.clientX - start.x, event.clientY - start.y) > 6)
                start.moved = true;
            const rotation = { x: clamp(start.rx - (event.clientY - start.y) / start.width * 150, -65, 65),
                y: start.ry + (event.clientX - start.x) / start.width * (start.disc ? 360 : 220) };
            if (start.disc) {
                pose.current.disc.x = rotation.x;
                pose.current.disc.y = rotation.y;
                discBase.current = rotation;
            }
            else
                base.current = rotation;
            move(true);
            return;
        }
        if (!ready || event.pointerType !== 'mouse' || event.buttons || reduced.current || inspecting) {
            clearHint();
            move();
            return;
        }
        mouse.current = { x: event.clientX, y: event.clientY };
        target.current.hintIndex = scene.current?.hoverDisc(event.clientX, event.clientY, target.current.hintIndex) ?? -1;
        if (!motion.intended) {
            const rect = event.currentTarget.getBoundingClientRect();
            offset.current = { x: (.5 - clamp((event.clientY - rect.top) / rect.height, 0, 1)) * 24,
                y: (clamp((event.clientX - rect.left) / rect.width, 0, 1) - .5) * 32 };
        }
        move();
    };
    const toggle = () => {
        if (!ready || !model.canOpen)
            return;
        clearHint();
        requestedOpen.current = !requestedOpen.current;
        closeAfterReturn.current = !requestedOpen.current && pose.current.disc.out > 0;
        nextDisc.current = null;
        if (!requestedOpen.current) {
            target.current.discOut = 0;
            setDiscStatus('');
        }
        target.current.open = closeAfterReturn.current ? 1 : Number(requestedOpen.current);
        setOpened(requestedOpen.current);
        move();
    };
    const takeDisc = (index) => {
        if (!ready || (model.canOpen && (!requestedOpen.current || pose.current.open < .9)) || !scene.current?.discIndices.includes(index))
            return;
        clearHint();
        closeAfterReturn.current = false;
        const disc = pose.current.disc;
        setInspecting(true);
        if (disc.index === index && target.current.discOut) {
            target.current.discOut = 0;
            nextDisc.current = null;
            setDiscStatus('CD ' + (index + 1) + ' 放回原位');
        }
        else if (disc.out > 0 && disc.index !== index) {
            target.current.discOut = 0;
            nextDisc.current = index;
            setDiscStatus('CD ' + (index + 1) + ' 取出查看');
        }
        else {
            if (disc.index !== index || !disc.out) {
                pose.current.disc = { index, out: 0, x: -8, y: -12 };
                discBase.current = { x: -8, y: -12 };
            }
            target.current.discOut = 1;
            nextDisc.current = null;
            setDiscStatus('CD ' + (index + 1) + ' 取出查看');
        }
        offset.current = { x: 0, y: 0 };
        move();
    };
    const key = (event) => {
        if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey)
            return;
        if (/^[1-4]$/.test(event.key)) {
            event.preventDefault();
            event.stopPropagation();
            takeDisc(Number(event.key) - 1);
            return;
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            event.stopPropagation();
            if (target.current.discOut)
                takeDisc(pose.current.disc.index);
            else
                toggle();
            return;
        }
        const rotation = pose.current.disc.out > .95 ? pose.current.disc : base.current;
        if (event.key === 'Home') {
            event.preventDefault();
            rotation.x = 0;
            rotation.y = Math.round(rotation.y / 360) * 360;
            pose.current.zoom = 1;
        }
        else if (event.key.startsWith('Arrow')) {
            event.preventDefault();
            event.stopPropagation();
            rotation.x = clamp(rotation.x + (event.key === 'ArrowUp' ? 15 : event.key === 'ArrowDown' ? -15 : 0), -65, 65);
            rotation.y += event.key === 'ArrowRight' ? 25 : event.key === 'ArrowLeft' ? -25 : 0;
        }
        else
            return;
        clearHint();
        if (pose.current.disc.out > .95)
            discBase.current = { x: rotation.x, y: rotation.y };
        offset.current = { x: 0, y: 0 };
        motion.recalibrate();
        move();
    };
    if (fallback)
        return (0, jsx_runtime_1.jsx)(CSSAlbumModel_1.CSSAlbumModel, { record: record, permission: permission, inputEnabled: fallbackInputEnabled, onDismiss: onDismiss });
    return (0, jsx_runtime_1.jsx)("div", { className: "album-viewer", children: (0, jsx_runtime_1.jsxs)("div", { className: `album-model-scene album-webgl-scene${dragging ? ' is-dragging' : ''}`, ref: stage, role: "group", tabIndex: 0, "aria-label": `3D 专辑：${record.title}`, "aria-expanded": model.canOpen ? opened : undefined, "aria-busy": !ready, "aria-description": "\u62D6\u52A8\u6216\u65B9\u5411\u952E\u65CB\u8F6C\uFF0C\u70B9\u51FB\u5305\u88C5\u6216 Enter \u5F00\u5408\u3002\u5149\u6807\u9760\u8FD1\u888B\u53E3\u65F6 CD \u8F7B\u63A2\u51FA\uFF0C\u60AC\u505C\u6258\u76D8 CD \u65F6\u8F7B\u62AC\u3002\u70B9\u51FB CD \u53D6\u51FA\uFF0C\u62D6\u52A8\u67E5\u770B\u6B63\u53CD\u9762\uFF0C\u518D\u6B21\u70B9\u51FB\u653E\u56DE\uFF1B\u6570\u5B57\u952E 1 \u81F3 4 \u53D6\u653E\u5BF9\u5E94 CD\u3002\u6EDA\u8F6E\u653E\u5927\uFF0CHome \u56DE\u6B63\uFF0CEsc \u5173\u95ED\u3002", onKeyDown: key, onDragStart: event => event.preventDefault(), onPointerDown: down, onPointerMove: pointerMove, onPointerUp: stopDrag, onPointerCancel: () => { clearHint(); move(); tapCase.current = null; stopDrag(); trailing.current = true; }, onLostPointerCapture: () => { if (drag.current) {
                clearHint();
                move();
                tapCase.current = null;
                stopDrag();
                trailing.current = true;
            } }, onPointerLeave: () => { clearHint(); if (!drag.current && !motion.intended)
                offset.current = { x: 0, y: 0 }; move(); }, onClick: event => {
                const startedOnCase = tapCase.current;
                tapCase.current = null;
                if (trailing.current) {
                    trailing.current = false;
                    event.preventDefault();
                    event.stopPropagation();
                    return;
                }
                if (event.detail !== 0 && !startedOnCase) {
                    if (ready && !scene.current?.hits(event.clientX, event.clientY))
                        onDismiss();
                    return;
                }
                if (startedOnCase?.disc !== undefined)
                    takeDisc(startedOnCase.disc);
                else
                    toggle();
            }, children: [!ready ? (0, jsx_runtime_1.jsxs)("div", { className: "album-model-loading", role: "status", "aria-live": "polite", children: [(0, jsx_runtime_1.jsx)("span", { className: "album-model-loading-spinner", "aria-hidden": "true" }), (0, jsx_runtime_1.jsx)("span", { children: "\u6B63\u5728\u52A0\u8F7D\u4E13\u8F91\u6A21\u578B" })] }) : null, (0, jsx_runtime_1.jsx)("span", { className: "album-model-status", role: "status", children: discStatus })] }) });
}
