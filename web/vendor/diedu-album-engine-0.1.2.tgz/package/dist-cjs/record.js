"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createViewerInput = createViewerInput;
function createViewerInput(entity, resolveAsset, models) {
    if (entity.schemaVersion !== 1)
        throw new Error('Unsupported album entity schema');
    if (models.rigVersion !== 1)
        throw new Error('Unsupported album model rig');
    const textures = {}, regions = {};
    const rows = {};
    const discs = {};
    for (const [name, surface] of Object.entries(entity.surfaces)) {
        if (!surface)
            continue;
        const role = name;
        textures[role] = resolveAsset(surface.asset);
        if (surface.region)
            regions[role] = [...surface.region];
        if (surface.warpRows)
            rows[role] = surface.warpRows.map(row => [...row]);
        if (role.startsWith('disc') && surface.discCalibration)
            discs[role] = structuredClone(surface.discCalibration);
    }
    return { id: entity.key, title: entity.title, placeholderHue: entity.placeholderHue ?? 0,
        packaging: { ...entity.packaging, photoRegions: regions }, modelTextures: textures,
        ...(Object.keys(rows).length ? { modelWarpRows: rows } : {}),
        ...(Object.keys(discs).length ? { modelDiscCalibrations: discs } : {}),
        ...(entity.calibration ? { modelCalibration: structuredClone(entity.calibration) } : {}), modelAssets: { ...models } };
}
