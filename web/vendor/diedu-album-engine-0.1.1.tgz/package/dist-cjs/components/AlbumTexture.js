"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AlbumTexture = AlbumTexture;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const album_model_assets_1 = require("../core/album-model-assets");
const album_photo_projection_1 = require("../core/album-photo-projection");
const album_photo_raster_1 = require("../core/album-photo-raster");
const EntityArtwork_1 = require("./EntityArtwork");
/** The CSS fallback uses the same source, quadrilateral and paper warp as WebGL. */
function AlbumTexture({ record, role }) {
    const source = (0, album_model_assets_1.albumTextureSource)(record, role);
    const region = record.packaging?.photoRegions?.[role], rows = record.modelWarpRows?.[role];
    const projected = !!(region && (0, album_photo_projection_1.photoProjection)(region) || rows && (0, album_photo_projection_1.validPhotoWarpRows)(rows));
    const canvas = (0, react_1.useRef)(null);
    const [failed, setFailed] = (0, react_1.useState)('');
    (0, react_1.useEffect)(() => {
        if (!source || !projected || !canvas.current)
            return;
        let alive = true;
        const image = new Image();
        image.onload = () => {
            if (!alive || !canvas.current)
                return;
            try {
                const crop = (0, album_photo_projection_1.photoTextureCrop)(image.naturalWidth, image.naturalHeight, region, rows);
                const scale = Math.min(1, 2048 / Math.max(crop.width, crop.height));
                const buffer = document.createElement('canvas');
                buffer.width = Math.max(1, Math.ceil(crop.width * scale));
                buffer.height = Math.max(1, Math.ceil(crop.height * scale));
                const context = buffer.getContext('2d', { willReadFrequently: true });
                if (!context)
                    throw new Error('Photo canvas unavailable');
                context.drawImage(image, crop.x, crop.y, crop.width, crop.height, 0, 0, buffer.width, buffer.height);
                const result = (0, album_photo_raster_1.rasterPackagingPhoto)(context.getImageData(0, 0, buffer.width, buffer.height).data, buffer.width, buffer.height, crop.region, crop.warpRows);
                canvas.current.width = result.width;
                canvas.current.height = result.height;
                const target = canvas.current.getContext('2d');
                if (!target)
                    throw new Error('Photo canvas unavailable');
                target.putImageData(new ImageData(result.data, result.width, result.height), 0, 0);
            }
            catch {
                setFailed(source);
            }
        };
        image.onerror = () => { if (alive)
            setFailed(source); };
        image.src = source;
        return () => { alive = false; image.onload = null; image.onerror = null; };
    }, [source, projected, region, rows]);
    if (source && failed !== source)
        return projected
            ? (0, jsx_runtime_1.jsx)("canvas", { ref: canvas, className: "album-texture", "aria-hidden": "true", "data-texture-role": role })
            : (0, jsx_runtime_1.jsx)("img", { className: "album-texture", src: source, alt: "", draggable: false, onError: () => setFailed(source) });
    if (role === 'front' && !source)
        return (0, jsx_runtime_1.jsx)(EntityArtwork_1.EntityArtwork, { record: record });
    return (0, jsx_runtime_1.jsx)("span", { className: "album-surface-note", children: source ? '贴图载入失败' : role.startsWith('disc') ? '' : role === 'back' ? '示意背面' : role === 'spine' ? '' : '示意中面' });
}
