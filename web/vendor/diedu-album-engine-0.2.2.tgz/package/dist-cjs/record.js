"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createViewerInput = createViewerInput;
const capabilities_1 = require("./capabilities");
function createViewerInput(source, resolveAsset, models) {
    let entity;
    let assembly;
    if (source.schemaVersion === 2) {
        const capability = (0, capabilities_1.inspectAlbum)(source, models);
        if (!capability.supported)
            throw new Error('Unsupported album assembly: ' + capability.reason);
        assembly = capability.entity;
        const root = (0, capabilities_1.packageComponent)(assembly);
        entity = { schemaVersion: 1, key: assembly.key, title: assembly.title, packaging: root.configuration,
            surfaces: Object.fromEntries(Object.entries(root.surfaces).filter(([role]) => !role.startsWith('disc'))), calibration: assembly.calibration, placeholderHue: assembly.placeholderHue };
        // Canonical CD components own their print and calibration. Root role aliases
        // remain in historical envelopes only and cannot override those components.
        for (const part of assembly.assembly.components) {
            if (part.kind !== 'disc' || !part.mount)
                continue;
            const index = Number(part.mount.split(':')[1]);
            const role = (index === 0 ? 'disc' : 'disc' + (index + 1));
            if (part.surfaces.front)
                entity.surfaces[role] = part.surfaces.front;
        }
    }
    else
        entity = source;
    if (entity.schemaVersion !== 1)
        throw new Error('Unsupported album entity schema');
    if (models.rigVersion !== 1)
        throw new Error('Unsupported album model rig');
    const textures = {}, regions = {};
    const rows = {};
    const discs = {};
    for (const [name, surface] of Object.entries(entity.surfaces)) {
        if (!surface)
            continue;
        const role = name;
        textures[role] = resolveAsset(surface.asset);
        if (surface.region)
            regions[role] = [...surface.region];
        if (surface.warpRows)
            rows[role] = surface.warpRows.map(row => [...row]);
        if (role.startsWith('disc') && surface.discCalibration)
            discs[role] = structuredClone(surface.discCalibration);
    }
    const accessories = assembly ? assembly.assembly.components.filter((c) => ['obi', 'booklet', 'inner-sleeve'].includes(c.kind))
        .map(c => ({ id: c.id, kind: c.kind, source: resolveAsset(c.surfaces.front.asset),
        region: c.surfaces.front.region, warpRows: c.surfaces.front.warpRows,
        ...(c.surfaces.back ? { back: { source: resolveAsset(c.surfaces.back.asset), region: c.surfaces.back.region, warpRows: c.surfaces.back.warpRows } } : {}), mount: c.mount, dimensions: c.dimensions,
        ...(c.kind === 'booklet' && c.fold ? { fold: structuredClone(c.fold) } : {}),
        ...(c.contains?.length ? { discIndex: Number(assembly.assembly.components.find(d => d.id === c.contains[0])?.mount?.split(':')[1]) } : {}) }))
        : entity.components?.map(({ asset, back, ...part }) => ({ ...part, source: resolveAsset(asset),
            ...(back ? { back: { source: resolveAsset(back.asset), region: back.region, warpRows: back.warpRows } } : {}) }));
    return { id: entity.key, title: entity.title, placeholderHue: entity.placeholderHue ?? 0,
        packaging: { ...entity.packaging, photoRegions: regions }, modelTextures: textures,
        ...(Object.keys(rows).length ? { modelWarpRows: rows } : {}),
        ...(Object.keys(discs).length ? { modelDiscCalibrations: discs } : {}),
        ...(entity.calibration ? { modelCalibration: structuredClone(entity.calibration) } : {}),
        ...(accessories?.length ? { modelAccessories: accessories } : {}), ...(assembly ? { assembly } : {}), modelAssets: { ...models } };
}
