"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestAlbumOrientationPermission = void 0;
exports.AlbumViewer = AlbumViewer;
const jsx_runtime_1 = require("react/jsx-runtime");
const react_1 = require("react");
const record_1 = require("./record");
const AlbumModel_1 = require("./components/AlbumModel");
var useAlbumOrientation_1 = require("./components/useAlbumOrientation");
Object.defineProperty(exports, "requestAlbumOrientationPermission", { enumerable: true, get: function () { return useAlbumOrientation_1.requestAlbumOrientationPermission; } });
function AlbumViewer({ entity, resolveAsset, models, permission, onRequestClose, onUnavailable, layout }) {
    const record = (0, react_1.useMemo)(() => (0, record_1.createViewerInput)(entity, resolveAsset, models), [entity, resolveAsset, models]);
    return (0, jsx_runtime_1.jsx)("div", { className: layout === 'fill' ? 'album-engine-frame album-engine-frame--fill' : 'album-engine-frame', children: (0, jsx_runtime_1.jsx)(AlbumModel_1.AlbumModel, { record: record, permission: permission, onDismiss: onRequestClose, onUnavailable: onUnavailable }) });
}
