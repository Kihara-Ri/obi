"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.albumSceneIdentity = albumSceneIdentity;
exports.albumModelAsset = albumModelAsset;
exports.albumTextureSource = albumTextureSource;
exports.albumPanelDiscs = albumPanelDiscs;
/** Polling creates new record objects; only changed scene inputs require a new renderer. */
function albumSceneIdentity(record) {
    return JSON.stringify([record.id, record.packaging, record.modelTextures,
        record.modelWarpRows, record.modelDiscCalibrations, record.modelCalibration, record.modelAssets, record.modelAccessories, record.assembly]);
}
/** A disc count selects a carrier, never silently selects a fatbox shell. */
function albumModelAsset(model, calibrated = false, models = { baseUrl: '', rigVersion: 1 }) {
    const kind = model.kind;
    const name = kind === 'gatefold' && model.panels === 2 && model.miniLP && model.holder === 'pocket'
        && model.pocketOpening === 'outer' && calibrated ? 'gatefold-2-mini-lp'
        : kind === 'jewel' ? model.thickness === 'slim' ? 'slimline-jewel'
            : model.thickness === 'thick' ? 'jewel-fat'
                : model.discs > 2 ? 'jewel-swing-4' : model.discs > 1 ? 'jewel-swing-2' : 'jewel-case'
            : kind === 'gatefold' || kind === 'digipak' ? kind + '-' + model.panels
                + (kind === 'gatefold' && model.holder === 'pocket' && model.pocketOpening === 'inner' ? '-inner' : '')
                : kind === 'card-sleeve' && model.miniLP ? 'mini-lp-sleeve'
                    : kind === 'unknown' ? 'neutral' : kind;
    return (models.baseUrl ? models.baseUrl.replace(/\/?$/, '/') : '') + name + '.glb';
}
/** A specified but unavailable front photograph must not become a different cover. */
function albumTextureSource(record, role) {
    return record.modelTextures[role] ?? '';
}
function albumPanelDiscs(model, panel) {
    if (model.kind === 'jewel')
        return Array.from({ length: model.discs }, (_, i) => i);
    if (model.kind === 'card-sleeve' || model.kind === 'rigid-box')
        return panel === 1 ? Array.from({ length: model.discs }, (_, i) => i) : [];
    if (model.holder === 'pocket' && model.pockets !== 'both')
        return panel === (model.pockets === 'left' ? 0 : 1) ? Array.from({ length: model.discs }, (_, i) => i) : [];
    if (model.discs === 1)
        return panel === 1 ? [0] : [];
    const count = Math.min(model.panels, model.discs);
    if (panel >= count)
        return [];
    const before = Array.from({ length: panel }, (_, i) => Math.floor(model.discs / count) +
        (i >= count - model.discs % count ? 1 : 0)).reduce((a, b) => a + b, 0);
    const amount = Math.floor(model.discs / count) + (panel >= count - model.discs % count ? 1 : 0);
    return Array.from({ length: amount }, (_, i) => before + i);
}
