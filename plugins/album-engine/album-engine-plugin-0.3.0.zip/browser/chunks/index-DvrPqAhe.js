import { j as D } from "./jsx-runtime-B0GD0xBr.js";
import { r as d, a as be, u as Me, c as Pe, b as we } from "./plugin-DPTO-O3o.js";
function De(n) {
  return JSON.stringify([
    n.id,
    n.packaging,
    n.modelTextures,
    n.modelWarpRows,
    n.modelDiscCalibrations,
    n.modelCalibration,
    n.modelAssets,
    n.modelAccessories,
    n.assembly
  ]);
}
function je(n, a) {
  return n.modelTextures[a] ?? "";
}
function Re(n) {
  const a = n == null ? void 0 : n.initialCamera;
  return {
    x: (a == null ? void 0 : a.pitch) === void 0 ? -8 : a.pitch * 180 / Math.PI,
    y: (a == null ? void 0 : a.yaw) === void 0 ? -16 : a.yaw * 180 / Math.PI,
    zoom: (a == null ? void 0 : a.zoom) ?? 1,
    open: 0,
    disc: { index: -1, out: 0, x: 0, y: 0 },
    hint: { index: -1, amount: 0 }
  };
}
function Te(n, a, M) {
  return {
    x: ((n == null ? void 0 : n.initialCamera.framingX) ?? 0) * a,
    y: ((n == null ? void 0 : n.initialCamera.framingY) ?? 0) * M
  };
}
function Ce(n, a) {
  return Math.atan2(Math.sin(a - n), Math.cos(a - n)) * 180 / Math.PI;
}
function ke(n, a, M) {
  return Math.hypot((a - n.x) / Math.max(1, n.width / 2), (M - n.y) / Math.max(1, n.height / 2)) > 0.68;
}
const ze = 1.5;
function Ae(n, a, M) {
  if (M <= 0) return n;
  if (Math.abs(a - n.out) < 1e-9 && Math.abs(n.velocity) < 1e-9)
    return { out: a, velocity: 0 };
  const R = n.from === void 0 || n.to !== a || n.elapsed === void 0, f = R ? n.out : n.from, m = R ? Math.max(0.38, ze * Math.sqrt(Math.abs(a - f))) : n.duration, z = R ? n.velocity : n.velocityStart ?? 0, o = Math.min(m, (R ? 0 : n.elapsed) + M), P = o / m, u = P * P, C = u * P, A = a - f, y = z * m, O = f + (C - 2 * u + P) * y + (3 * u - 2 * C) * A, Q = ((3 * u - 4 * P + 1) * y + (6 * P - 6 * u) * A) / m;
  if (o >= m - 1e-8) return { out: a, velocity: 0 };
  const w = Math.max(0, Math.min(1, O));
  return {
    out: w,
    velocity: w === O ? Q : 0,
    from: f,
    to: a,
    elapsed: o,
    duration: m,
    velocityStart: z
  };
}
const L = (n, a, M) => Math.max(a, Math.min(M, n));
function Se({ record: n, permission: a, onDismiss: M, onUnavailable: R, lifecycle: f }) {
  return /* @__PURE__ */ D.jsx(Oe, { lifecycle: f, record: n, permission: a, onDismiss: M, onUnavailable: R }, De(n));
}
function Oe({ record: n, permission: a, onDismiss: M, onUnavailable: R, lifecycle: f }) {
  const m = d.useRef(null), [z] = d.useState(() => ({ record: n, model: be(n.packaging) })), o = d.useRef(null), [P] = d.useState(() => Re(n.presentation)), u = d.useRef(P), C = d.useRef({ x: P.x, y: P.y }), A = d.useRef({ x: -8, y: -12, z: 0 }), y = d.useRef(null), O = d.useRef({ x: 0, y: 0, z: 0 }), Q = d.useRef(0), w = d.useRef({ x: 0, y: 0 }), h = d.useRef({ x: P.x, y: P.y, open: 0, discOut: 0, hintIndex: -1 }), _ = d.useRef(null), F = d.useRef(null), H = d.useRef({ out: 0, velocity: 0 }), B = d.useRef(!1), E = d.useRef(!1), v = d.useRef(0), N = d.useRef(!1), Z = d.useRef(!document.hidden), k = d.useRef(null), K = d.useRef(null), X = d.useRef(!1), [ne, se] = d.useState(!1), [W, ae] = d.useState(!1), $ = d.useRef(R);
  $.current = R;
  const [le, de] = d.useState(!1), [I, ee] = d.useState(!1), [fe, U] = d.useState(""), [S, Y] = d.useState(null), [pe, ce] = d.useState(!1), te = z.model, b = d.useCallback((e = !1) => {
    var l;
    if (f != null && f.aborted || (h.current.x = L(C.current.x + w.current.x, -72, 72), h.current.y = C.current.y + w.current.y, (e || N.current) && (u.current.x = h.current.x, u.current.y = h.current.y), N.current && (u.current.open = h.current.open), e && ((l = o.current) == null || l.paint(u.current)), !Z.current || v.current)) return;
    let t = performance.now();
    const r = (p) => {
      var ie, oe;
      const i = L((p - t) / 1e3, 0, 0.05);
      t = p;
      const s = u.current, c = h.current, x = 1 - Math.exp(-20 * i);
      s.x += (c.x - s.x) * x, s.y += (c.y - s.y) * x, s.open += (c.open - s.open) * (N.current ? 1 : 1 - Math.exp(-12 * i));
      const g = N.current ? { out: c.discOut, velocity: 0 } : Ae(H.current, c.discOut, i);
      s.disc.out = g.out, H.current = g;
      let T = s.hint.index === c.hintIndex && c.hintIndex >= 0 ? 1 : 0;
      c.discOut && s.disc.index === s.hint.index && s.disc.out < 0.52 && (T = s.hint.amount), s.hint.amount += (T - s.hint.amount) * (1 - Math.exp(-16 * i)), Math.abs(T - s.hint.amount) < 1e-3 && (s.hint.amount = T, T || (s.hint.index = c.hintIndex)), H.current.from === void 0 && Math.abs(c.discOut - s.disc.out) < 1e-3 && (s.disc.out = c.discOut, H.current = { out: c.discOut, velocity: 0 }, c.discOut || (F.current !== null ? (s.disc = { index: F.current, out: 0, x: -8, y: -12 }, c.discOut = 1, F.current = null, H.current = { out: 0, velocity: 0 }, A.current = { x: -8, y: -12 }) : (ce(!1), B.current && (c.open = 0, B.current = !1))));
      const V = Math.abs(c.x - s.x) + Math.abs(c.y - s.y) < 0.02 && Math.abs(c.open - s.open) < 1e-3 && H.current.from === void 0 && Math.abs(c.discOut - s.disc.out) < 1e-3;
      V && (s.x = c.x, s.y = c.y, s.open = c.open), (ie = o.current) == null || ie.paint(s);
      const q = _.current;
      q && !k.current && !c.discOut && !N.current && (c.hintIndex = ((oe = o.current) == null ? void 0 : oe.hoverDisc(q.x, q.y, c.hintIndex)) ?? -1), m.current && (m.current.dataset.discHover = String(c.hintIndex >= 0));
      const ge = V && s.hint.index === c.hintIndex && Math.abs((c.hintIndex >= 0 ? 1 : 0) - s.hint.amount) < 1e-3;
      v.current = ge ? 0 : requestAnimationFrame(r);
    };
    v.current = requestAnimationFrame(r);
  }, [f]), xe = d.useCallback((e, t) => {
    var l;
    const r = y.current;
    r && ((l = o.current) != null && l.accessoryPose(r)) ? o.current.rotateAccessory(r, L(O.current.x + e, -65, 65), O.current.y + t, O.current.z ?? 0) : u.current.disc.out > 0 || h.current.discOut ? (u.current.disc.x = L(A.current.x + e, -65, 65), u.current.disc.y = A.current.y + t) : w.current = { x: e, y: t }, b();
  }, [b]), G = Me({ lifecycle: f, active: I && !ne && !W, permission: a, onTilt: xe });
  d.useEffect(() => {
    let e = !0;
    const t = m.current;
    if (!t || W || f != null && f.aborted) return;
    const r = document.createElement("canvas");
    r.className = "album-webgl-canvas", r.setAttribute("aria-hidden", "true"), t.prepend(r), ee(!1);
    let l = null;
    const p = (x) => {
      x.preventDefault(), u.current.zoom = L(u.current.zoom * Math.exp(-x.deltaY * 1e-3), 0.7, 2), b();
    }, i = () => {
      var x;
      e && (ae(!0), ee(!1), (x = $.current) == null || x.call($));
    }, s = (x) => {
      x.preventDefault(), i();
    };
    t.addEventListener("wheel", p, { passive: !1 }), r.addEventListener("webglcontextlost", s), import("./album-scene-CqoZRuOx.js").then(async ({ AlbumScene: x }) => {
      if (!e) return;
      const g = new x(t, r, z.record, z.model);
      l = g, o.current = g, await g.load(), e && (g.paint(u.current), ee(!0));
    }).catch(() => {
      l == null || l.dispose(), e && (o.current = null, i());
    });
    const c = () => {
      f == null || f.removeEventListener("abort", c), e = !1, t.removeEventListener("wheel", p), r.removeEventListener("webglcontextlost", s), l == null || l.dispose(), o.current === l && (o.current = null), r.remove();
    };
    return f == null || f.addEventListener("abort", c, { once: !0 }), c;
  }, [z, W, b, f]), d.useEffect(() => {
    if (f != null && f.aborted) return;
    const e = matchMedia("(prefers-reduced-motion: reduce)"), t = () => {
      N.current = e.matches, w.current = { x: 0, y: 0 }, _.current = null, h.current.hintIndex = -1, u.current.hint = { index: -1, amount: 0 }, b(!0);
    }, r = () => {
      Z.current = !document.hidden, Z.current ? b(!0) : (_.current = null, h.current.hintIndex = -1, u.current.hint = { index: -1, amount: 0 }, cancelAnimationFrame(v.current), v.current = 0);
    };
    t(), e.addEventListener("change", t), document.addEventListener("visibilitychange", r);
    const l = () => {
      var i;
      f == null || f.removeEventListener("abort", l);
      const p = k.current;
      p && ((i = m.current) != null && i.hasPointerCapture(p.id)) && m.current.releasePointerCapture(p.id), k.current = null, cancelAnimationFrame(v.current), v.current = 0, window.clearTimeout(Q.current), e.removeEventListener("change", t), document.removeEventListener("visibilitychange", r);
    };
    return f == null || f.addEventListener("abort", l, { once: !0 }), l;
  }, [b, f]);
  const j = () => {
    _.current = null, h.current.hintIndex = -1, m.current && (m.current.dataset.accessoryHover = "");
  }, J = () => {
    var t;
    const e = k.current;
    e != null && e.moved && (X.current = !0), k.current = null, se(!1), e && ((t = m.current) != null && t.hasPointerCapture(e.id)) && m.current.releasePointerCapture(e.id), G.recalibrate();
  }, me = (e) => {
    var x, g, T, V, q;
    K.current = null;
    const t = ((x = m.current) == null ? void 0 : x.dataset.accessoryHover) || null;
    if (j(), b(), !e.isPrimary) {
      J(), X.current = !0;
      return;
    }
    if (X.current = !1, !I || e.button !== 0 || e.clientX < 28 || k.current) return;
    const r = (g = o.current) == null ? void 0 : g.pick(e.clientX, e.clientY), l = t && !(r != null && r.accessory) && (r == null ? void 0 : r.disc) === void 0 ? { accessory: t } : r;
    if (!l) return;
    K.current = l;
    const p = l.accessory ? (T = o.current) == null ? void 0 : T.accessoryPose(l.accessory) : null;
    y.current = l.accessory ?? null;
    const i = l.disc === u.current.disc.index && u.current.disc.out > 0.95;
    p ? (O.current = p, C.current = { x: u.current.x, y: u.current.y }, w.current = { x: 0, y: 0 }, b(!0)) : i ? A.current = { x: u.current.disc.x, y: u.current.disc.y } : (C.current = { x: u.current.x, y: u.current.y }, w.current = { x: 0, y: 0 });
    const s = p ? (V = o.current) == null ? void 0 : V.inspectionFrame(l.accessory) : i ? (q = o.current) == null ? void 0 : q.inspectionFrame("disc") : null, c = s && ke(s, e.clientX, e.clientY);
    k.current = {
      id: e.pointerId,
      x: e.clientX,
      y: e.clientY,
      rx: (p == null ? void 0 : p.x) ?? (i ? u.current.disc.x : C.current.x),
      ry: (p == null ? void 0 : p.y) ?? (i ? u.current.disc.y : C.current.y),
      rz: (p == null ? void 0 : p.z) ?? (i ? u.current.disc.z ?? 0 : 0),
      ...s && (c || e.shiftKey) ? { roll: {
        x: s.x,
        y: s.y,
        angle: Math.atan2(s.y - e.clientY, e.clientX - s.x),
        linear: e.shiftKey
      } } : {},
      width: e.currentTarget.clientWidth,
      moved: !1,
      disc: i,
      accessory: p ? l.accessory : void 0
    }, m.current && (m.current.dataset.rotationTarget = p ? l.accessory : i ? "disc" : "album", m.current.dataset.rotationMode = k.current.roll ? "roll" : "orbit"), se(!0), e.currentTarget.focus({ preventScroll: !0 }), e.currentTarget.setPointerCapture(e.pointerId);
  }, ye = (e) => {
    var l, p;
    const t = k.current;
    if ((t == null ? void 0 : t.id) === e.pointerId) {
      Math.hypot(e.clientX - t.x, e.clientY - t.y) > 6 && (t.moved = !0);
      const i = {
        x: L(t.rx - (e.clientY - t.y) / t.width * 150, -65, 65),
        y: t.ry + (e.clientX - t.x) / t.width * (t.disc || t.accessory ? 360 : 220),
        z: t.rz
      };
      if (t.roll)
        if (i.x = t.rx, i.y = t.ry, t.roll.linear) i.z = t.rz + (e.clientX - t.x) / t.width * 360;
        else {
          const s = Math.atan2(t.roll.y - e.clientY, e.clientX - t.roll.x);
          t.rz += Ce(t.roll.angle, s), t.roll.angle = s, i.z = t.rz;
        }
      t.accessory ? ((l = o.current) == null || l.rotateAccessory(t.accessory, i.x, i.y, i.z), O.current = i) : t.disc ? (u.current.disc.x = i.x, u.current.disc.y = i.y, u.current.disc.z = i.z, A.current = i) : C.current = i, b(!0);
      return;
    }
    if (!I || e.pointerType !== "mouse" || e.buttons || N.current || pe) {
      j(), b();
      return;
    }
    _.current = { x: e.clientX, y: e.clientY };
    const r = (p = o.current) == null ? void 0 : p.pick(e.clientX, e.clientY, 34, h.current.hintIndex);
    if (h.current.hintIndex = (r == null ? void 0 : r.disc) ?? -1, m.current && (m.current.dataset.accessoryHover = (r == null ? void 0 : r.accessory) ?? "", m.current.dataset.discHover = String((r == null ? void 0 : r.disc) !== void 0)), r != null && r.accessory)
      w.current = { x: 0, y: 0 };
    else if (!G.intended) {
      const i = e.currentTarget.getBoundingClientRect();
      w.current = {
        x: (0.5 - L((e.clientY - i.top) / i.height, 0, 1)) * 24,
        y: (L((e.clientX - i.left) / i.width, 0, 1) - 0.5) * 32
      };
    }
    b();
  }, ue = () => {
    var e, t;
    !I || !te.canOpen || (j(), E.current = !E.current, E.current ? (e = o.current) == null || e.releaseWrapBeforeOpen() : (t = o.current) == null || t.prepareForClose(), B.current = !E.current && u.current.disc.out > 0, F.current = null, E.current || (h.current.discOut = 0, U("")), h.current.open = B.current ? 1 : Number(E.current), de(E.current), b());
  }, re = (e) => {
    var r;
    if (!I || te.canOpen && (!E.current || u.current.open < 0.9) || !((r = o.current) != null && r.discIndices.includes(e)) || !o.current.canTakeDisc(e)) return;
    j(), y.current = null, B.current = !1;
    const t = u.current.disc;
    ce(!0), t.index === e && h.current.discOut ? (h.current.discOut = 0, F.current = null, U("CD " + (e + 1) + " 放回原位")) : t.out > 0 && t.index !== e ? (h.current.discOut = 0, F.current = e, U("CD " + (e + 1) + " 取出查看")) : ((t.index !== e || !t.out) && (u.current.disc = { index: e, out: 0, x: -8, y: -12 }, A.current = { x: -8, y: -12 }), h.current.discOut = 1, F.current = null, U("CD " + (e + 1) + " 取出查看")), w.current = { x: 0, y: 0 }, b();
  }, he = (e) => {
    var l, p, i, s, c;
    if (e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
    if (/^[1-4]$/.test(e.key)) {
      e.preventDefault(), e.stopPropagation(), re(Number(e.key) - 1);
      return;
    }
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault(), e.stopPropagation(), y.current && ((l = o.current) != null && l.accessoryPose(y.current)) ? (o.current.toggleAccessory(y.current), Y(null)) : h.current.discOut ? re(u.current.disc.index) : ue();
      return;
    }
    if (e.key.toLowerCase() === "f" && y.current && ((p = o.current) == null ? void 0 : p.paperFoldState(y.current)) !== null) {
      e.preventDefault(), e.stopPropagation(), (i = o.current) == null || i.togglePaperFold(y.current), Y((x) => (x == null ? void 0 : x.id) === y.current ? { ...x, expanded: !x.expanded } : x);
      return;
    }
    const t = y.current ? (s = o.current) == null ? void 0 : s.accessoryPose(y.current) : null, r = t ?? (u.current.disc.out > 0.95 ? u.current.disc : C.current);
    if (e.key === "Home")
      e.preventDefault(), r.x = 0, r.y = Math.round(r.y / 360) * 360, r.z = 0, u.current.zoom = 1;
    else if ((e.key.toLowerCase() === "q" || e.key.toLowerCase() === "e") && (t || u.current.disc.out > 0.95))
      e.preventDefault(), e.stopPropagation(), r.z = (r.z ?? 0) + (e.key.toLowerCase() === "e" ? 90 : -90);
    else if (e.key.startsWith("Arrow"))
      e.preventDefault(), e.stopPropagation(), r.x = L(r.x + (e.key === "ArrowUp" ? 15 : e.key === "ArrowDown" ? -15 : 0), -65, 65), r.y += e.key === "ArrowRight" ? 25 : e.key === "ArrowLeft" ? -25 : 0;
    else return;
    j(), t && y.current ? ((c = o.current) == null || c.rotateAccessory(y.current, r.x, r.y, r.z ?? 0), O.current = r) : u.current.disc.out > 0.95 && (u.current.disc.z = r.z ?? 0, A.current = { ...r }), w.current = { x: 0, y: 0 }, G.recalibrate(), b(!0);
  };
  return W ? /* @__PURE__ */ D.jsx("div", { className: "album-model-unavailable", role: "status", children: "当前设备无法显示 3D 模型" }) : /* @__PURE__ */ D.jsxs("div", { className: "album-viewer", children: [
    /* @__PURE__ */ D.jsxs(
      "div",
      {
        className: `album-model-scene album-webgl-scene${ne ? " is-dragging" : ""}`,
        ref: m,
        role: "group",
        tabIndex: 0,
        "aria-label": `3D 专辑：${n.title}`,
        "aria-expanded": te.canOpen ? le : void 0,
        "aria-busy": !I,
        "aria-description": "拖动或方向键旋转。取出的侧标、歌词册、内袋和 CD 可各自独立旋转；拖动边缘或按住 Shift 拖动可转正文字，Q/E 每次旋转90度，Home 回正。折页取出后单击纸面或按 F 展开/折起，使用可见的收回按钮放回折页。点击包装开合，点击其他内容物取出或放回。先展开包装才能取出内部纸件；内袋抽出后才能取出其中 CD。数字键取放对应 CD；滚轮放大，Home 回正，Esc 关闭。",
        onKeyDown: he,
        onDragStart: (e) => e.preventDefault(),
        onPointerDown: me,
        onPointerMove: ye,
        onPointerUp: J,
        onPointerCancel: () => {
          j(), b(), K.current = null, J(), X.current = !0;
        },
        onLostPointerCapture: () => {
          k.current && (j(), b(), K.current = null, J(), X.current = !0);
        },
        onPointerLeave: () => {
          j(), !k.current && !G.intended && (w.current = { x: 0, y: 0 }), b();
        },
        onClick: (e) => {
          var r, l, p, i, s;
          const t = K.current;
          if (K.current = null, X.current) {
            X.current = !1, e.preventDefault(), e.stopPropagation();
            return;
          }
          if (e.detail !== 0 && !t) {
            I && !((r = o.current) != null && r.hits(e.clientX, e.clientY)) && M();
            return;
          }
          if (t != null && t.accessory) {
            const c = t.accessory, x = (l = z.record.modelAccessories) == null ? void 0 : l.find((g) => g.id === c && g.kind === "booklet" && g.fold);
            x != null && x.fold ? (p = o.current) != null && p.accessoryPose(c) ? (o.current.togglePaperFold(c), Y((g) => ({ id: c, panels: x.fold.panels, expanded: (g == null ? void 0 : g.id) === c ? !g.expanded : !0 }))) : ((i = o.current) == null || i.toggleAccessory(c), Y({ id: c, panels: x.fold.panels, expanded: !1 })) : ((s = o.current) == null || s.toggleAccessory(c), Y(null));
          } else (t == null ? void 0 : t.disc) !== void 0 ? re(t.disc) : ue();
        },
        children: [
          I ? null : /* @__PURE__ */ D.jsxs("div", { className: "album-model-loading", role: "status", "aria-live": "polite", children: [
            /* @__PURE__ */ D.jsx("span", { className: "album-model-loading-spinner", "aria-hidden": "true" }),
            /* @__PURE__ */ D.jsx("span", { children: "正在加载专辑模型" })
          ] }),
          /* @__PURE__ */ D.jsx("span", { className: "album-model-status", role: "status", children: fe })
        ]
      }
    ),
    S && I ? /* @__PURE__ */ D.jsxs("div", { className: "album-paper-tools", role: "group", "aria-label": `${S.panels} 联折页查看`, children: [
      /* @__PURE__ */ D.jsxs("span", { className: "album-paper-tools-label", children: [
        S.panels,
        " 联折页 · 点击纸面",
        S.expanded ? "折起" : "展开"
      ] }),
      /* @__PURE__ */ D.jsx(
        "button",
        {
          type: "button",
          "aria-label": S.expanded ? "折起纸张" : "展开纸张",
          onClick: () => {
            var e;
            y.current = S.id, (e = o.current) == null || e.togglePaperFold(S.id), Y((t) => (t == null ? void 0 : t.id) === S.id ? { ...t, expanded: !t.expanded } : t);
          },
          children: S.expanded ? "折起" : "展开"
        }
      ),
      /* @__PURE__ */ D.jsx("button", { type: "button", "aria-label": "收回纸张", onClick: () => {
        var e;
        (e = o.current) == null || e.toggleAccessory(S.id), y.current = null, Y(null);
      }, children: "收回" })
    ] }) : null
  ] });
}
function Ie({ entity: n, resolveAsset: a, models: M, permission: R, onRequestClose: f, onUnavailable: m, layout: z, lifecycle: o }) {
  const P = d.useMemo(() => Pe(n, a, M), [n, a, M]);
  return /* @__PURE__ */ D.jsx("div", { className: z === "fill" ? "album-engine-frame album-engine-frame--fill" : "album-engine-frame", children: /* @__PURE__ */ D.jsx(Se, { lifecycle: o, record: P, permission: R, onDismiss: f, onUnavailable: m }) });
}
const Fe = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  AlbumViewer: Ie,
  requestAlbumOrientationPermission: we
}, Symbol.toStringTag, { value: "Module" }));
export {
  je as a,
  Te as b,
  Fe as i
};
