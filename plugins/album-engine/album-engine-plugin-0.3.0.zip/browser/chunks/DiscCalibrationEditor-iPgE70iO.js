import { j as n } from "./jsx-runtime-B0GD0xBr.js";
import { r as u, l as U, v as C, m as V } from "./plugin-DPTO-O3o.js";
const M = (x, k, N) => Math.max(k, Math.min(N, x)), X = (x) => ({ ...x });
function O({ surfaces: x, resolveAsset: k, onSave: N, onClose: v }) {
  const I = ["disc", "disc2", "disc3", "disc4"].filter((t) => {
    var e;
    return (e = x[t]) == null ? void 0 : e.asset;
  }), [P, A] = u.useState(I[0] ?? "disc"), [y, S] = u.useState(null), [p, B] = u.useState({ width: 1, height: 1 }), [r, g] = u.useState(null), [E, H] = u.useState(null), [R, m] = u.useState(""), [b, T] = u.useState(!1), j = u.useRef(null), d = u.useRef(null), o = x[P], w = o ? k(o.asset) : "", W = (t, e) => ({
    cx: 0.5,
    cy: 0.5,
    rx: Math.min(0.46, 0.46 * e / t),
    ry: Math.min(0.46, 0.46 * t / e),
    angle: 0
  });
  u.useEffect(() => {
    let t = !0;
    S(null), m("");
    const e = new Image();
    return e.onload = () => {
      if (!t) return;
      const s = Math.min(1, 1100 / Math.max(e.naturalWidth, e.naturalHeight)), a = document.createElement("canvas");
      a.width = Math.max(1, Math.round(e.naturalWidth * s)), a.height = Math.max(1, Math.round(e.naturalHeight * s));
      const c = a.getContext("2d", { willReadFrequently: !0 });
      if (!c) {
        m("无法读取图像");
        return;
      }
      c.drawImage(e, 0, 0, a.width, a.height);
      const i = c.getImageData(0, 0, a.width, a.height), l = U(i.data, i.width, i.height);
      S(i), B({ width: i.width, height: i.height }), H(l), g(o != null && o.discCalibration ? structuredClone(o.discCalibration) : l ? structuredClone(l) : { outer: W(i.width, i.height), source: "manual" });
    }, e.onerror = () => {
      t && m("无法加载原始盘面图片");
    }, e.src = w, () => {
      t = !1, e.onload = null, e.onerror = null;
    };
  }, [w, o == null ? void 0 : o.discCalibration]), u.useEffect(() => {
    if (!y || !r || !j.current || !C(r)) return;
    let t = !1;
    const e = window.setTimeout(() => {
      var c;
      const s = V(y.data, y.width, y.height, r, 440);
      if (t || !s || !j.current) return;
      const a = j.current;
      a.width = s.width, a.height = s.height, (c = a.getContext("2d")) == null || c.putImageData(new ImageData(s.data, s.width, s.height), 0, 0);
    }, 75);
    return () => {
      t = !0, window.clearTimeout(e);
    };
  }, [y, r]);
  const q = (t, e, s) => {
    if (!r) return;
    const a = t === "outer" ? r.outer : r.inner;
    if (!a) return;
    const c = { ...a, [e]: e === "angle" ? M(s, -Math.PI, Math.PI) : M(s, e === "cx" || e === "cy" ? 0 : 0.025, 1) };
    g({ ...r, [t]: c, source: "manual", confidence: void 0 });
  }, F = (t) => {
    const e = t.currentTarget.getBoundingClientRect();
    return { x: M((t.clientX - e.left) / e.width, 0, 1), y: M((t.clientY - e.top) / e.height, 0, 1) };
  }, G = (t) => {
    if (!d.current || !r) return;
    const { x: e, y: s } = F(t), a = d.current.startsWith("inner"), c = a ? r.inner : r.outer;
    if (c)
      if (d.current === "center" || d.current === "inner-center")
        g((i) => i && { ...i, [a ? "inner" : "outer"]: { ...a ? i.inner : i.outer, cx: e, cy: s }, source: "manual", confidence: void 0 });
      else {
        const i = e - c.cx, l = s - c.cy, h = Math.cos(c.angle), f = Math.sin(c.angle), L = d.current.endsWith("x") ? Math.abs(i * h + l * f) : Math.abs(-i * f + l * h);
        q(a ? "inner" : "outer", d.current.endsWith("x") ? "rx" : "ry", L);
      }
  }, z = (t, e, s) => {
    const a = Math.cos(t.angle), c = Math.sin(t.angle), i = [
      { k: s === "outer" ? "center" : "inner-center", x: t.cx, y: t.cy },
      { k: s === "outer" ? "outer-x" : "inner-x", x: t.cx + t.rx * a, y: t.cy + t.rx * c },
      { k: s === "outer" ? "outer-y" : "inner-y", x: t.cx - t.ry * c, y: t.cy + t.ry * a }
    ];
    return /* @__PURE__ */ n.jsxs("g", { children: [
      /* @__PURE__ */ n.jsx(
        "ellipse",
        {
          cx: t.cx * 1e3,
          cy: t.cy * 1e3,
          rx: t.rx * 1e3,
          ry: t.ry * 1e3,
          transform: "rotate(" + t.angle * 180 / Math.PI + " " + t.cx * 1e3 + " " + t.cy * 1e3 + ")",
          fill: "none",
          stroke: e,
          strokeWidth: "3",
          vectorEffect: "non-scaling-stroke"
        }
      ),
      i.map((l) => /* @__PURE__ */ n.jsx(
        "circle",
        {
          cx: l.x * 1e3,
          cy: l.y * 1e3,
          r: "11",
          fill: e,
          stroke: "#151515",
          strokeWidth: "2",
          onPointerDown: (h) => {
            var f;
            h.preventDefault(), h.stopPropagation(), d.current = l.k, (f = h.currentTarget.ownerSVGElement) == null || f.setPointerCapture(h.pointerId);
          }
        },
        l.k
      ))
    ] });
  }, D = async (t = !1) => {
    if (!(!r && !t)) {
      if (!t && !C(r)) {
        m("椭圆超出原图或中心环尺寸不正确");
        return;
      }
      T(!0), m("");
      try {
        await N(P, t ? null : { ...r, source: "manual" }), v();
      } catch (e) {
        m(e instanceof Error ? e.message : "保存失败");
      } finally {
        T(!1);
      }
    }
  }, K = (t) => {
    A(t), d.current = null;
  };
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      className: "disc-calibration-overlay",
      role: "dialog",
      "aria-modal": "true",
      "aria-label": "盘面贴图校准",
      onClick: (t) => t.stopPropagation(),
      onKeyDown: (t) => {
        t.stopPropagation(), t.key === "Escape" && (t.preventDefault(), v());
      },
      children: /* @__PURE__ */ n.jsxs("div", { className: "disc-calibration-panel", children: [
        /* @__PURE__ */ n.jsxs("div", { className: "disc-calibration-heading", children: [
          /* @__PURE__ */ n.jsx("strong", { children: "盘面校准" }),
          /* @__PURE__ */ n.jsxs("div", { className: "disc-calibration-heading-actions", children: [
            r ? /* @__PURE__ */ n.jsx("button", { type: "button", disabled: b || !C(r), onClick: () => void D(), children: b ? "保存中…" : "保存" }) : null,
            /* @__PURE__ */ n.jsx("button", { type: "button", className: "quiet", onClick: v, children: "关闭" })
          ] })
        ] }),
        /* @__PURE__ */ n.jsx("p", { className: "small-note", children: "按住圆心或外圈控制点拖动。原图不变，校准结果仅用于数字实体显示。" }),
        I.length > 1 ? /* @__PURE__ */ n.jsx("div", { className: "disc-calibration-roles", children: I.map((t, e) => /* @__PURE__ */ n.jsxs(
          "button",
          {
            type: "button",
            className: t === P ? "selected" : "",
            onClick: () => K(t),
            children: [
              "CD ",
              e + 1
            ]
          },
          t
        )) }) : null,
        /* @__PURE__ */ n.jsxs("div", { className: "disc-calibration-workspace", children: [
          /* @__PURE__ */ n.jsxs("div", { className: "disc-calibration-source", style: { aspectRatio: p.width + "/" + p.height }, children: [
            w ? /* @__PURE__ */ n.jsx("img", { src: w, alt: "盘面原始来源" }) : null,
            r ? /* @__PURE__ */ n.jsxs(
              "svg",
              {
                viewBox: "0 0 1000 1000",
                preserveAspectRatio: "none",
                onPointerMove: G,
                onPointerUp: (t) => {
                  d.current = null, t.currentTarget.hasPointerCapture(t.pointerId) && t.currentTarget.releasePointerCapture(t.pointerId);
                },
                onPointerCancel: () => {
                  d.current = null;
                },
                "aria-label": "拖动调整盘面椭圆",
                children: [
                  z(r.outer, "#8ae8ff", "outer"),
                  r.inner ? z(r.inner, "#ffcc80", "inner") : null
                ]
              }
            ) : null
          ] }),
          /* @__PURE__ */ n.jsxs("div", { className: "disc-calibration-result", children: [
            /* @__PURE__ */ n.jsx("canvas", { ref: j, "aria-label": "圆形盘面校正预览" }),
            /* @__PURE__ */ n.jsx("span", { children: "实时正视预览" })
          ] })
        ] }),
        r ? /* @__PURE__ */ n.jsxs("div", { className: "disc-calibration-settings", children: [
          /* @__PURE__ */ n.jsxs("label", { children: [
            "旋转角度 ",
            /* @__PURE__ */ n.jsx(
              "input",
              {
                type: "range",
                min: "-180",
                max: "180",
                value: Math.round(r.outer.angle * 180 / Math.PI),
                onChange: (t) => q("outer", "angle", Number(t.target.value) * Math.PI / 180)
              }
            )
          ] }),
          /* @__PURE__ */ n.jsxs("label", { children: [
            /* @__PURE__ */ n.jsx("input", { type: "checkbox", checked: !!r.inner, onChange: (t) => g((e) => e && {
              ...e,
              inner: t.target.checked ? {
                ...X(e.outer),
                rx: e.outer.rx * 0.22,
                ry: e.outer.ry * 0.22
              } : void 0,
              source: "manual"
            }) }),
            "校准中心环（可选）"
          ] }),
          /* @__PURE__ */ n.jsxs("div", { className: "disc-calibration-actions", children: [
            /* @__PURE__ */ n.jsx(
              "button",
              {
                type: "button",
                className: "quiet",
                disabled: !E,
                onClick: () => E && g(structuredClone(E)),
                children: "自动拟合外圆"
              }
            ),
            /* @__PURE__ */ n.jsx("button", { type: "button", className: "quiet", onClick: () => g({
              outer: W(p.width, p.height),
              source: "manual"
            }), children: "重置控制点" }),
            o != null && o.discCalibration ? /* @__PURE__ */ n.jsx("button", { type: "button", className: "quiet", disabled: b, onClick: () => void D(!0), children: "撤销已保存校准" }) : null,
            /* @__PURE__ */ n.jsx("button", { type: "button", disabled: b || !C(r), onClick: () => void D(), children: b ? "保存中…" : "保存盘面校准" })
          ] })
        ] }) : /* @__PURE__ */ n.jsx("p", { className: "small-note", children: "正在加载原始盘面图…" }),
        R ? /* @__PURE__ */ n.jsx("p", { className: "disc-calibration-error", role: "alert", children: R }) : null
      ] })
    }
  );
}
export {
  O as DiscCalibrationEditor
};
