function _e(e, n) {
  for (var i = 0; i < n.length; i++) {
    const s = n[i];
    if (typeof s != "string" && !Array.isArray(s)) {
      for (const r in s)
        if (r !== "default" && !(r in e)) {
          const a = Object.getOwnPropertyDescriptor(s, r);
          a && Object.defineProperty(e, r, a.get ? a : {
            enumerable: !0,
            get: () => s[r]
          });
        }
    }
  }
  return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }));
}
function ve(e, n, i) {
  let s = !1;
  return () => {
    s || (s = !0, n.abort(), queueMicrotask(() => {
      try {
        e.unmount();
      } finally {
        i();
      }
    }));
  };
}
const we = "0.3.0", ze = "album-rig-1", Pe = 1, xe = 2, Me = {
  version: we,
  modelSet: ze,
  rigVersion: Pe,
  schemaVersion: xe
}, ue = {
  modelSet: "album-rig-1",
  models: {
    "jewel-case": {
      nominal_mm: [
        142,
        125,
        10.4
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            24.14,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Lid_Hinge_Y",
          panel: 0,
          size_mm: [
            119,
            119,
            0.8
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "$root",
          panel: 0,
          size_mm: [
            138,
            122,
            8.4
          ]
        }
      }
    },
    "jewel-swing-2": {
      nominal_mm: [
        142,
        125,
        10.4
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            24.14,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Lid_Hinge_Y",
          panel: 0,
          size_mm: [
            119,
            119,
            0.8
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "$root",
          panel: 0,
          size_mm: [
            138,
            122,
            8.4
          ]
        }
      }
    },
    "jewel-swing-4": {
      nominal_mm: [
        142,
        125,
        10.4
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            24.14,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Lid_Hinge_Y",
          panel: 0,
          size_mm: [
            119,
            119,
            0.8
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "$root",
          panel: 0,
          size_mm: [
            138,
            122,
            8.4
          ]
        }
      }
    },
    "jewel-fat": {
      nominal_mm: [
        142,
        125,
        22
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            24.14,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Lid_Hinge_Y",
          panel: 0,
          size_mm: [
            119,
            119,
            0.8
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "$root",
          panel: 0,
          size_mm: [
            138,
            122,
            20
          ]
        }
      }
    },
    "slimline-jewel": {
      nominal_mm: [
        142,
        125,
        5.2
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            24.14,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Lid_Hinge_Y",
          panel: 0,
          size_mm: [
            119,
            119,
            0.8
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "$root",
          panel: 0,
          size_mm: [
            138,
            122,
            3.2
          ]
        }
      }
    },
    "card-sleeve": {
      nominal_mm: [
        130,
        130,
        3.5
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            22.1,
            128.5,
            0.15
          ]
        },
        "pocket:1": {
          kind: "pocket",
          node: "$root",
          panel: 1,
          size_mm: [
            126,
            126,
            2.5
          ],
          opening: 1
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "$root",
          panel: 0,
          size_mm: [
            119,
            119,
            0.8
          ],
          opening: 1
        }
      }
    },
    "mini-lp-sleeve": {
      nominal_mm: [
        135,
        135,
        3.5
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            22.95,
            133.5,
            0.15
          ]
        },
        "pocket:1": {
          kind: "pocket",
          node: "$root",
          panel: 1,
          size_mm: [
            131,
            131,
            2.5
          ],
          opening: 1
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "$root",
          panel: 0,
          size_mm: [
            119,
            119,
            0.8
          ],
          opening: 1
        }
      }
    },
    digibook: {
      nominal_mm: [
        140,
        140,
        16
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            23.8,
            138.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            138,
            138,
            7.6
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            138,
            138,
            7.6
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            138,
            138,
            7.6
          ],
          opening: 1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            138,
            138,
            7.6
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        }
      }
    },
    "rigid-box": {
      nominal_mm: [
        145,
        145,
        24
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            24.65,
            143.5,
            0.15
          ]
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            141,
            141,
            23
          ],
          opening: 1
        }
      }
    },
    "gatefold-2": {
      nominal_mm: [
        135,
        135,
        5
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            22.95,
            133.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            133,
            133,
            2.1
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            133,
            133,
            2.1
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            133,
            133,
            2.1
          ],
          opening: 1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            133,
            133,
            2.1
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        }
      }
    },
    "gatefold-3": {
      nominal_mm: [
        135,
        135,
        10
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            22.95,
            133.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            133,
            133,
            2.9333333333333336
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            133,
            133,
            2.9333333333333336
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            133,
            133,
            2.9333333333333336
          ],
          opening: 1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            133,
            133,
            2.9333333333333336
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:2": {
          kind: "pocket",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            133,
            133,
            2.9333333333333336
          ],
          opening: 1
        },
        "tray:2": {
          kind: "tray",
          node: "Tray_2",
          panel: 2,
          size_mm: [
            133,
            133,
            2.9333333333333336
          ]
        },
        "sleeve:panel:2": {
          kind: "inner-sleeve",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        }
      }
    },
    "gatefold-4": {
      nominal_mm: [
        135,
        135,
        15
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            22.95,
            133.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            133,
            133,
            3.35
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            133,
            133,
            3.35
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            133,
            133,
            3.35
          ],
          opening: 1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            133,
            133,
            3.35
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:2": {
          kind: "pocket",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            133,
            133,
            3.35
          ],
          opening: 1
        },
        "tray:2": {
          kind: "tray",
          node: "Tray_2",
          panel: 2,
          size_mm: [
            133,
            133,
            3.35
          ]
        },
        "sleeve:panel:2": {
          kind: "inner-sleeve",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:3": {
          kind: "pocket",
          node: "Pocket_3",
          panel: 3,
          size_mm: [
            133,
            133,
            3.35
          ],
          opening: 1
        },
        "tray:3": {
          kind: "tray",
          node: "Tray_3",
          panel: 3,
          size_mm: [
            133,
            133,
            3.35
          ]
        },
        "sleeve:panel:3": {
          kind: "inner-sleeve",
          node: "Pocket_3",
          panel: 3,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        }
      }
    },
    "digipak-2": {
      nominal_mm: [
        139,
        125,
        9
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            23.63,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            137,
            123,
            4.1
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            137,
            123,
            4.1
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            137,
            123,
            4.1
          ],
          opening: 1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            137,
            123,
            4.1
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        }
      }
    },
    "digipak-3": {
      nominal_mm: [
        139,
        125,
        18
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            23.63,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            137,
            123,
            5.6
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            137,
            123,
            5.6
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            137,
            123,
            5.6
          ],
          opening: 1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            137,
            123,
            5.6
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:2": {
          kind: "pocket",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            137,
            123,
            5.6
          ],
          opening: 1
        },
        "tray:2": {
          kind: "tray",
          node: "Tray_2",
          panel: 2,
          size_mm: [
            137,
            123,
            5.6
          ]
        },
        "sleeve:panel:2": {
          kind: "inner-sleeve",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        }
      }
    },
    "digipak-4": {
      nominal_mm: [
        139,
        125,
        27
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            23.63,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            137,
            123,
            6.35
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            137,
            123,
            6.35
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            137,
            123,
            6.35
          ],
          opening: 1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            137,
            123,
            6.35
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:2": {
          kind: "pocket",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            137,
            123,
            6.35
          ],
          opening: 1
        },
        "tray:2": {
          kind: "tray",
          node: "Tray_2",
          panel: 2,
          size_mm: [
            137,
            123,
            6.35
          ]
        },
        "sleeve:panel:2": {
          kind: "inner-sleeve",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:3": {
          kind: "pocket",
          node: "Pocket_3",
          panel: 3,
          size_mm: [
            137,
            123,
            6.35
          ],
          opening: 1
        },
        "tray:3": {
          kind: "tray",
          node: "Tray_3",
          panel: 3,
          size_mm: [
            137,
            123,
            6.35
          ]
        },
        "sleeve:panel:3": {
          kind: "inner-sleeve",
          node: "Pocket_3",
          panel: 3,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        }
      }
    },
    "gatefold-2-inner": {
      nominal_mm: [
        138,
        125,
        5
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            23.46,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            136,
            123,
            2.1
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            136,
            123,
            2.1
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            136,
            123,
            2.1
          ],
          opening: -1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            136,
            123,
            2.1
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: -1
        }
      }
    },
    "gatefold-3-inner": {
      nominal_mm: [
        138,
        125,
        10
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            23.46,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            136,
            123,
            2.9333333333333336
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            136,
            123,
            2.9333333333333336
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            136,
            123,
            2.9333333333333336
          ],
          opening: -1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            136,
            123,
            2.9333333333333336
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: -1
        },
        "pocket:2": {
          kind: "pocket",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            136,
            123,
            2.9333333333333336
          ],
          opening: 1
        },
        "tray:2": {
          kind: "tray",
          node: "Tray_2",
          panel: 2,
          size_mm: [
            136,
            123,
            2.9333333333333336
          ]
        },
        "sleeve:panel:2": {
          kind: "inner-sleeve",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        }
      }
    },
    "gatefold-4-inner": {
      nominal_mm: [
        138,
        125,
        15
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            23.46,
            123.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            136,
            123,
            3.35
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            136,
            123,
            3.35
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            136,
            123,
            3.35
          ],
          opening: -1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            136,
            123,
            3.35
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: -1
        },
        "pocket:2": {
          kind: "pocket",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            136,
            123,
            3.35
          ],
          opening: 1
        },
        "tray:2": {
          kind: "tray",
          node: "Tray_2",
          panel: 2,
          size_mm: [
            136,
            123,
            3.35
          ]
        },
        "sleeve:panel:2": {
          kind: "inner-sleeve",
          node: "Pocket_2",
          panel: 2,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:3": {
          kind: "pocket",
          node: "Pocket_3",
          panel: 3,
          size_mm: [
            136,
            123,
            3.35
          ],
          opening: 1
        },
        "tray:3": {
          kind: "tray",
          node: "Tray_3",
          panel: 3,
          size_mm: [
            136,
            123,
            3.35
          ]
        },
        "sleeve:panel:3": {
          kind: "inner-sleeve",
          node: "Pocket_3",
          panel: 3,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        }
      }
    },
    "gatefold-2-mini-lp": {
      nominal_mm: [
        135,
        135,
        5
      ],
      sockets: {
        "obi:spine": {
          kind: "obi",
          node: "$root",
          size_mm: [
            22.95,
            133.5,
            0.15
          ]
        },
        "booklet:panel:0": {
          kind: "booklet",
          node: "Panel_Left",
          panel: 0,
          size_mm: [
            116,
            118,
            0.8
          ],
          opening: 1
        },
        "pocket:0": {
          kind: "pocket",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            133,
            133,
            2.1
          ],
          opening: 1
        },
        "tray:0": {
          kind: "tray",
          node: "Tray_0",
          panel: 0,
          size_mm: [
            133,
            133,
            2.1
          ]
        },
        "sleeve:panel:0": {
          kind: "inner-sleeve",
          node: "Pocket_0",
          panel: 0,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        },
        "pocket:1": {
          kind: "pocket",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            133,
            133,
            2.1
          ],
          opening: 1
        },
        "tray:1": {
          kind: "tray",
          node: "Tray_1",
          panel: 1,
          size_mm: [
            133,
            133,
            2.1
          ]
        },
        "sleeve:panel:1": {
          kind: "inner-sleeve",
          node: "Pocket_1",
          panel: 1,
          size_mm: [
            122,
            122,
            1.9
          ],
          opening: 1
        }
      }
    }
  }
};
function me(e, n = !1, i = { baseUrl: "", rigVersion: 1 }) {
  const s = e.kind, r = s === "gatefold" && e.panels === 2 && e.miniLP && e.holder === "pocket" && e.pocketOpening === "outer" && n ? "gatefold-2-mini-lp" : s === "jewel" ? e.thickness === "slim" ? "slimline-jewel" : e.thickness === "thick" ? "jewel-fat" : e.discs > 2 ? "jewel-swing-4" : e.discs > 1 ? "jewel-swing-2" : "jewel-case" : s === "gatefold" || s === "digipak" ? s + "-" + e.panels + (s === "gatefold" && e.holder === "pocket" && e.pocketOpening === "inner" ? "-inner" : "") : s === "card-sleeve" && e.miniLP ? "mini-lp-sleeve" : s === "unknown" ? "neutral" : s;
  return (i.baseUrl ? i.baseUrl.replace(/\/?$/, "/") : "") + r + ".glb";
}
function B(e, n) {
  if (e.kind === "jewel") return Array.from({ length: e.discs }, (a, m) => m);
  if (e.kind === "card-sleeve" || e.kind === "rigid-box")
    return n === 1 ? Array.from({ length: e.discs }, (a, m) => m) : [];
  if (e.holder === "pocket" && e.pockets !== "both")
    return n === (e.pockets === "left" ? 0 : 1) ? Array.from({ length: e.discs }, (a, m) => m) : [];
  if (e.discs === 1) return n === 1 ? [0] : [];
  const i = Math.min(e.panels, e.discs);
  if (n >= i) return [];
  const s = Array.from({ length: n }, (a, m) => Math.floor(e.discs / i) + (m >= i - e.discs % i ? 1 : 0)).reduce((a, m) => a + m, 0), r = Math.floor(e.discs / i) + (n >= i - e.discs % i ? 1 : 0);
  return Array.from({ length: r }, (a, m) => s + m);
}
function Ee(e, n = {}) {
  let i = e === "jewel" ? n.thickness === "slim" ? "Slimline Jewel Case" : n.thickness === "thick" ? "Multi-CD Jewel Case" : "Jewel Case" : e === "card-sleeve" ? "Card Sleeve" : e === "gatefold" ? (n.panels ?? 2) === 2 ? "Gatefold Sleeve" : "Digisleeve" : e === "digipak" ? "Digipak" : e === "digibook" ? "Digibook" : e === "rigid-box" ? "Rigid Box" : "";
  return (e === "gatefold" || e === "digipak") && (n.panels ?? 2) > 2 && (i = (n.panels ?? 2) * 2 + "-panel " + i), n.miniLP && e === "card-sleeve" ? i = "Mini LP Sleeve" : n.miniLP && i && (i += " · Mini LP"), n.slipcase && i && (i += " + Slipcase"), i;
}
function W(e = {}) {
  const n = e, i = n.structure ?? "unknown", s = i === "jewel" ? 142.4 / 124.5 : i === "digipak" ? 1.1 : 1, r = i === "jewel" ? n.thickness === "thick" ? 0.16 : n.thickness === "slim" ? 0.037 : 0.073 : i === "rigid-box" ? 0.16 : i === "digibook" ? 0.09 : i === "digipak" ? 0.045 : i === "gatefold" ? 0.026 : n.miniLP ? 0.02 : 0.012, a = i !== "jewel" && i !== "rigid-box" ? r * (n.thickness === "slim" ? 0.7 : n.thickness === "thick" ? 1.6 : 1) : r, m = n.finish ?? (i === "jewel" ? "gloss" : "matte");
  return {
    kind: i,
    label: Ee(i, n),
    thickness: n.thickness ?? "standard",
    aspect: n.size ? n.size.width / n.size.height : s,
    depth: n.size ? n.size.depth / n.size.width : a,
    gloss: m === "gloss" ? 0.85 : m === "matte" ? 0.2 : 0.08,
    finish: m,
    panels: n.panels ?? 2,
    pockets: n.pockets ?? "right",
    pocketOpening: n.pocketOpening ?? "outer",
    holder: n.holder ?? (i === "jewel" || i === "digipak" ? "tray" : "pocket"),
    tray: n.tray ?? (i === "jewel" ? "black" : "clear"),
    discs: n.discs ?? 1,
    miniLP: n.miniLP ?? !1,
    slipcase: n.slipcase ?? !1,
    canOpen: i !== "unknown" && i !== "card-sleeve" || !!n.slipcase
  };
}
function te(e) {
  if (e.length !== 8 || e.some((w) => !Number.isFinite(w) || w < 0 || w > 1)) return null;
  const n = Array.from({ length: 4 }, (w, $) => [e[$ * 2], e[$ * 2 + 1]]), i = n.map(([w, $], T) => {
    const [M, x] = n[(T + 1) % 4], [L, O] = n[(T + 2) % 4];
    return (M - w) * (O - x) - (x - $) * (L - M);
  });
  if (!i.every((w) => w > 1e-8) && !i.every((w) => w < -1e-8)) return null;
  const [s, r, a, m, f, k, _, P] = e, d = a - f, o = _ - f, c = s - a + f - _, h = m - k, p = P - k, E = r - m + k - P, g = d * p - o * h;
  if (Math.abs(g) < 1e-12) return null;
  const y = (c * p - o * E) / g, u = (d * E - c * h) / g;
  return [1 + y, 1 + u, 1 + y + u].some((w) => !Number.isFinite(w) || w <= 1e-9) ? null : [
    a - s + y * a,
    _ - s + u * _,
    s,
    m - r + y * m,
    P - r + u * P,
    r,
    y,
    u,
    1
  ];
}
function ie(e) {
  return e.length < 2 || e.length > 17 || e.some((n) => n.length !== 4 || n.some((i) => !Number.isFinite(i) || i < 0 || i > 1)) ? !1 : e.slice(1).every((n, i) => {
    const s = e[i];
    return n[1] > s[1] && n[3] > s[3] && !!te([...s, n[2], n[3], n[0], n[1]]);
  });
}
function Fe(e, n, i) {
  if (!ie(e)) return null;
  const s = Math.max(0, Math.min(1, i)) * (e.length - 1), r = Math.min(e.length - 2, Math.floor(s)), a = s - r, m = e[r], f = e[r + 1], k = m[0] * (1 - n) + m[2] * n, _ = m[1] * (1 - n) + m[3] * n;
  return [
    k * (1 - a) + (f[0] * (1 - n) + f[2] * n) * a,
    _ * (1 - a) + (f[1] * (1 - n) + f[3] * n) * a
  ];
}
function Ge(e, n, i, s) {
  const r = s && ie(s) ? s : void 0, a = r ? r.flatMap((c) => [...c]) : i && te(i) ? [...i] : null;
  if (!a) return null;
  const m = a.filter((c, h) => h % 2 === 0), f = a.filter((c, h) => h % 2 === 1), k = Math.floor(Math.min(...m) * e), _ = Math.floor(Math.min(...f) * n), P = Math.max(1, Math.min(e - k, Math.ceil(Math.max(...m) * e) - k)), d = Math.max(1, Math.min(n - _, Math.ceil(Math.max(...f) * n) - _)), o = (c) => c.map((h, p) => p % 2 ? (h * n - _) / d : (h * e - k) / P);
  return {
    x: k,
    y: _,
    width: P,
    height: d,
    region: i ? o(i) : void 0,
    warpRows: r == null ? void 0 : r.map((c) => o(c))
  };
}
function ee(e) {
  return !!e && [e.cx, e.cy, e.rx, e.ry, e.angle].every(Number.isFinite) && e.cx >= 0 && e.cx <= 1 && e.cy >= 0 && e.cy <= 1 && e.rx >= 0.025 && e.rx <= 1 && e.ry >= 0.025 && e.ry <= 1 && Math.abs(e.angle) <= Math.PI && e.rx / e.ry >= 0.18 && e.rx / e.ry <= 5.5 && e.cx - Math.hypot(e.rx * Math.cos(e.angle), e.ry * Math.sin(e.angle)) >= -0.015 && e.cx + Math.hypot(e.rx * Math.cos(e.angle), e.ry * Math.sin(e.angle)) <= 1.015 && e.cy - Math.hypot(e.rx * Math.sin(e.angle), e.ry * Math.cos(e.angle)) >= -0.015 && e.cy + Math.hypot(e.rx * Math.sin(e.angle), e.ry * Math.cos(e.angle)) <= 1.015;
}
function de(e) {
  return !e || !ee(e.outer) || !["auto", "manual"].includes(e.source) || e.inner && (!ee(e.inner) || e.inner.rx >= e.outer.rx * 0.85 || e.inner.ry >= e.outer.ry * 0.85 || Math.hypot(e.inner.cx - e.outer.cx, e.inner.cy - e.outer.cy) > Math.max(e.outer.rx, e.outer.ry) * 0.4) ? !1 : e.confidence === void 0 || Number.isFinite(e.confidence) && e.confidence >= 0 && e.confidence <= 1;
}
function ne(e, n) {
  return [
    e.cx + e.rx * Math.cos(n) * Math.cos(e.angle) - e.ry * Math.sin(n) * Math.sin(e.angle),
    e.cy + e.rx * Math.cos(n) * Math.sin(e.angle) + e.ry * Math.sin(n) * Math.cos(e.angle)
  ];
}
function We(e, n, i, s, r = 768) {
  if (!de(s) || n < 2 || i < 2 || e.length !== n * i * 4) return null;
  const a = Math.max(16, Math.min(1536, Math.floor(r))), m = new Uint8ClampedArray(a * a * 4), f = s.outer, k = s.inner, _ = k ? Math.min(0.8, Math.max(0.125, Math.sqrt(k.rx * k.ry / (f.rx * f.ry)))) : 0, P = (d, o, c) => {
    d = Math.min(n - 1, Math.max(0, d)), o = Math.min(i - 1, Math.max(0, o));
    const h = Math.floor(d), p = Math.floor(o), E = d - h, g = o - p, y = (p * n + h) * 4, u = (p * n + Math.min(n - 1, h + 1)) * 4, w = (Math.min(i - 1, p + 1) * n + h) * 4, $ = (Math.min(i - 1, p + 1) * n + Math.min(n - 1, h + 1)) * 4;
    for (let T = 0; T < 4; T++) m[c + T] = (e[y + T] * (1 - E) + e[u + T] * E) * (1 - g) + (e[w + T] * (1 - E) + e[$ + T] * E) * g;
  };
  for (let d = 0; d < a; d++) for (let o = 0; o < a; o++) {
    const c = (o + 0.5) / a * 2 - 1, h = (d + 0.5) / a * 2 - 1, p = Math.hypot(c, h);
    if (p > 1) continue;
    const E = Math.atan2(h, c), [g, y] = ne(f, E);
    let u = f.cx + (g - f.cx) * p, w = f.cy + (y - f.cy) * p;
    if (k) {
      const [$, T] = ne(k, E);
      if (p <= _)
        u = k.cx + ($ - k.cx) * p / _, w = k.cy + (T - k.cy) * p / _;
      else {
        const M = (p - _) / (1 - _);
        u = $ + (g - $) * M, w = T + (y - T) * M;
      }
    }
    P(u * n - 0.5, w * i - 0.5, (d * a + o) * 4);
  }
  return { data: m, width: a, height: a };
}
function Be(e, n, i) {
  if (n < 60 || i < 60 || e.length !== n * i * 4) return null;
  const s = Math.min(1, 320 / Math.max(n, i)), r = Math.max(16, Math.round(n * s)), a = Math.max(16, Math.round(i * s)), m = new Float32Array(r * a);
  for (let g = 0; g < a; g++) for (let y = 0; y < r; y++) {
    const u = Math.min(n - 1, Math.floor((y + 0.5) * n / r)), $ = (Math.min(i - 1, Math.floor((g + 0.5) * i / a)) * n + u) * 4;
    m[g * r + y] = 0.2126 * e[$] + 0.7152 * e[$ + 1] + 0.0722 * e[$ + 2];
  }
  const f = (g, y) => {
    const u = Math.round(g), w = Math.round(y);
    return u < 1 || w < 1 || u >= r - 1 || w >= a - 1 ? null : m[w * r + u];
  }, k = Math.min(r, a), _ = Array.from({ length: 64 }, (g, y) => y * Math.PI / 32), P = { best: null }, d = [0.3, 0.34, 0.38, 0.42, 0.46, 0.49], o = (g) => {
    let y = 0, u = 0, w = 0;
    for (const $ of _) {
      const [T, M] = ne(g, $), x = g.cx * r, L = g.cy * a, O = T * r, S = M * a, D = O - x, H = S - L, I = Math.hypot(D, H), q = f(O - D / I * 2, S - H / I * 2), U = f(O + D / I * 2, S + H / I * 2);
      if (q === null || U === null) continue;
      const Z = Math.abs(q - U);
      y += Math.min(70, Z), Z > 13 && u++, w++;
    }
    return w < 60 ? { score: 0, hits: 0 } : { score: y / w * Math.pow(u / w, 2), hits: u / w };
  }, c = (g) => {
    if (!ee(g)) return;
    const y = o(g);
    (!P.best || y.score > P.best.score) && (P.best = { e: g, score: y.score, hits: y.hits });
  };
  for (const g of [0.4, 0.5, 0.6]) for (const y of [0.4, 0.5, 0.6]) for (const u of d)
    for (const w of [1, 0.85, 0.7, 0.55]) for (const $ of [0, Math.PI / 4, Math.PI / 2, 3 * Math.PI / 4]) {
      const T = u * k / r, M = u * w * k / a;
      c({ cx: g, cy: y, rx: T, ry: M, angle: $ });
    }
  if (!P.best) return null;
  const h = 0.035 * k;
  for (const g of [1, 0.45, 0.2]) {
    const y = P.best.e;
    for (const u of [-1, 0, 1]) for (const w of [-1, 0, 1])
      for (const $ of [-1, 0, 1]) for (const T of [-1, 0, 1]) {
        const M = {
          ...y,
          cx: y.cx + u * h * g / r,
          cy: y.cy + w * h * g / a,
          rx: y.rx + $ * h * g / r,
          ry: y.ry + T * h * g / a
        };
        c(M);
      }
  }
  const p = P.best;
  if (!p || p.hits < 0.68 || p.score < 9) return null;
  const E = Math.min(1, Math.max(0, (p.score - 8) / 30)) * p.hits;
  return E < 0.32 ? null : { outer: p.e, source: "auto", confidence: E };
}
const je = {
  $schema: "https://json-schema.org/draft/2020-12/schema",
  $id: "https://diedu.example/schema/album-document-v2.schema.json",
  title: "Album Engine canonical physical assembly v2",
  description: "Structural wire schema. Engine validates model sockets, parent graph, physical containment, complete disc allocation and provenance against model-set.json.",
  type: "object",
  properties: {
    schemaVersion: {
      const: 2
    },
    key: {
      type: "string",
      minLength: 1,
      maxLength: 200
    },
    title: {
      type: "string"
    },
    modelSet: {
      const: "album-rig-1"
    },
    assembly: {
      type: "object",
      properties: {
        root: {
          const: "package"
        },
        components: {
          type: "array",
          items: {
            oneOf: [
              {
                $ref: "#/$defs/package"
              },
              {
                $ref: "#/$defs/insert"
              }
            ]
          },
          minItems: 1,
          maxItems: 32
        }
      },
      required: [
        "root",
        "components"
      ],
      additionalProperties: !1
    },
    assets: {
      type: "object",
      propertyNames: {
        type: "string",
        pattern: "^(?!.*\\.\\.)[A-Za-z0-9][A-Za-z0-9._-]{0,199}$"
      },
      additionalProperties: {
        $ref: "#/$defs/provenance"
      },
      maxProperties: 64
    },
    preview: {
      $ref: "#/$defs/surface"
    },
    calibration: {
      type: "object",
      properties: {
        spine: {
          $ref: "#/$defs/spine"
        }
      },
      required: [
        "spine"
      ],
      additionalProperties: !1
    },
    placeholderHue: {
      enum: [
        0,
        1,
        2,
        3
      ]
    },
    presentation: {
      $ref: "#/$defs/presentation"
    }
  },
  required: [
    "schemaVersion",
    "key",
    "title",
    "modelSet",
    "assembly",
    "assets"
  ],
  additionalProperties: !1,
  $defs: {
    surface: {
      type: "object",
      properties: {
        asset: {
          type: "string",
          pattern: "^(?!.*\\.\\.)[A-Za-z0-9][A-Za-z0-9._-]{0,199}$"
        },
        region: {
          anyOf: [
            {
              type: "null"
            },
            {
              type: "array",
              items: {
                type: "number",
                minimum: 0,
                maximum: 1
              },
              minItems: 8,
              maxItems: 8
            }
          ]
        },
        warpRows: {
          type: "array",
          items: {
            type: "array",
            items: {
              type: "number",
              minimum: 0,
              maximum: 1
            },
            minItems: 4,
            maxItems: 4
          },
          minItems: 2,
          maxItems: 17
        },
        discCalibration: {
          $ref: "#/$defs/discCalibration"
        },
        origin: {
          type: "string",
          maxLength: 4096
        },
        sourceUrl: {
          type: "string",
          maxLength: 4096
        },
        sourceReleaseId: {
          type: "string",
          format: "uuid"
        }
      },
      required: [
        "asset"
      ],
      additionalProperties: !1
    },
    provenance: {
      type: "object",
      properties: {
        origin: {
          type: "string",
          maxLength: 4096
        },
        sourceUrl: {
          type: "string",
          maxLength: 4096
        },
        sourceReleaseId: {
          type: "string",
          format: "uuid"
        }
      },
      required: [],
      additionalProperties: !1
    },
    ellipse: {
      type: "object",
      properties: {
        cx: {
          type: "number",
          minimum: 0,
          maximum: 1
        },
        cy: {
          type: "number",
          minimum: 0,
          maximum: 1
        },
        rx: {
          type: "number",
          minimum: 0.025,
          maximum: 1
        },
        ry: {
          type: "number",
          minimum: 0.025,
          maximum: 1
        },
        angle: {
          type: "number",
          minimum: -3.141592653589793,
          maximum: 3.141592653589793
        }
      },
      required: [
        "cx",
        "cy",
        "rx",
        "ry",
        "angle"
      ],
      additionalProperties: !1
    },
    discCalibration: {
      type: "object",
      properties: {
        outer: {
          $ref: "#/$defs/ellipse"
        },
        inner: {
          $ref: "#/$defs/ellipse"
        },
        source: {
          enum: [
            "auto",
            "manual"
          ]
        },
        confidence: {
          type: "number",
          minimum: 0,
          maximum: 1
        }
      },
      required: [
        "outer",
        "source"
      ],
      additionalProperties: !1
    },
    dimensions: {
      type: "object",
      properties: {
        width: {
          type: "number",
          exclusiveMinimum: 0,
          maximum: 700
        },
        height: {
          type: "number",
          exclusiveMinimum: 0,
          maximum: 700
        },
        depth: {
          type: "number",
          exclusiveMinimum: 0,
          maximum: 700
        },
        basis: {
          enum: [
            "template",
            "measured"
          ]
        },
        source: {
          type: "string",
          maxLength: 1e3
        }
      },
      required: [
        "width",
        "height",
        "depth",
        "basis"
      ],
      additionalProperties: !1
    },
    package: {
      type: "object",
      properties: {
        id: {
          const: "package"
        },
        definition: {
          type: "string",
          minLength: 1
        },
        parent: {
          type: "null"
        },
        mount: {
          type: "null"
        },
        dimensions: {
          $ref: "#/$defs/dimensions"
        },
        surfaces: {
          type: "object",
          additionalProperties: {
            $ref: "#/$defs/surface"
          }
        },
        kind: {
          const: "package"
        },
        configuration: {
          type: "object",
          properties: {
            structure: {
              enum: [
                "jewel",
                "card-sleeve",
                "gatefold",
                "digipak",
                "digibook",
                "rigid-box",
                "unknown"
              ]
            },
            thickness: {
              enum: [
                "slim",
                "standard",
                "thick"
              ]
            },
            panels: {
              enum: [
                2,
                3,
                4
              ]
            },
            discs: {
              enum: [
                1,
                2,
                3,
                4
              ]
            },
            pockets: {
              enum: [
                "left",
                "right",
                "both"
              ]
            },
            pocketOpening: {
              enum: [
                "outer",
                "inner"
              ]
            },
            holder: {
              enum: [
                "tray",
                "pocket"
              ]
            },
            tray: {
              enum: [
                "clear",
                "black",
                "white"
              ]
            },
            finish: {
              enum: [
                "uncoated",
                "matte",
                "gloss"
              ]
            },
            miniLP: {
              type: "boolean"
            },
            slipcase: {
              type: "boolean"
            },
            size: {
              type: "object",
              properties: {
                width: {
                  type: "number",
                  minimum: 50,
                  maximum: 500
                },
                height: {
                  type: "number",
                  minimum: 50,
                  maximum: 700
                },
                depth: {
                  type: "number",
                  minimum: 0.1,
                  maximum: 300
                }
              },
              required: [
                "width",
                "height",
                "depth"
              ],
              additionalProperties: !1
            }
          },
          required: [],
          additionalProperties: !1
        }
      },
      required: [
        "id",
        "definition",
        "parent",
        "mount",
        "dimensions",
        "surfaces",
        "kind",
        "configuration"
      ],
      additionalProperties: !1
    },
    insert: {
      oneOf: [
        {
          $ref: "#/$defs/ordinary-insert"
        },
        {
          $ref: "#/$defs/booklet"
        }
      ]
    },
    spine: {
      type: "object",
      properties: {
        widthRatio: {
          type: "number",
          minimum: 1e-3,
          maximum: 0.2
        },
        basis: {
          const: "image-estimate"
        },
        asset: {
          type: "string",
          pattern: "^(?!.*\\.\\.)[A-Za-z0-9][A-Za-z0-9._-]{0,199}$"
        },
        origin: {
          type: "string",
          maxLength: 4096
        },
        sourceUrl: {
          type: "string",
          maxLength: 4096
        },
        sourceReleaseId: {
          type: "string",
          format: "uuid"
        },
        reliefMm: {
          type: "array",
          items: {
            type: "number",
            minimum: -0.15,
            maximum: 0.15
          },
          minItems: 3,
          maxItems: 17
        }
      },
      required: [
        "widthRatio",
        "basis",
        "asset"
      ],
      additionalProperties: !1
    },
    "ordinary-insert": {
      type: "object",
      properties: {
        id: {
          type: "string",
          pattern: "^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$"
        },
        definition: {
          type: "string",
          minLength: 1
        },
        parent: {
          type: "string",
          pattern: "^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$"
        },
        mount: {
          type: "string",
          minLength: 1
        },
        dimensions: {
          $ref: "#/$defs/dimensions"
        },
        surfaces: {
          type: "object",
          additionalProperties: {
            $ref: "#/$defs/surface"
          }
        },
        kind: {
          enum: [
            "tray",
            "pocket",
            "disc",
            "obi",
            "inner-sleeve"
          ]
        },
        contains: {
          type: "array",
          items: {
            type: "string",
            pattern: "^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$"
          },
          uniqueItems: !0,
          maxItems: 4
        }
      },
      required: [
        "id",
        "definition",
        "parent",
        "mount",
        "dimensions",
        "surfaces",
        "kind"
      ],
      additionalProperties: !1
    },
    booklet: {
      type: "object",
      properties: {
        id: {
          type: "string",
          pattern: "^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$"
        },
        definition: {
          type: "string",
          minLength: 1
        },
        parent: {
          type: "string",
          pattern: "^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$"
        },
        mount: {
          type: "string",
          minLength: 1
        },
        dimensions: {
          $ref: "#/$defs/dimensions"
        },
        surfaces: {
          type: "object",
          additionalProperties: {
            $ref: "#/$defs/surface"
          }
        },
        kind: {
          const: "booklet"
        },
        contains: {
          type: "array",
          items: {
            type: "string",
            pattern: "^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$"
          },
          uniqueItems: !0,
          maxItems: 4
        },
        fold: {
          $ref: "#/$defs/paper-fold"
        }
      },
      required: [
        "id",
        "definition",
        "parent",
        "mount",
        "dimensions",
        "surfaces",
        "kind"
      ],
      additionalProperties: !1
    },
    "paper-fold": {
      type: "object",
      description: "Nominal accordion sheet, with folded dimensions carried by its booklet component.",
      properties: {
        pattern: {
          const: "accordion"
        },
        panels: {
          type: "integer",
          minimum: 2,
          maximum: 6
        }
      },
      required: [
        "pattern",
        "panels"
      ],
      additionalProperties: !1
    },
    presentation: {
      type: "object",
      properties: {
        initialCamera: {
          $ref: "#/$defs/initial-camera"
        }
      },
      required: [
        "initialCamera"
      ],
      additionalProperties: !1
    },
    "initial-camera": {
      type: "object",
      description: "Authored initial pose only. Angles in radians; framing fractions of visible width/height. Runtime dragging never rewrites this profile.",
      properties: {
        pitch: {
          type: "number",
          minimum: -1.2566370614359172,
          maximum: 1.2566370614359172
        },
        yaw: {
          type: "number",
          minimum: -6.283185307179586,
          maximum: 6.283185307179586
        },
        zoom: {
          type: "number",
          minimum: 0.7,
          maximum: 2
        },
        framingX: {
          type: "number",
          minimum: -0.5,
          maximum: 0.5
        },
        framingY: {
          type: "number",
          minimum: -0.5,
          maximum: 0.5
        }
      },
      additionalProperties: !1
    }
  }
}, pe = je;
function V(e, n) {
  if (n.$ref) return V(e, pe.$defs[n.$ref.split("/").at(-1)]);
  if ("const" in n && e !== n.const || n.enum && !n.enum.includes(e) || n.oneOf && n.oneOf.filter((i) => V(e, i)).length !== 1 || n.anyOf && !n.anyOf.some((i) => V(e, i))) return !1;
  if (n.type === "null") return e === null;
  if (n.type === "boolean") return typeof e == "boolean";
  if (n.type === "number" || n.type === "integer")
    return typeof e != "number" || !Number.isFinite(e) || n.type === "integer" && !Number.isInteger(e) ? !1 : (n.minimum === void 0 || e >= n.minimum) && (n.maximum === void 0 || e <= n.maximum) && (n.exclusiveMinimum === void 0 || e > n.exclusiveMinimum) && (n.exclusiveMaximum === void 0 || e < n.exclusiveMaximum);
  if (n.type === "string") return typeof e == "string" && (n.minLength === void 0 || Array.from(e).length >= n.minLength) && (n.maxLength === void 0 || Array.from(e).length <= n.maxLength) && (!n.pattern || new RegExp(n.pattern).test(e)) && (n.format !== "uuid" || /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(e));
  if (n.type === "array") return Array.isArray(e) && (n.minItems === void 0 || e.length >= n.minItems) && (n.maxItems === void 0 || e.length <= n.maxItems) && (!n.items || e.every((i) => V(i, n.items))) && (!n.uniqueItems || new Set(e.map((i) => JSON.stringify(i))).size === e.length);
  if (n.type === "object") {
    if (!e || typeof e != "object" || Array.isArray(e)) return !1;
    const i = e, s = Object.keys(i);
    return (n.required ?? []).some((r) => !Object.hasOwn(i, r)) || n.minProperties !== void 0 && s.length < n.minProperties || n.maxProperties !== void 0 && s.length > n.maxProperties ? !1 : s.every((r) => {
      var a;
      return (!n.propertyNames || V(r, n.propertyNames)) && ((a = n.properties) != null && a[r] ? V(i[r], n.properties[r]) : n.additionalProperties === !1 ? !1 : typeof n.additionalProperties == "object" ? V(i[r], n.additionalProperties) : !0);
    });
  }
  return !0;
}
function Re(e) {
  return V(e, pe);
}
const oe = ue.modelSet, fe = ue.models;
function $e(e) {
  const n = e.assembly.components.find((i) => i.id === e.assembly.root);
  if ((n == null ? void 0 : n.kind) !== "package") throw new Error("Missing album package");
  return n;
}
function Te(e) {
  var _, P;
  if (e.schemaVersion !== 1 || (_ = e.components) != null && _.length) throw new Error("Legacy attachment ownership is unknown");
  const n = W(e.packaging), i = me(n, !!e.calibration).replace(/\.glb$/, ""), s = fe[i];
  if (!s) throw new Error("Unsupported album model");
  const [r, a, m] = s.nominal_mm, f = [{
    id: "package",
    kind: "package",
    definition: i,
    parent: null,
    mount: null,
    configuration: structuredClone(e.packaging),
    dimensions: { ...e.packaging.size ?? { width: r, height: a, depth: m }, basis: e.packaging.size ? "measured" : "template" },
    surfaces: structuredClone(e.surfaces)
  }];
  for (let d = 0; d < n.panels; d++) {
    const o = B(n, d);
    if (!o.length) continue;
    const c = `${n.holder}:${n.kind === "jewel" ? 0 : d}`, h = s.sockets[c];
    if (!h) throw new Error("Missing disc carrier socket");
    const p = c.replace(":", "-"), [E, g, y] = h.size_mm;
    f.push({
      id: p,
      kind: n.holder,
      definition: n.holder,
      parent: "package",
      mount: c,
      dimensions: { width: E, height: g, depth: y, basis: "template" },
      surfaces: {},
      contains: o.map((u) => "disc-" + u)
    });
    for (const u of o) f.push({
      id: "disc-" + u,
      kind: "disc",
      definition: "cd",
      parent: p,
      mount: "disc:" + u,
      dimensions: { width: 120, height: 120, depth: 1.2, basis: "template" },
      surfaces: e.surfaces[u === 0 ? "disc" : "disc" + (u + 1)] ? { front: structuredClone(e.surfaces[u === 0 ? "disc" : "disc" + (u + 1)]) } : {}
    });
    if (n.kind === "jewel" || n.kind === "card-sleeve" || n.kind === "rigid-box") break;
  }
  const k = Object.fromEntries(Object.values(e.surfaces).filter((d) => !!d).map((d) => [
    d.asset,
    Object.fromEntries(Object.entries(d).filter(([o, c]) => ["origin", "sourceUrl", "sourceReleaseId"].includes(o) && c !== void 0))
  ]));
  return e.calibration && (k[P = e.calibration.spine.asset] ?? (k[P] = { origin: e.calibration.spine.origin, sourceUrl: e.calibration.spine.sourceUrl })), {
    schemaVersion: 2,
    key: e.key,
    title: e.title,
    modelSet: oe,
    assembly: { root: "package", components: f },
    assets: k,
    ...e.surfaces.front ? { preview: e.surfaces.front } : {},
    ...e.calibration ? { calibration: structuredClone(e.calibration) } : {},
    ...e.placeholderHue === void 0 ? {} : { placeholderHue: e.placeholderHue }
  };
}
function Ae(e) {
  var P, d;
  if (e.modelSet !== oe) return "model";
  if (typeof e.key != "string" || !e.key || e.key.length > 200 || typeof e.title != "string" || !e.assembly || !Array.isArray(e.assembly.components) || !e.assets || typeof e.assets != "object" || Object.keys(e).some((o) => !["schemaVersion", "key", "title", "modelSet", "assembly", "assets", "preview", "calibration", "placeholderHue", "presentation"].includes(o))) return "schema";
  if (Object.keys(e.assets).length > 64 || Object.entries(e.assets).some(([o, c]) => !/^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/.test(o) || o.includes("..") || !c || Object.entries(c).some(([h, p]) => !["origin", "sourceUrl", "sourceReleaseId"].includes(h) || typeof p != "string" || p.length > 4096))) return "assets";
  const n = e.assembly.components;
  if (!n.length || n.length > 32) return "assembly";
  const i = new Map(n.map((o) => [o.id, o]));
  if (i.size !== n.length || n.some((o) => typeof o.id != "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,99}$/.test(o.id))) return "assembly";
  const s = i.get(e.assembly.root);
  if ((s == null ? void 0 : s.kind) !== "package" || s.parent !== null || s.mount !== null) return "assembly";
  const r = fe[s.definition];
  if (!r || me(W(s.configuration), !!e.calibration).replace(/\.glb$/, "") !== s.definition) return "model";
  if ("photos" in s.configuration || "photoRegions" in s.configuration) return "assembly";
  const a = W(s.configuration);
  if (s.configuration.size && ["width", "height", "depth"].some((o, c) => Math.abs(s.configuration.size[o] - r.nominal_mm[c]) > 1e-3)) return "model";
  const m = s.configuration.size ? [s.configuration.size.width, s.configuration.size.height, s.configuration.size.depth] : r.nominal_mm;
  if (["width", "height", "depth"].some((o, c) => Math.abs(s.dimensions[o] - m[c]) > 1e-6) || s.dimensions.basis !== (s.configuration.size ? "measured" : "template")) return "assembly";
  const f = (o) => !o || typeof o.asset != "string" || !Object.hasOwn(e.assets, o.asset) || Object.keys(o).some((c) => !["asset", "region", "warpRows", "discCalibration", "origin", "sourceUrl", "sourceReleaseId"].includes(c)) || ["origin", "sourceUrl", "sourceReleaseId"].some((c) => c in o && o[c] !== e.assets[o.asset][c]) || o.region && (o.region.length !== 8 || !o.region.every((c) => Number.isFinite(c) && c >= 0 && c <= 1) || !te(o.region)) ? !1 : (!o.warpRows || ie(o.warpRows)) && (!o.discCalibration || de(o.discCalibration)), k = /* @__PURE__ */ new Set();
  for (const o of n) {
    const c = o.dimensions;
    if (Object.keys(o).some((u) => !["id", "kind", "definition", "parent", "mount", "dimensions", "surfaces", "configuration", "contains", "fold"].includes(u)) || !c || !["measured", "template"].includes(c.basis) || ![c.width, c.height, c.depth].every((u) => typeof u == "number" && Number.isFinite(u) && u > 0 && u <= 700) || o.kind === "booklet" && o.fold && c.depth + 1e-6 < o.fold.panels * 0.1 || "position" in o || "scale" in o || "rotation" in o) return "assembly";
    if (!o.surfaces || typeof o.surfaces != "object") return "assets";
    for (const u of Object.values(o.surfaces))
      if (!f(u)) return "assets";
    if (o === s) continue;
    const h = o.kind === "disc" ? ["front"] : ["obi", "booklet", "inner-sleeve"].includes(o.kind) ? ["front", "back"] : [];
    if (Object.keys(o.surfaces).some((u) => !h.includes(u))) return "assets";
    const p = o.parent ? i.get(o.parent) : void 0;
    if (!p || !o.mount) return "assembly";
    const E = o.parent + ":" + o.mount;
    if (k.has(E)) return "assembly";
    k.add(E);
    const g = /* @__PURE__ */ new Set([o.id]);
    let y = p;
    for (; y; ) {
      if (g.has(y.id)) return "assembly";
      g.add(y.id), y = y.parent ? i.get(y.parent) : void 0;
    }
    if (!g.has(s.id)) return "assembly";
    if (o.kind === "disc") {
      if (!["pocket", "tray", "inner-sleeve"].includes(p.kind) || !/^disc:[0-3]$/.test(o.mount) || o.definition !== "cd" || c.width !== 120 || c.height !== 120 || c.depth !== 1.2) return "assembly";
      const u = p.kind === "inner-sleeve" ? i.get(p.parent) : p, w = Number((P = u == null ? void 0 : u.mount) == null ? void 0 : P.split(":")[1]);
      if (!B(a, w).includes(Number(o.mount.split(":")[1])) || p.kind === "inner-sleeve" && (((d = p.contains) == null ? void 0 : d.length) !== 1 || !p.contains.includes(o.id) || p.dimensions.width < 121.3 || p.dimensions.height < 121.3 || p.dimensions.depth < 1.6)) return "assembly";
    } else {
      const u = r.sockets[o.mount];
      if (!u || u.kind !== o.kind || o.definition !== o.kind || o.kind === "inner-sleeve" && (p.kind !== "pocket" || p.mount !== "pocket:" + u.panel) || o.kind !== "inner-sleeve" && p !== s) return "assembly";
      if (o.kind === "pocket" || o.kind === "tray") {
        if (o.kind !== a.holder || !B(a, u.panel).length || Object.keys(o.surfaces).length) return "assembly";
      } else if (!o.surfaces.front) return "assets";
      if (c.width > u.size_mm[0] + 1e-3 || c.height > u.size_mm[1] + 1e-3 || c.depth > u.size_mm[2] + 1e-3 || o.kind === "obi" && (c.height > s.dimensions.height || c.width > s.dimensions.width / 2) || o.kind === "inner-sleeve" && (c.width > p.dimensions.width || c.height > p.dimensions.height || c.depth > p.dimensions.depth)) return "assembly";
    }
    if (o.contains) {
      if (!["pocket", "tray", "inner-sleeve"].includes(o.kind) || new Set(o.contains).size !== o.contains.length) return "assembly";
      const u = n.filter((w) => w.parent === o.id && w.kind === "disc");
      if (u.length !== o.contains.length || u.some((w) => !o.contains.includes(w.id))) return "assembly";
    }
  }
  const _ = n.filter((o) => o.kind === "disc");
  return _.length !== W(s.configuration).discs || new Set(_.map((o) => o.mount)).size !== _.length ? "assembly" : e.preview && !f(e.preview) || e.calibration && (!e.calibration.spine || !Object.hasOwn(e.assets, e.calibration.spine.asset) || e.calibration.spine.basis !== "image-estimate" || !Number.isFinite(e.calibration.spine.widthRatio) || e.calibration.spine.widthRatio < 1e-3 || e.calibration.spine.widthRatio > 0.2) ? "assets" : null;
}
function ke(e, n = { rigVersion: 1 }) {
  if (n.rigVersion !== 1 || !e || typeof e != "object") return { supported: !1, reason: "schema" };
  try {
    const i = e, s = i.schemaVersion === 1 ? Te(i) : i;
    if (s.schemaVersion !== 2) return { supported: !1, reason: "schema" };
    if (!Re(s)) return { supported: !1, reason: "schema" };
    const r = Ae(s);
    return r ? { supported: !1, reason: r } : { supported: !0, entity: s, modelSet: oe };
  } catch {
    return { supported: !1, reason: "assembly" };
  }
}
function Ce(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var Q = { exports: {} }, z = {}, ce;
function Oe() {
  if (ce) return z;
  ce = 1;
  /**
   * @license React
   * react.production.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   */
  var e = Symbol.for("react.transitional.element"), n = Symbol.for("react.portal"), i = Symbol.for("react.fragment"), s = Symbol.for("react.strict_mode"), r = Symbol.for("react.profiler"), a = Symbol.for("react.consumer"), m = Symbol.for("react.context"), f = Symbol.for("react.forward_ref"), k = Symbol.for("react.suspense"), _ = Symbol.for("react.memo"), P = Symbol.for("react.lazy"), d = Symbol.for("react.activity"), o = Symbol.for("react.view_transition"), c = Symbol.iterator;
  function h(t) {
    return t === null || typeof t != "object" ? null : (t = c && t[c] || t["@@iterator"], typeof t == "function" ? t : null);
  }
  var p = {
    isMounted: function() {
      return !1;
    },
    enqueueForceUpdate: function() {
    },
    enqueueReplaceState: function() {
    },
    enqueueSetState: function() {
    }
  }, E = Object.assign, g = {};
  function y(t, l, b) {
    this.props = t, this.context = l, this.refs = g, this.updater = b || p;
  }
  y.prototype.isReactComponent = {}, y.prototype.setState = function(t, l) {
    if (typeof t != "object" && typeof t != "function" && t != null)
      throw Error(
        "takes an object of state variables to update or a function which returns an object of state variables."
      );
    this.updater.enqueueSetState(this, t, l, "setState");
  }, y.prototype.forceUpdate = function(t) {
    this.updater.enqueueForceUpdate(this, t, "forceUpdate");
  };
  function u() {
  }
  u.prototype = y.prototype;
  function w(t, l, b) {
    this.props = t, this.context = l, this.refs = g, this.updater = b || p;
  }
  var $ = w.prototype = new u();
  $.constructor = w, E($, y.prototype), $.isPureReactComponent = !0;
  var T = Array.isArray;
  function M() {
  }
  var x = { H: null, A: null, T: null, S: null }, L = Object.prototype.hasOwnProperty;
  function O(t, l, b) {
    var v = b.ref;
    return {
      $$typeof: e,
      type: t,
      key: l,
      ref: v !== void 0 ? v : null,
      props: b
    };
  }
  function S(t, l) {
    return O(t.type, l, t.props);
  }
  function D(t) {
    return typeof t == "object" && t !== null && t.$$typeof === e;
  }
  function H(t) {
    var l = { "=": "=0", ":": "=2" };
    return "$" + t.replace(/[=:]/g, function(b) {
      return l[b];
    });
  }
  var I = /\/+/g;
  function q(t, l) {
    return typeof t == "object" && t !== null && t.key != null ? H("" + t.key) : l.toString(36);
  }
  function U(t) {
    switch (t.status) {
      case "fulfilled":
        return t.value;
      case "rejected":
        throw t.reason;
      default:
        switch (typeof t.status == "string" ? t.then(M, M) : (t.status = "pending", t.then(
          function(l) {
            t.status === "pending" && (t.status = "fulfilled", t.value = l);
          },
          function(l) {
            t.status === "pending" && (t.status = "rejected", t.reason = l);
          }
        )), t.status) {
          case "fulfilled":
            return t.value;
          case "rejected":
            throw t.reason;
        }
    }
    throw t;
  }
  function Z(t, l, b, v, j) {
    var R = typeof t;
    (R === "undefined" || R === "boolean") && (t = null);
    var A = !1;
    if (t === null) A = !0;
    else
      switch (R) {
        case "bigint":
        case "string":
        case "number":
          A = !0;
          break;
        case "object":
          switch (t.$$typeof) {
            case e:
            case n:
              A = !0;
              break;
            case P:
              return A = t._init, Z(
                A(t._payload),
                l,
                b,
                v,
                j
              );
          }
      }
    if (A)
      return j = j(t), A = v === "" ? "." + q(t, 0) : v, T(j) ? (b = "", A != null && (b = A.replace(I, "$&/") + "/"), Z(j, l, b, "", function(he) {
        return he;
      })) : j != null && (D(j) && (j = S(
        j,
        b + (j.key == null || t && t.key === j.key ? "" : ("" + j.key).replace(
          I,
          "$&/"
        ) + "/") + A
      )), l.push(j)), 1;
    A = 0;
    var Y = v === "" ? "." : v + ":";
    if (T(t))
      for (var N = 0; N < t.length; N++)
        v = t[N], R = Y + q(v, N), A += Z(
          v,
          l,
          b,
          R,
          j
        );
    else if (N = h(t), typeof N == "function")
      for (t = N.call(t), N = 0; !(v = t.next()).done; )
        v = v.value, R = Y + q(v, N++), A += Z(
          v,
          l,
          b,
          R,
          j
        );
    else if (R === "object") {
      if (typeof t.then == "function")
        return Z(
          U(t),
          l,
          b,
          v,
          j
        );
      throw l = String(t), Error(
        "Objects are not valid as a React child (found: " + (l === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : l) + "). If you meant to render a collection of children, use an array instead."
      );
    }
    return A;
  }
  function J(t, l, b) {
    if (t == null) return t;
    var v = [], j = 0;
    return Z(t, v, "", "", function(R) {
      return l.call(b, R, j++);
    }), v;
  }
  function ye(t) {
    if (t._status === -1) {
      var l = t._result, b = l();
      b.then(
        function(v) {
          (t._status === 0 || t._status === -1) && (t._status = 1, t._result = v, b.status === void 0 && (b.status = "fulfilled", b.value = v));
        },
        function(v) {
          (t._status === 0 || t._status === -1) && (t._status = 2, t._result = v, b.status === void 0 && (b.status = "rejected", b.reason = v));
        }
      ), t._status === -1 && (t._status = 0, t._result = b);
    }
    if (t._status === 1) return t._result.default;
    throw t._result;
  }
  var se = typeof reportError == "function" ? reportError : function(t) {
    if (typeof window == "object" && typeof window.ErrorEvent == "function") {
      var l = new window.ErrorEvent("error", {
        bubbles: !0,
        cancelable: !0,
        message: typeof t == "object" && t !== null && typeof t.message == "string" ? String(t.message) : String(t),
        error: t
      });
      if (!window.dispatchEvent(l)) return;
    }
    console.error(t);
  };
  function re(t) {
    var l = x.T, b = {};
    b.types = l !== null ? l.types : null, x.T = b;
    try {
      var v = t(), j = x.S;
      j !== null && j(b, v), typeof v == "object" && v !== null && typeof v.then == "function" && v.then(M, se);
    } catch (R) {
      se(R);
    } finally {
      l !== null && b.types !== null && (l.types = b.types), x.T = l;
    }
  }
  function ae(t) {
    var l = x.T;
    if (l !== null) {
      var b = l.types;
      b === null ? l.types = [t] : b.indexOf(t) === -1 && b.push(t);
    } else re(ae.bind(null, t));
  }
  var be = {
    map: J,
    forEach: function(t, l, b) {
      J(
        t,
        function() {
          l.apply(this, arguments);
        },
        b
      );
    },
    count: function(t) {
      var l = 0;
      return J(t, function() {
        l++;
      }), l;
    },
    toArray: function(t) {
      return J(t, function(l) {
        return l;
      }) || [];
    },
    only: function(t) {
      if (!D(t))
        throw Error(
          "React.Children.only expected to receive a single React element child."
        );
      return t;
    }
  };
  return z.Activity = d, z.Children = be, z.Component = y, z.Fragment = i, z.Profiler = r, z.PureComponent = w, z.StrictMode = s, z.Suspense = k, z.ViewTransition = o, z.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = x, z.__COMPILER_RUNTIME = {
    __proto__: null,
    c: function(t) {
      return x.H.useMemoCache(t);
    }
  }, z.addTransitionType = ae, z.cache = function(t) {
    return function() {
      return t.apply(null, arguments);
    };
  }, z.cacheSignal = function() {
    return null;
  }, z.cloneElement = function(t, l, b) {
    if (t == null)
      throw Error(
        "The argument must be a React element, but you passed " + t + "."
      );
    var v = E({}, t.props), j = t.key;
    if (l != null)
      for (R in l.key !== void 0 && (j = "" + l.key), l)
        !L.call(l, R) || R === "key" || R === "__self" || R === "__source" || R === "ref" && l.ref === void 0 || (v[R] = l[R]);
    var R = arguments.length - 2;
    if (R === 1) v.children = b;
    else if (1 < R) {
      for (var A = Array(R), Y = 0; Y < R; Y++)
        A[Y] = arguments[Y + 2];
      v.children = A;
    }
    return O(t.type, j, v);
  }, z.createContext = function(t) {
    return t = {
      $$typeof: m,
      _currentValue: t,
      _currentValue2: t,
      _threadCount: 0,
      Provider: null,
      Consumer: null
    }, t.Provider = t, t.Consumer = {
      $$typeof: a,
      _context: t
    }, t;
  }, z.createElement = function(t, l, b) {
    var v, j = {}, R = null;
    if (l != null)
      for (v in l.key !== void 0 && (R = "" + l.key), l)
        L.call(l, v) && v !== "key" && v !== "__self" && v !== "__source" && (j[v] = l[v]);
    var A = arguments.length - 2;
    if (A === 1) j.children = b;
    else if (1 < A) {
      for (var Y = Array(A), N = 0; N < A; N++)
        Y[N] = arguments[N + 2];
      j.children = Y;
    }
    if (t && t.defaultProps)
      for (v in A = t.defaultProps, A)
        j[v] === void 0 && (j[v] = A[v]);
    return O(t, R, j);
  }, z.createRef = function() {
    return { current: null };
  }, z.forwardRef = function(t) {
    return { $$typeof: f, render: t };
  }, z.isValidElement = D, z.lazy = function(t) {
    return {
      $$typeof: P,
      _payload: { _status: -1, _result: t },
      _init: ye
    };
  }, z.memo = function(t, l) {
    return {
      $$typeof: _,
      type: t,
      compare: l === void 0 ? null : l
    };
  }, z.startTransition = re, z.unstable_useCacheRefresh = function() {
    return x.H.useCacheRefresh();
  }, z.use = function(t) {
    return x.H.use(t);
  }, z.useActionState = function(t, l, b) {
    return x.H.useActionState(t, l, b);
  }, z.useCallback = function(t, l) {
    return x.H.useCallback(t, l);
  }, z.useContext = function(t) {
    return x.H.useContext(t);
  }, z.useDebugValue = function() {
  }, z.useDeferredValue = function(t, l) {
    return x.H.useDeferredValue(t, l);
  }, z.useEffect = function(t, l) {
    return x.H.useEffect(t, l);
  }, z.useEffectEvent = function(t) {
    return x.H.useEffectEvent(t);
  }, z.useId = function() {
    return x.H.useId();
  }, z.useImperativeHandle = function(t, l, b) {
    return x.H.useImperativeHandle(t, l, b);
  }, z.useInsertionEffect = function(t, l) {
    return x.H.useInsertionEffect(t, l);
  }, z.useLayoutEffect = function(t, l) {
    return x.H.useLayoutEffect(t, l);
  }, z.useMemo = function(t, l) {
    return x.H.useMemo(t, l);
  }, z.useOptimistic = function(t, l) {
    return x.H.useOptimistic(t, l);
  }, z.useReducer = function(t, l, b) {
    return x.H.useReducer(t, l, b);
  }, z.useRef = function(t) {
    return x.H.useRef(t);
  }, z.useState = function(t) {
    return x.H.useState(t);
  }, z.useSyncExternalStore = function(t, l, b) {
    return x.H.useSyncExternalStore(
      t,
      l,
      b
    );
  }, z.useTransition = function() {
    return x.H.useTransition();
  }, z.version = "19.3.0", z;
}
var le;
function Le() {
  return le || (le = 1, Q.exports = Oe()), Q.exports;
}
var C = Le();
const Ie = /* @__PURE__ */ Ce(C), Se = /* @__PURE__ */ _e({
  __proto__: null,
  default: Ie
}, [C]);
function Ne(e, n) {
  return e !== null && n !== null && Number.isFinite(e) && Number.isFinite(n) ? { beta: e, gamma: n } : null;
}
function K(e, n, i) {
  return ((e - n + i / 2) % i + i) % i - i / 2;
}
function De(e, n, i = 0) {
  const s = {
    pitch: K(e.beta, n.beta, 360),
    yaw: K(e.gamma, n.gamma, 360)
  }, r = {
    pitch: K(180 - e.beta, n.beta, 360),
    yaw: K(e.gamma + 180, n.gamma, 360)
  }, { pitch: a, yaw: m } = s.pitch ** 2 + s.yaw ** 2 <= r.pitch ** 2 + r.yaw ** 2 ? s : r, f = i * Math.PI / 180, k = (_) => Math.max(-18, Math.min(18, _));
  return {
    x: k(-a * Math.cos(f) - m * Math.sin(f)),
    y: k(m * Math.cos(f) - a * Math.sin(f))
  };
}
function Je() {
  var e;
  if (G() || !navigator.maxTouchPoints && !window.matchMedia("(pointer: coarse)").matches) return Promise.resolve("unavailable");
  try {
    const n = window.DeviceOrientationEvent, i = (e = n.requestPermission) == null ? void 0 : e.call(n);
    return i ? i.catch(() => "denied") : Promise.resolve("granted");
  } catch {
    return Promise.resolve("denied");
  }
}
function G() {
  return window.isSecureContext ? typeof window.DeviceOrientationEvent != "function" ? "当前设备不支持运动感应，仍可拖动旋转" : null : "运动感应需要 HTTPS，仍可拖动旋转";
}
function F() {
  var n;
  const e = ((n = window.screen.orientation) == null ? void 0 : n.angle) ?? window.orientation ?? 0;
  return Number.isFinite(e) ? e : 0;
}
function Ke(e) {
  const n = C.useRef(e);
  n.current = e;
  const [i, s] = C.useState(!1), [r, a] = C.useState(() => G() ? "unavailable" : "idle"), [m, f] = C.useState(() => window.matchMedia("(prefers-reduced-motion: reduce)").matches), [k, _] = C.useState(() => !document.hidden), [P, d] = C.useState(F), o = C.useRef(null), c = C.useRef(!0), h = C.useRef(0), p = C.useRef(!1), E = C.useRef(!1), g = C.useRef(!1), y = C.useRef(m), u = C.useCallback(() => {
    o.current = null, n.current.onTilt(0, 0);
  }, []), w = C.useCallback(() => {
    h.current++, p.current = !1, g.current = !1, s(!1), a(G() ? "unavailable" : "idle"), u();
  }, [u]), $ = C.useCallback(async () => {
    var x;
    if (!c.current || p.current) return;
    if (G()) {
      a("unavailable");
      return;
    }
    const M = ++h.current;
    if (!E.current) {
      p.current = !0, a("requesting");
      try {
        const L = window.DeviceOrientationEvent, O = (x = L.requestPermission) == null ? void 0 : x.call(L), S = O ? await O : "granted";
        if (!c.current || h.current !== M) return;
        if (S !== "granted") {
          a("denied");
          return;
        }
        E.current = !0;
      } catch {
        c.current && h.current === M && a("denied");
        return;
      } finally {
        h.current === M && (p.current = !1);
      }
    }
    !c.current || h.current !== M || (u(), g.current = !0, s(!0));
  }, [u]);
  C.useEffect(() => {
    var D, H, I;
    if ((D = e.lifecycle) != null && D.aborted) return;
    c.current = !0;
    const M = window.matchMedia("(prefers-reduced-motion: reduce)"), x = () => {
      y.current = M.matches, f(M.matches), u();
    }, L = () => {
      _(!document.hidden), u();
    }, O = () => {
      d(F()), u();
    };
    M.addEventListener("change", x), document.addEventListener("visibilitychange", L), (H = window.screen.orientation) == null || H.addEventListener("change", O), window.addEventListener("orientationchange", O);
    const S = () => {
      var q, U;
      (q = e.lifecycle) == null || q.removeEventListener("abort", S), c.current = !1, h.current++, p.current = !1, M.removeEventListener("change", x), document.removeEventListener("visibilitychange", L), (U = window.screen.orientation) == null || U.removeEventListener("change", O), window.removeEventListener("orientationchange", O);
    };
    return (I = e.lifecycle) == null || I.addEventListener("abort", S, { once: !0 }), S;
  }, [u, e.lifecycle]), C.useEffect(() => {
    const M = e.permission;
    if (!M) return;
    let x = !0;
    return M.then((L) => {
      if (!(!x || !c.current)) {
        if (L !== "granted") {
          a(L === "denied" ? "denied" : "unavailable");
          return;
        }
        E.current = !0, u(), g.current = !0, s(!0);
      }
    }), () => {
      x = !1;
    };
  }, [e.permission, u]), C.useEffect(() => {
    var D, H;
    if (!i || (D = e.lifecycle) != null && D.aborted) return;
    if (u(), m) {
      a("reduced-motion");
      return;
    }
    if (!e.active || !k) {
      a("paused");
      return;
    }
    let M = !0;
    const x = F();
    a("waiting");
    const L = window.setTimeout(() => {
      M && c.current && g.current && !o.current && a("no-signal");
    }, 4e3), O = (I) => {
      if (!M || !c.current || !g.current || !n.current.active || document.hidden || y.current) return;
      const q = Ne(I.beta, I.gamma);
      if (!q) return;
      if (F() !== x) {
        u(), d(F());
        return;
      }
      o.current || (o.current = q);
      const U = De(q, o.current, x);
      window.clearTimeout(L), a("enabled"), n.current.onTilt(U.x, U.y);
    };
    window.addEventListener("deviceorientation", O);
    const S = () => {
      var I;
      (I = e.lifecycle) == null || I.removeEventListener("abort", S), M = !1, window.clearTimeout(L), window.removeEventListener("deviceorientation", O), o.current = null;
    };
    return (H = e.lifecycle) == null || H.addEventListener("abort", S, { once: !0 }), S;
  }, [i, e.active, m, k, P, u, e.lifecycle]);
  const T = {
    idle: "开启后，轻转手机查看光泽",
    requesting: "等待运动感应授权…",
    waiting: "正在等待运动感应数据…",
    enabled: "轻转手机，查看光泽",
    paused: "运动感应已暂停",
    denied: "未获运动感应权限，仍可拖动旋转",
    unavailable: G() ?? "当前浏览器无法启用运动感应，仍可拖动旋转",
    "no-signal": "未收到运动感应数据，仍可拖动旋转",
    "reduced-motion": "减少动态效果已开启，运动感应暂停"
  };
  return { status: r, message: T[r], intended: i, enable: $, disable: w, recalibrate: u };
}
const Xe = [
  { value: "card-sleeve", label: "Card Sleeve / 纸封套" },
  { value: "jewel", label: "Jewel Case / 塑料盒" },
  { value: "gatefold", label: "Gatefold / 对折纸封" },
  { value: "digipak", label: "Digipak" },
  { value: "digibook", label: "Digibook" },
  { value: "rigid-box", label: "Rigid Box" }
], ge = [
  { kind: "obi", label: "独立侧标 OBI", shortLabel: "侧标 OBI" },
  { kind: "booklet", label: "可取出的歌词册", shortLabel: "歌词册" },
  { kind: "inner-sleeve", label: "纸质内袋", shortLabel: "内袋" }
], Qe = {
  front: "正面",
  back: "背面",
  insideLeft: "左内面",
  insideRight: "右内面",
  disc: "CD 1",
  disc2: "CD 2",
  disc3: "CD 3",
  disc4: "CD 4",
  outer: "外套",
  spine: "书脊"
};
function qe(e) {
  const n = (e || "").toLowerCase();
  return n.includes("gatefold") ? "gatefold" : n.includes("digipak") ? "digipak" : n.includes("digibook") ? "digibook" : n.includes("jewel") ? "jewel" : n.includes("cardboard") || n.includes("sleeve") ? "card-sleeve" : "";
}
function He(e) {
  return e ? [
    ...(e.artwork || []).map((n) => ({
      sourceId: "caa:" + n.id,
      types: n.types,
      origin: "caa",
      guidedLabel: n.types.join(" / ") || "CAA",
      accessoryLabel: "CAA · " + n.types.join(", ")
    })),
    ...(e.editionReferences || []).filter((n) => n.status === "verified").flatMap((n) => (n.images || []).map((i, s) => ({
      sourceId: i.sourceId,
      types: [],
      origin: "verified-discogs",
      guidedLabel: "Discogs #" + s,
      accessoryLabel: "Discogs #" + (s + 1)
    }))),
    ...(e.compatibleArtwork || []).flatMap((n) => n.images.map((i) => ({
      sourceId: i.sourceId,
      types: i.types,
      origin: "compatible-edition",
      guidedLabel: "同封装版次 / " + i.types.join(", "),
      accessoryLabel: "同封装版 · " + i.types.join(", ")
    })))
  ] : [];
}
function en(e, n) {
  return [...e.map((i, s) => ({
    ...i,
    types: [],
    origin: "record-photo",
    guidedLabel: "本人实物照片 #" + (s + 1),
    accessoryLabel: "实物照片 " + (s + 1)
  })), ...He(n)];
}
function Ue(e, n) {
  return [
    "front",
    "back",
    ...["jewel", "gatefold", "digipak", "digibook"].includes(e) ? ["insideLeft"] : [],
    ...["gatefold", "digipak", "digibook"].includes(e) ? ["insideRight"] : [],
    ...Array.from({ length: n }, (i, s) => s === 0 ? "disc" : "disc" + (s + 1))
  ];
}
function nn(e, n) {
  const i = { ...e };
  for (const s of ["front", "back", "disc"]) {
    const r = s === "disc" ? "medium" : s, a = n.find((m) => m.types.some((f) => f.toLowerCase() === r));
    a && (i[s] = a.sourceId);
  }
  return i;
}
function tn(e, n, i, s, r, a, m) {
  const f = e.discCount || 1;
  if (!Number.isInteger(f) || f < 1 || f > 4 || !n) return null;
  const k = qe(e.packaging), _ = !!k && k !== n, P = new Set(m.map((o) => o.sourceId)), d = Ue(n, f);
  return _ && !s || !d.every((o) => P.has(r[o])) || !Object.values(a).every((o) => !o || P.has(o)) ? null : {
    confirmedPackagingOverride: _ && s,
    packaging: { structure: n, discs: f, miniLP: i, holder: n === "jewel" ? "tray" : "pocket" },
    surfaces: Object.fromEntries(d.map((o) => [o, r[o]])),
    components: ge.flatMap((o) => a[o.kind] ? [{ kind: o.kind, sourceId: a[o.kind] }] : [])
  };
}
function on(e, n) {
  const i = /^discogs-(\d+)-(\d+)\.(?:jpg|png|webp)$/.exec(e.asset);
  if (i) return n.find((m) => m === "discogs:" + i[1] + ":" + i[2]) || "";
  const s = /^photo-(\d+)\.(?:jpg|png|webp)$/.exec(e.asset);
  if (s) return n.find((m) => m === "photo:" + s[1]) || "";
  const r = /^caa-(\d+)\.(?:jpg|png|webp)$/.exec(e.asset);
  if (!r) return "";
  if (e.origin === "compatible-edition-reference" && e.sourceReleaseId)
    return n.find((m) => m === "related-caa:" + e.sourceReleaseId + ":" + r[1]) || "";
  const a = n.filter((m) => m === "caa:" + r[1] || m.startsWith("related-caa:") && m.endsWith(":" + r[1]));
  return e.origin === "edition-reference" ? a.find((m) => m === "caa:" + r[1]) || "" : a.length === 1 ? a[0] : "";
}
function sn(e, n) {
  return ge.flatMap(({ kind: i }) => {
    const s = e[i];
    if (!s) return [];
    const r = n.filter((a) => a.kind === i).at(-1);
    return [{ ...r ? { id: r.id } : {}, kind: i, sourceId: s }];
  });
}
function Ye(e, n, i) {
  var P;
  let s, r;
  if (e.schemaVersion === 2) {
    const d = ke(e, i);
    if (!d.supported) throw new Error("Unsupported album assembly: " + d.reason);
    r = d.entity;
    const o = $e(r);
    s = {
      schemaVersion: 1,
      key: r.key,
      title: r.title,
      packaging: o.configuration,
      surfaces: Object.fromEntries(Object.entries(o.surfaces).filter(([c]) => !c.startsWith("disc"))),
      calibration: r.calibration,
      placeholderHue: r.placeholderHue
    };
    for (const c of r.assembly.components) {
      if (c.kind !== "disc" || !c.mount) continue;
      const h = Number(c.mount.split(":")[1]), p = h === 0 ? "disc" : "disc" + (h + 1);
      c.surfaces.front && (s.surfaces[p] = c.surfaces.front);
    }
  } else s = e;
  if (s.schemaVersion !== 1) throw new Error("Unsupported album entity schema");
  if (i.rigVersion !== 1) throw new Error("Unsupported album model rig");
  const a = {}, m = {}, f = {}, k = {};
  for (const [d, o] of Object.entries(s.surfaces)) {
    if (!o) continue;
    const c = d;
    a[c] = n(o.asset), o.region && (m[c] = [...o.region]), o.warpRows && (f[c] = o.warpRows.map((h) => [...h])), c.startsWith("disc") && o.discCalibration && (k[c] = structuredClone(o.discCalibration));
  }
  const _ = r ? r.assembly.components.filter((d) => ["obi", "booklet", "inner-sleeve"].includes(d.kind)).map((d) => {
    var o, c, h;
    return {
      id: d.id,
      kind: d.kind,
      source: n(d.surfaces.front.asset),
      region: d.surfaces.front.region,
      warpRows: d.surfaces.front.warpRows,
      ...d.surfaces.back ? { back: { source: n(d.surfaces.back.asset), region: d.surfaces.back.region, warpRows: d.surfaces.back.warpRows } } : {},
      mount: d.mount,
      dimensions: d.dimensions,
      ...d.kind === "booklet" && d.fold ? { fold: structuredClone(d.fold) } : {},
      ...(o = d.contains) != null && o.length ? { discIndex: Number((h = (c = r.assembly.components.find((p) => p.id === d.contains[0])) == null ? void 0 : c.mount) == null ? void 0 : h.split(":")[1]) } : {}
    };
  }) : (P = s.components) == null ? void 0 : P.map(({ asset: d, back: o, ...c }) => ({
    ...c,
    source: n(d),
    ...o ? { back: { source: n(o.asset), region: o.region, warpRows: o.warpRows } } : {}
  }));
  return {
    id: s.key,
    title: s.title,
    placeholderHue: s.placeholderHue ?? 0,
    packaging: { ...s.packaging, photoRegions: m },
    modelTextures: a,
    ...Object.keys(f).length ? { modelWarpRows: f } : {},
    ...Object.keys(k).length ? { modelDiscCalibrations: k } : {},
    ...s.calibration ? { modelCalibration: structuredClone(s.calibration) } : {},
    ..._ != null && _.length ? { modelAccessories: _ } : {},
    ...r ? { assembly: r, ...r.presentation ? { presentation: structuredClone(r.presentation) } : {} } : {},
    modelAssets: { ...i }
  };
}
function Ze(e, n, i, s = !1) {
  const r = B(n, i).length, a = (e.modelAccessories ?? []).reduce((f, k) => {
    var _, P;
    return k.mount === "booklet:panel:" + i ? f + (((_ = k.dimensions) == null ? void 0 : _.depth) ?? 0.8) + 0.2 : k.kind === "inner-sleeve" && k.mount === "sleeve:panel:" + i ? f + Math.max(0, (((P = k.dimensions) == null ? void 0 : P.depth) ?? 1.9) - 1.2) + 0.2 : f;
  }, 0), m = n.kind === "gatefold" && n.holder === "pocket" && n.pocketOpening === "inner";
  return a + (r ? n.holder === "pocket" ? (m ? 2.07 : s ? 2.5 : 3.8) + (r - 1) * 1.25 : 4.8 + (r - 1) * 1.8 : 0);
}
function Ve(e) {
  var c, h, p;
  const n = (c = e.modelCalibration) == null ? void 0 : c.spine, i = W(e.packaging);
  if (!n || !["gatefold", "digipak", "digibook"].includes(i.kind)) return null;
  const s = i.kind === "gatefold" && i.holder === "pocket" && i.pocketOpening === "inner", r = s ? 138 : i.kind === "digipak" ? 139 : i.kind === "digibook" ? 140 : 135, a = i.kind === "gatefold" && i.holder === "pocket" && i.miniLP && !s && Array.from({ length: i.panels }, (E, g) => B(i, g).length).every((E) => E <= 1), m = Array.from({ length: i.panels }, (E, g) => Ze(e, i, g, a)).reduce((E, g) => E + g, s ? 0.12 : 0.7), f = (s ? 4.6 : i.kind === "digibook" ? 13 : i.kind === "digipak" ? 7 : 4) * (i.panels - 1), _ = s || i.kind === "gatefold" && i.panels === 2 && i.miniLP && i.holder === "pocket" && i.pocketOpening === "outer" ? 1 : Math.PI / 2, P = n.widthRatio * (((p = (h = e.packaging) == null ? void 0 : h.size) == null ? void 0 : p.width) ?? r), d = Math.max(m, i.kind === "digibook" ? 13 : 0) * _, o = Math.max(P, d);
  return {
    basis: n.basis,
    status: P < d ? "minimum-cd-fit" : "applied",
    requestedMm: P,
    appliedMm: o,
    minimumMm: d,
    factor: o / (f * _),
    compactPockets: a
  };
}
function rn(e) {
  const n = ke(e);
  return n.supported ? Ve(Ye(n.entity, (i) => i, { baseUrl: "", rigVersion: 1 })) : null;
}
const an = Object.freeze({ id: "album-engine", pluginProtocol: 1, ...Me }), X = /* @__PURE__ */ new WeakMap();
async function cn(e, n, i) {
  let s;
  switch (e) {
    case "viewer":
      s = (await import("./index-DvrPqAhe.js").then((P) => P.i)).AlbumViewer;
      break;
    case "guided-editor":
      s = (await import("./GuidedTwinEditor-DTVfobVE.js")).GuidedTwinEditor;
      break;
    case "accessories-editor":
      s = (await import("./TwinAccessoriesEditor-Uq4Tp8H_.js")).TwinAccessoriesEditor;
      break;
    case "disc-calibration-editor":
      s = (await import("./DiscCalibrationEditor-iPgE70iO.js")).DiscCalibrationEditor;
      break;
    default:
      throw new Error("Unknown Album Engine mount kind");
  }
  const [{ createRoot: r }, { createElement: a }] = await Promise.all([import("./client-D6t40Q-P.js").then((P) => P.c), Promise.resolve().then(() => Se)]), m = X.get(n);
  m && (m(), await Promise.resolve());
  const f = r(n), k = new AbortController(), _ = ve(f, k, () => {
    X.get(n) === _ && X.delete(n);
  });
  return X.set(n, _), f.render(a(s, e === "viewer" ? { ...i, lifecycle: k.signal } : i)), _;
}
export {
  Fe as A,
  Ze as B,
  He as C,
  ke as D,
  an as E,
  cn as F,
  Xe as G,
  rn as H,
  fe as M,
  W as a,
  Je as b,
  Ye as c,
  nn as d,
  Ue as e,
  tn as f,
  en as g,
  Qe as h,
  qe as i,
  ge as j,
  sn as k,
  Be as l,
  We as m,
  Le as n,
  Ce as o,
  ie as p,
  te as q,
  C as r,
  on as s,
  $e as t,
  Ke as u,
  de as v,
  B as w,
  me as x,
  Ve as y,
  Ge as z
};
