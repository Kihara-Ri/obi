import { j as e } from "./jsx-runtime-B0GD0xBr.js";
import { r as t, g as y, s as v, j as N, k as S } from "./plugin-DPTO-O3o.js";
function I({ photos: n, candidate: l, components: i, resolveSource: x, onSubmit: j, onClose: o }) {
  const a = t.useMemo(() => y(n, l), [l, n]), h = a.map((s) => s.sourceId), [d, g] = t.useState(() => {
    const s = {};
    for (const r of i)
      s[r.kind] = v(r, h);
    return s;
  }), [c, u] = t.useState(!1), [p, m] = t.useState("");
  if (!a.length) return /* @__PURE__ */ e.jsx("p", { className: "small-note", children: "当前实体没有可复用的已核验图集或实物照片，暂不能增删附件。请先补充实物照片。" });
  const b = async () => {
    if (!c) {
      u(!0), m("");
      try {
        await j(S(d, i)), o();
      } catch (s) {
        m(s instanceof Error ? s.message : "附件保存失败");
      } finally {
        u(!1);
      }
    }
  };
  return /* @__PURE__ */ e.jsxs("section", { className: "twin-guided", "aria-label": "更新独立包装附件", children: [
    /* @__PURE__ */ e.jsx("p", { className: "small-note", children: "补充或移除附件，不重新生成封套和 CD。只允许使用已核验的发行版原图和当前实物照片；未选择的附件不会创建模型。" }),
    /* @__PURE__ */ e.jsx("div", { className: "twin-guided-gallery", children: a.map((s) => /* @__PURE__ */ e.jsxs("figure", { children: [
      /* @__PURE__ */ e.jsx(
        "img",
        {
          alt: s.accessoryLabel,
          loading: "lazy",
          src: x(s.sourceId)
        }
      ),
      /* @__PURE__ */ e.jsx("figcaption", { children: s.accessoryLabel })
    ] }, s.sourceId)) }),
    /* @__PURE__ */ e.jsx("div", { className: "twin-guided-mapping", children: N.map((s) => /* @__PURE__ */ e.jsxs("label", { children: [
      s.shortLabel,
      /* @__PURE__ */ e.jsxs("select", { value: d[s.kind] || "", onChange: (r) => g((f) => ({ ...f, [s.kind]: r.target.value })), children: [
        /* @__PURE__ */ e.jsx("option", { value: "", children: "无附件 / 移除" }),
        a.map((r) => /* @__PURE__ */ e.jsxs("option", { value: r.sourceId, children: [
          r.accessoryLabel,
          " · ",
          r.sourceId
        ] }, r.sourceId))
      ] })
    ] }, s.kind)) }),
    p ? /* @__PURE__ */ e.jsx("p", { role: "alert", className: "twin-error", children: p }) : null,
    /* @__PURE__ */ e.jsxs("div", { className: "twin-generate-actions", children: [
      /* @__PURE__ */ e.jsx("button", { type: "button", className: "primary", disabled: c, onClick: () => void b(), children: c ? "保存中…" : "保存附件" }),
      /* @__PURE__ */ e.jsx("button", { type: "button", className: "quiet", disabled: c, onClick: o, children: "取消" })
    ] })
  ] });
}
export {
  I as TwinAccessoriesEditor
};
