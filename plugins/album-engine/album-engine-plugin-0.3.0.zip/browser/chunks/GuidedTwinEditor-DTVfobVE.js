import { j as s } from "./jsx-runtime-B0GD0xBr.js";
import { r as l, g as T, i as v, d as _, e as B, f as D, G as F, h as O, j as z } from "./plugin-DPTO-O3o.js";
function H({ candidate: a, photos: o, initialSurfaces: N, resolveSource: k, onSubmit: E, disabled: S = !1 }) {
  const t = l.useMemo(() => T(o, a), [a, o]), [i, y] = l.useState(() => v(a == null ? void 0 : a.packaging)), [d, I] = l.useState(!1), [u, C] = l.useState(!1), [g, A] = l.useState(() => _(N, t)), [m, G] = l.useState({}), [r, x] = l.useState(!1), [h, j] = l.useState("");
  if (!a) return /* @__PURE__ */ s.jsx("p", { className: "small-note", children: "等待确认发行版图集数据。" });
  const L = a.discCount || 1, w = B(i, L), p = v(a.packaging), R = !!i && !!p && p !== i, f = D(a, i, d, u, g, m, t), b = f !== null, M = async () => {
    if (!(!b || r)) {
      x(!0), j("");
      try {
        await E(f);
      } catch (e) {
        j(e instanceof Error ? e.message : "图源确认失败");
      } finally {
        x(!1);
      }
    }
  }, P = /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
    /* @__PURE__ */ s.jsx("option", { value: "", children: "请确认图源" }),
    t.map((e) => /* @__PURE__ */ s.jsxs("option", { value: e.sourceId, children: [
      e.guidedLabel,
      " · ",
      e.sourceId
    ] }, e.sourceId))
  ] });
  return /* @__PURE__ */ s.jsxs("section", { className: "twin-guided", "aria-label": "人工确认数字实体素材", children: [
    /* @__PURE__ */ s.jsx("p", { className: "small-note", children: "无需视觉模型。只有已验证的同版或同封装图片可选择；Discogs 照片没有准确的面类型标签，请对照缩略图逐一确认。" }),
    /* @__PURE__ */ s.jsxs("div", { className: "twin-guided-packaging", children: [
      /* @__PURE__ */ s.jsxs("label", { children: [
        "实物封装",
        /* @__PURE__ */ s.jsxs("select", { value: i, onChange: (e) => y(e.target.value), children: [
          /* @__PURE__ */ s.jsx("option", { value: "", children: "选择封装类型" }),
          F.map((e) => /* @__PURE__ */ s.jsx("option", { value: e.value, children: e.label }, e.value))
        ] })
      ] }),
      /* @__PURE__ */ s.jsxs("label", { children: [
        /* @__PURE__ */ s.jsx(
          "input",
          {
            type: "checkbox",
            checked: d,
            disabled: i !== "card-sleeve" && i !== "gatefold",
            onChange: (e) => I(e.target.checked)
          }
        ),
        " Mini LP 尺寸/形式"
      ] })
    ] }),
    R ? /* @__PURE__ */ s.jsxs("label", { children: [
      /* @__PURE__ */ s.jsx(
        "input",
        {
          type: "checkbox",
          checked: u,
          onChange: (e) => C(e.target.checked)
        }
      ),
      "已核对实物，确认与 MusicBrainz 所列封装类型不同"
    ] }) : null,
    /* @__PURE__ */ s.jsx("div", { className: "twin-guided-gallery", children: t.map((e, n) => /* @__PURE__ */ s.jsxs("figure", { children: [
      /* @__PURE__ */ s.jsx(
        "img",
        {
          src: k(e.sourceId),
          loading: "lazy",
          alt: e.guidedLabel
        }
      ),
      /* @__PURE__ */ s.jsxs("figcaption", { children: [
        n + 1,
        ". ",
        e.guidedLabel
      ] })
    ] }, e.sourceId)) }),
    /* @__PURE__ */ s.jsx("div", { className: "twin-guided-mapping", children: w.map((e) => /* @__PURE__ */ s.jsxs("label", { children: [
      O[e] || e,
      /* @__PURE__ */ s.jsx("select", { value: g[e] || "", onChange: (n) => A((c) => ({ ...c, [e]: n.target.value })), children: P })
    ] }, e)) }),
    /* @__PURE__ */ s.jsx("p", { className: "small-note", children: "可选独立 3D 附件：仅在确实有照片时指定，歌词册、侧标和内袋不会被伪装成封套内页。" }),
    /* @__PURE__ */ s.jsx("div", { className: "twin-guided-mapping", children: z.map((e) => /* @__PURE__ */ s.jsxs("label", { children: [
      e.label,
      /* @__PURE__ */ s.jsxs("select", { value: m[e.kind] || "", onChange: (n) => G((c) => ({ ...c, [e.kind]: n.target.value })), children: [
        /* @__PURE__ */ s.jsx("option", { value: "", children: "没有这个附件 / 暂不建模" }),
        t.map((n) => /* @__PURE__ */ s.jsxs("option", { value: n.sourceId, children: [
          n.guidedLabel,
          " · ",
          n.sourceId
        ] }, n.sourceId))
      ] })
    ] }, e.kind)) }),
    h ? /* @__PURE__ */ s.jsx("p", { className: "twin-error", role: "alert", children: h }) : null,
    /* @__PURE__ */ s.jsx("button", { type: "button", className: "primary", disabled: !b || r || S, onClick: () => void M(), children: r ? "正在确认…" : "确认图片与包装，生成 3D 实体" })
  ] });
}
export {
  H as GuidedTwinEditor
};
