import { C as s, D as t, E as e, F as n, b as o, y as r, H as m } from "./chunks/plugin-DPTO-O3o.js";
export {
  s as editionMaterialSources,
  t as inspectAlbum,
  e as manifest,
  n as mount,
  o as requestAlbumOrientationPermission,
  r as spineCalibrationFit,
  m as spineCalibrationFitForEntity
};
